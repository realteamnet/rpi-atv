import{s,T as p,a2 as A,r as W,k as d,j as t,ah as f,a0 as z,i as x,g as G,a1 as B,_ as Q,W as V,F as X}from"./vendor.281da1c4.js";import{_ as Y,W as F}from"./WizardStepper.d6b52cac.js";import{m as c,f as H,a as L,a7 as v,cR as M,cS as J,cT as K,q as N,j as R,cU as Z}from"./index.b20384c6.js";import{F as tt}from"./FeedbackAndSupport.6b7330d1.js";import{a as et,O as it}from"./OrganisationPageWrapper.168e07c4.js";import{_ as at}from"./Pill.57759def.js";import{s as w}from"./slugify.ec4044c3.js";import{f as _}from"./date.02c92264.js";import{S as nt}from"./SectionContainer.126407a1.js";import{u as ot,a as st}from"./useRouterWithState.4e85082f.js";import{a as rt}from"./organisation.c289f012.js";import"./CircleIcon.c8c9e429.js";import"./useGlossary.051e47b6.js";import"./upperFirst.427ac793.js";import"./startCase.d9c4fdfc.js";import"./startCase.b6a27f54.js";import"./array.16bb7391.js";import"./PageHeader.215820c0.js";import"./PageNavigation.81107d24.js";import"./slugify.e6045279.js";import"./index.a3bca40c.js";import"./index.647f9079.js";import"./index.560c5515.js";import"./index.548bb946.js";import"./number.d970b2c6.js";const lt=s(p).withConfig({componentId:"sc-v0uy34-0"})(["grid-area:dates;padding-bottom:1rem;",""],c.tablet`
    padding-left: 0;
    padding-bottom: 0;
  `),dt=s.div.withConfig({componentId:"sc-v0uy34-1"})(["display:flex;align-items:center;justify-content:center;height:100%;min-height:4rem;grid-area:indicator;transition:background-color 150ms ease;background-color:",";svg{fill:",";transition:fill 150ms ease;}",""],e=>e.theme.blackberry100,e=>e.theme.tertiary,c.tablet`
    display: none;
  `),E=s(A).withConfig({componentId:"sc-v0uy34-2"})(["display:none;",""],c.tablet`
    display: block;
  `),ct=s(H).withConfig({componentId:"sc-v0uy34-3"})(["display:flex;justify-content:space-between;border:1px solid ",";align-items:center;text-decoration:none;color:",";overflow:hidden;padding:0 0 0 1rem;margin-top:-1px;transition:background-color 150ms ",";@supports (display:grid){display:grid;grid-gap:0.5rem;grid-template-columns:1fr 5rem 2rem;grid-row-gap:1rem;grid-template-areas:'name status indicator' 'dates dates indicator';}&:hover,&:focus{background-color:",";","{background-color:",";color:",";}}",""],e=>e.theme.bodyBackground,e=>e.theme.bodyCopy,e=>e.theme.easeInOutCirc,e=>e.theme.blackberry100,E,e=>e.theme.buttonTertiary,e=>e.theme.white400,c.tablet`
    grid-template-columns: 1.5fr 2fr 1fr auto;
    grid-template-areas: 'name dates status indicator';
    padding: 0 1.5rem;
    height: 3.75rem;
  `),mt=s(p).withConfig({componentId:"sc-v0uy34-4"})(["margin-top:0;margin-bottom:1rem;",""],c.tablet`
    margin-bottom: 1.75rem;
  `),gt=s(p).withConfig({componentId:"sc-v0uy34-5"})(["padding-top:1rem;grid-area:name;",""],c.tablet`
    padding-top: 0;
  `),pt=s.div.withConfig({componentId:"sc-v0uy34-6"})(["display:flex;align-items:center;grid-area:status;padding-top:1rem;justify-self:end;",""],c.tablet`
    padding-top: 0;
    justify-self: start;
  `),ut=s(p).attrs({as:"button",fontStyle:"italic",size:"14"}).withConfig({componentId:"sc-v0uy34-7"})(["background:none;border:none;padding:0;margin:0 auto;cursor:pointer;display:block;"]);function ht({season:e,organisation:m,tenant:a,name:u}){return m.type===M.Club?`/${a}/org/${w(m.name)}/${m.id}/${w(`${u} ${e.name}`)}/${e.id}/teams`:`/${a}/org/${w(m.name)}/${w(`${u} ${e.name}`)}/${e.id}`}const ft=({name:e,seasons:m,organisation:a,tenant:u,statusFilter:C})=>{const{t:o}=L(),[h,y]=W.exports.useState(3),g=C?m.filter(l=>C.includes(l.status.value)):m;return d("div",{children:[t(mt,{weight:"700",size:"18",as:"h2",children:e}),m.length===0&&t(f,{variant:"empty",children:o("components.seasonstatuslist.there-are-currently-no-seasons-for-this-competitio")}),g.length===0&&m.length>0&&t(f,{variant:"empty",children:o("components.seasonstatuslist.there-are-no-seasons-available-for-the-selected-fi")}),t("div",{children:g.slice(0,h).map(l=>d(ct,{to:ht({season:l,organisation:a,tenant:u,name:e}),"data-testid":`season-${l.id}-item`,children:[t(gt,{size:"16",weight:"600",children:o(l.name)}),d(lt,{size:"16",color:"darkGrey400",children:[t(p,{as:"span",children:_(l.startDate,"dd MMM yyyy")})," ","\u2014"," ",t(p,{as:"span",children:_(l.endDate,"dd MMM yyyy")})]}),t(pt,{children:t(at,{variant:l.status.value===v.Active?"active":l.status.value===v.Upcoming?"upcoming":"complete",small:!0,text:o(l.status.name)})}),t(E,{variant:"tertiary",halo:!0,icon:"right-arrow-strong",iconPosition:"right",iconSize:"12",size:"small",children:o("components.seasonstatuslist.select")}),t(dt,{children:t(z,{name:"right-arrow"})})]},l.id))}),g.length>h&&d(ut,{onClick:()=>y(h+2),"data-testid":"see-more",children:[o("components.seasonstatuslist.see-more")," ",t(z,{name:"down-arrow",size:"8"})]})]})},k=[{name:x.t("constants.season-status.upcoming"),value:v.Upcoming},{name:x.t("constants.season-status.active"),value:v.Active},{name:x.t("constants.season-status.completed"),value:v.Completed}],Yt=G`
  query discoverCompetitions($organisationID: ID!, $organisationCode: String!) {
    discoverCompetitions(organisationID: $organisationID) {
      id
      name
      seasons(organisationID: $organisationID) {
        id
        name
        startDate
        endDate
        status {
          name
          value
        }
      }
      organisation {
        id
        name
        logo {
          sizes {
            url
            dimensions {
              width
              height
            }
          }
        }
      }
    }
    discoverOrganisation(code: $organisationCode) {
      ...OrganisationDetails
    }
    tenantConfiguration {
      label
      sport {
        name
      }
      ...TenantContactRolesConfiguration
    }
  }
  ${J}
  ${K}
`,vt=s(N).withConfig({componentId:"sc-1dp4kje-0"})(["display:grid;grid-gap:1rem;",""],c.tablet`
    grid-gap: 2.125rem;
  `),yt=s(N).withConfig({componentId:"sc-1dp4kje-1"})(["display:flex;flex-direction:column;> * + *{margin-top:2rem;","}@supports (display:grid){display:grid;grid-gap:2rem;> * + *{margin-top:initial;","}","}"],c.tablet`
      margin-top: 3.5rem;
    `,c.tablet`
        margin-top: initial;
      `,c.tablet`
      grid-gap: 3.5rem;
    `),bt=s(R).withConfig({componentId:"sc-1dp4kje-2"})(["display:grid;grid-gap:2rem;padding-top:2rem;padding-bottom:2rem;"]),Ct=s(tt).withConfig({componentId:"sc-1dp4kje-3"})(["margin-top:4rem;"]),St=s(et).withConfig({componentId:"sc-1dp4kje-4"})(["padding:0;.organisation-name{font-size:1rem;font-weight:700;}svg{width:2rem;height:2rem;}",""],c.tablet`
    .organisation-name {
      font-size: 1.25rem;
    }

    svg {
      width: 2.5rem;
      height: 2.5rem;
    }
  `),wt=s.div.withConfig({componentId:"sc-1dp4kje-5"})(["display:grid;grid-gap:1rem;",""],c.tablet`
    grid-gap: 2rem;
  `),kt=s(B).withConfig({componentId:"sc-1dp4kje-6"})(["flex-wrap:wrap;"]),Ht=({organisationId:e,tenant:m})=>{var O;const{t:a}=L(),u=ot(),C=st(),[o,h]=W.exports.useState([]),y=o.length<k.length,{data:g,loading:l,error:P}=Z({variables:{organisationID:String(e),organisationCode:String(e)},onError:()=>null,onCompleted:i=>{var r;((r=u.state)==null?void 0:r.redirectToRegistrationTab)&&i.discoverCompetitions.length<1&&C(`${u.pathname}/register`,{replace:!0,state:{redirectToRegistrationTab:!1}});const n=k.reduce((S,j)=>j.value===v.Completed?S:[...S,j.value],[]);h(n)}});if(l)return t(Q,{});if(P||!g||!g.discoverCompetitions||!g.discoverOrganisation||!g.tenantConfiguration)return t(bt,{children:t(f,{variant:"error",children:a("pages.seasonlist.there-was-an-error-retrieving-the-competitions-for")})});const{discoverOrganisation:U,discoverCompetitions:I,tenantConfiguration:{contactRoles:q}}=g,b=rt(U,q),$=b.type===M.Club,D=I.reduce((i,n)=>{const r=i.findIndex(S=>S.organisation.id===n.organisation.id);return r>-1?[...i.slice(0,r),{...i[r],competitions:[...i[r].competitions,n]},...i.slice(r+1)]:[...i,{organisation:n.organisation,competitions:[n]}]},[]),T=y?D.filter(i=>i.competitions.some(n=>n.seasons.some(r=>o.includes(r.status.value)))):D;return d(it,{organisation:b,tenant:String(m),children:[t(V,{title:a(b.name),meta:[{name:"description",content:a("pages.seasonlist.view-with-params-competitions-seasons-and-contact-details",{organisationName:a(b.name)})}]}),d(R,{children:[d(nt,{noXPadding:!0,children:[I.length===0&&d(vt,{children:[t(p,{size:"20",weight:"700",children:a("pages.seasonlist.no-competitions-available")}),t(f,{variant:"empty",children:a("pages.seasonlist.there-are-currently-no-competitions-available-for-with-params",{param0:" ",param1:a($?"pages.seasonlist.club":"pages.seasonlist.association")})})]}),I.length>0&&d(X,{children:[d(Y,{children:[t(F,{count:1,highlight:!0,children:a("pages.seasonlist.select-a-season")}),t(F,{count:2,children:a("pages.seasonlist.select-a-with-params",{param0:a($?"pages.seasonlist.team":"pages.seasonlist.grade")})})]}),d(yt,{children:[d(B,{direction:{tablet:"row"},justifyContent:{tablet:"space-between"},gap:"m",children:[t(p,{size:"20",weight:"700",children:a("pages.seasonlist.competitions")}),t(kt,{direction:"row",gap:"s",children:k.map(i=>{const n=o.includes(i.value);return t(A,{size:"small",variant:n?"primary":"quinary","aria-pressed":n,onClick:()=>h(n?o.filter(r=>r!==i.value):o.concat(i.value)),children:t(p,{weight:"400",children:a(i.name)})},i.value)})})]}),y&&T.length===0&&(o.length===1?t(f,{variant:"empty",children:a("pages.seasonlist.there-are-noseasons-available-for-this-organisatio-with-params",{param0:" ",param1:(O=k.find(i=>i.value===o[0]))==null?void 0:O.name.toLowerCase(),param2:" "})}):t(f,{variant:"empty",children:a("pages.seasonlist.there-are-no-seasons-available-for-the-selected-fi")})),T.map(i=>d(wt,{"data-testid":`season-org-${i.organisation.id}`,children:[$&&t(St,{name:a(i.organisation.name),logo:i.organisation.logo}),i.competitions.map(n=>y&&n.seasons.every(r=>!o.includes(r.status.value))?null:t(ft,{name:a(n.name),seasons:n.seasons,organisation:b,tenant:String(m),statusFilter:o},n.id))]},i.organisation.id))]})]})]}),t(Ct,{})]})]})};export{Yt as DISCOVER_COMPETITIONS,Ht as default};
//# sourceMappingURL=SeasonList.2bca98bd.js.map
