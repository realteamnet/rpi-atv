import{aA as t}from"./vendor.281da1c4.js";import{u as a}from"./upperFirst.427ac793.js";var i=t,o=a;function p(r){return o(i(r).toLowerCase())}var n=p;export{n as c};
//# sourceMappingURL=capitalize.b2fec627.js.map
