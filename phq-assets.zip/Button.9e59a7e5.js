import{s as d,R as o,j as i,A as r,k as u}from"./vendor.281da1c4.js";import{m as c}from"./spacing.debe5ff3.js";import{I as m}from"./Icon.a2ddfd25.js";import{L as b}from"./Loader.7e370d5f.js";var a;(function(t){t.primary="primary",t.secondary="secondary",t.tertiary="tertiary",t.quaternary="quaternary",t.quinary="quinary",t.senary="senary",t.septenary="septenary",t.text="text",t.error="error",t.white="white"})(a||(a={}));const h=d.span`
  /* Display flex for IE11 */
  display: flex;
  display: grid;
  grid-auto-flow: column;
  grid-template-columns: max-content;
  justify-content: center;
  grid-gap: 0.5rem;
  align-items: center;
`,g=d(m)`
  transition: fill 175ms ease;
  ${t=>t.iconPosition==="right"?"order: 1":""};
  color: currentColor;
`,n=t=>`${t.charAt(0).toUpperCase()}${t.substring(1)}`,v=d(o.forwardRef((t,e)=>i("button",{...t,ref:e}))).withConfig({shouldForwardProp:(t,e)=>!["color"].includes(t)&&(e(t)||["state"].includes(t))})`
  display: inline-block;
  background-color: ${t=>t.halo?"transparent":t.variant?t.theme[`button${n(t.variant)}`]:t.theme.blackberry400};
  border: ${t=>t.variant&&t.variant!==a.text?`2px solid ${t.theme[`button${n(t.variant)}`]}`:"none"};
  font-size: 1rem;
  font-weight: ${t=>t.variant&&t.variant===a.text?400:t.theme.buttonFontWeight};
  ${t=>t.borderRadius!=="none"&&!t.block&&t.variant!==a.text&&r`
      border-radius: 50px;
    `}
  ${t=>t.block&&r`
      text-align: center;
    `}
  line-height: 1;
  text-decoration: none;
  vertical-align: top;
  color: ${t=>t.color?t.theme[t.color]:t.variant?t.halo?t.theme[`button${n(t.variant)}`]:t.theme[`button${n(t.variant)}Color`]:t.theme.black400};
  cursor: ${t=>t.disabled?"not-allowed":"pointer"};
  transition:
    background-color 175ms ease,
    color 175ms ease,
    border-color 175ms ease;
  opacity: ${t=>t.disabled||t.loading?"0.5":"1"};
  ${t=>(t.disabled||t.loading)&&"outline: none;"}
  font-family: ${t=>t.theme.fontFamily};

  svg {
    fill: currentColor;
  }

  padding: ${t=>{if(t.noPadding)return 0;const e=t.size==="x-small"?t.theme.buttonPaddingExtraSmall:t.size==="small"?t.theme.buttonPaddingSmall:t.size==="wide"?t.theme.buttonPaddingWide:t.size==="large"?t.theme.buttonPaddingLarge:t.theme.buttonPadding;return t.evenPadding?e.split(" ")[0]:e}};
  ${c.up("tablet")} {
    padding: ${t=>{if(t.noPadding)return 0;const e=t.size==="x-small"?t.theme.buttonPaddingTabletExtraSmall:t.size==="small"?t.theme.buttonPaddingTabletSmall:t.size==="wide"?t.theme.buttonPaddingTabletWide:t.size==="large"?t.theme.buttonPaddingTabletLarge:t.theme.buttonPaddingTablet;return t.evenPadding?e.split(" ")[0]:e}};
  }

  &:hover,
  &:focus {
    background-color: ${t=>{if(!(t.disabled||t.loading||t.variant===a.text))return t.variant&&!t.halo?t.theme[`button${n(t.variant)}Hover`]:t.variant&&t.halo?t.theme[`button${n(t.variant)}`]:t.theme.secondary}};

    color: ${t=>{if(t.disabled||t.loading||!t.variant||t.variant==="text")return;const e=`button${n(t.variant)}HoverColor`;if(t.variant&&!t.halo)return t.theme[e];const l=`button${n(t.variant)}`;return t.variant&&t.halo&&t.theme[e]!==t.theme[l]?t.theme[`button${n(t.variant)}HoverColor`]:t.theme.white400}};

    text-decoration: ${t=>{if(t.variant===a.text&&!t.disabled)return"underline"}};

    border-color: ${t=>!t.loading&&!t.disabled&&t.variant&&!t.halo&&t.theme[`button${n(t.variant)}Hover`]};
  }

  ${t=>!t.disabled&&r`
      &:active {
        opacity: 0.7;
      }
    `}
`,f=d(b)`
  margin: 0;
  svg {
    stroke: currentColor;
  }
`,$=o.forwardRef(({loading:t,...e},l)=>i(v,{...e,disabled:e.disabled||t,ref:l,children:u(h,{children:[e.icon&&!t&&i(g,{iconPosition:e.iconPosition,name:e.icon,size:e.iconSize||"16","data-testid":"button-icon"}),t&&i(f,{size:1}),e.children]})}));$.defaultProps={variant:a.primary};export{$ as B};
//# sourceMappingURL=Button.9e59a7e5.js.map
