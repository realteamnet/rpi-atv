import{s as n,T as o,k as r,j as a,a2 as i}from"./vendor.281da1c4.js";import{q as s,m as p,a as d}from"./index.b20384c6.js";const m=n(s).withConfig({componentId:"sc-ioph5n-0"})(["background-size:14px 100%;background-repeat:no-repeat;background-image:linear-gradient( to bottom,",","," );text-align:center;line-height:1.6;max-width:50rem;margin-left:auto;margin-right:auto;&{padding-left:2rem;padding-right:2rem;padding-bottom:2rem;}p{margin:0;}.feedbackButton{margin-top:2.5rem;}",""],e=>e.theme.blueberry400,e=>e.theme.grape400,p.tablet`
    & {
      padding-left: 3.5rem;
      padding-right: 3.5rem;
      padding-bottom: 2.375rem
    }
  `),c=n(o).withConfig({componentId:"sc-ioph5n-1"})(["margin-bottom:1.5rem;margin-top:0;"]),l=({className:e})=>{const{t}=d();return r(m,{className:e,children:[a(c,{size:"28",weight:"700",color:"blackberry400",as:"h3",children:t("components.feedbackandsupport.feedback-and-support")}),a(o,{as:"p",children:t("components.feedbackandsupport.if-you-need-assistance-using-playhq-please-check-o")}),a(i,{variant:"primary",icon:"right-arrow-strong",iconPosition:"right",className:"feedbackButton",as:"a",href:"https://support.playhq.com/",children:t("components.feedbackandsupport.find-out-more")})]})};export{l as F};
//# sourceMappingURL=FeedbackAndSupport.6b7330d1.js.map
