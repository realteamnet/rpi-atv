const s="/assets/noImage.c3574b60.svg";export{s as n};
//# sourceMappingURL=noImage.3eec2646.js.map
