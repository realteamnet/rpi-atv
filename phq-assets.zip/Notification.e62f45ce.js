import{r as n,j as t,F as s,af as c,s as a,A as i,k as u}from"./vendor.281da1c4.js";import{I as o}from"./Icon.a2ddfd25.js";const l=({delay:e,children:m})=>{const[h,d]=n.exports.useState(!0);return n.exports.useEffect(()=>{const g=setTimeout(()=>d(!1),e);return()=>clearTimeout(g)}),t(s,{children:h?m:null})};l.defaultProps={delay:4e3};const f=c`
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
`,y=c`
  0% {
    opacity: 0;
  }
  15% {
    opacity: 1;
  }
  85% {
    opacity: 1;
  }
  100% {
    opacity: 0;
  }
`,v=a.div`
  display: flex;
  align-items: center;
  text-align: left;
  width: 100%;
  padding: 1rem;
  font-size: 0.875rem;
  line-height: 1.125;
  ${e=>e.variant==="empty"&&`
    justify-content: center;
    font-style: italic;
  `}
  color: ${e=>e.theme.black400};
  background-color: ${e=>e.variant==="success"?e.theme.successBackground:e.variant==="warning"?e.theme.warningBackground:e.variant==="info"?e.theme.infoBackground:e.variant==="error"?e.theme.errorBackground:e.theme.emptyBackground};
  animation: ${e=>e.fadeOutDelay?i`
          ${y} ${e.fadeOutDelay}ms ease
        `:i`
          ${f} 500ms ease
        `};

  ul {
    list-style-type: none;
    padding: 0;
    margin: 0;
  }

  li:not(:last-of-type) {
    padding-bottom: 0.5rem;
  }

  a {
    color: ${e=>e.variant==="warning"?e.theme.warningHighlight:e.variant==="error"?e.theme.errorHighlight:e.theme.white400};
    text-decoration-color: ${e=>e.variant==="warning"?e.theme.warningHighlight:e.variant==="error"?e.theme.errorHighlight:e.theme.white400};
  }
`,w=a.div`
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: 50%;
  background-color: ${e=>e.variant==="success"?e.theme.kiwi400:e.variant==="info"?e.theme.infoHighlight:e.theme.errorHighlight};
  height: 1.5rem;
  width: 1.5rem;
  margin-right: 1rem;
  flex-shrink: 0;
`,k=a(o)`
  fill: white;
`,x=a(o)`
  min-width: 1.5rem;
  margin-right: 1rem;
`,r=e=>u(v,{variant:e.variant,...e,children:[e.removeIcon?null:e.variant==="warning"?t(x,{name:"warning"}):e.variant!=="empty"?t(w,{variant:e.variant,children:t(k,{name:e.variant==="success"?"tick":e.variant==="info"?"information":"cross",size:"12"})}):null,e.children]}),$=e=>e.fadeOutDelay?t(l,{delay:e.fadeOutDelay,children:t(r,{...e})}):t(r,{...e});$.defaultProps={variant:"success"};export{$ as N};
//# sourceMappingURL=Notification.e62f45ce.js.map
