import{s as i,T as n}from"./vendor.281da1c4.js";import{m as t}from"./index.b20384c6.js";const a=i.div.withConfig({componentId:"sc-1rq8l4t-0"})(["max-width:48rem;padding-left:1rem;padding-right:1rem;margin:0 auto;width:100%;position:relative;z-index:1;"]),l=i.div.withConfig({componentId:"sc-1rq8l4t-1"})(["background:white;"]),s=i.div.withConfig({componentId:"sc-1rq8l4t-2"})(["position:relative;z-index:1;&::before{content:'';height:450px;width:100%;background-color:",";position:absolute;padding:2rem 0 10rem;top:0;clip-path:ellipse(190% 80% at 50% 0%);background-image:url(",");background-blend-mode:soft-light;background-size:cover;background-position:center center;"," "," ","}"],e=>e.theme.blackberry400,e=>e.image,t.mobile`
      clip-path: ellipse(150% 80% at 50% 0%);
    `,t.tablet`
      clip-path: ellipse(100% 80% at 50% 0%);
    `,t.desktop`
      clip-path: ellipse(75% 80% at 50% 0%);
    `),c=i(n).attrs({as:"h1",size:"36",weight:"700"}).withConfig({componentId:"sc-1rq8l4t-3"})(["display:flex;justify-content:center;color:",";margin:0;padding-top:8rem;padding-bottom:3.5rem;text-align:center;"],e=>e.theme.white400),p=i.div.withConfig({componentId:"sc-1rq8l4t-4"})(["position:relative;z-index:0;background-color:",";padding:20rem 0 4rem;margin-top:-20rem;clip-path:ellipse(190% 80% at 50% 20%);"," "," "," p{margin:0;padding:0 2rem;font-size:1.125rem;line-height:1.33;text-align:center;color:",";}"],e=>e.theme.blueberry100,t.mobile`
    clip-path: ellipse(150% 80% at 50% 20%);
  `,t.tablet`
    clip-path: ellipse(100% 80% at 50% 20%);
  `,t.desktop`
    clip-path: ellipse(75% 80% at 50% 20%);
  `,e=>e.theme.blackberry400),d=i(n).attrs({as:"h2",size:"28",weight:"500"}).withConfig({componentId:"sc-1rq8l4t-5"})(["display:flex;justify-content:center;color:",";margin:0;padding-top:2rem;padding-bottom:1rem;text-align:center;"],e=>e.theme.blackberry400),g=i.div.withConfig({componentId:"sc-1rq8l4t-6"})(["box-shadow:0 5px 3px 0 rgba(0,0,0,0.16);background-color:white;"]),m=i.div.withConfig({componentId:"sc-1rq8l4t-7"})(["display:flex;flex-direction:column;padding:2rem;align-items:center;border-bottom:1px rgba(0,0,0,0.16) solid;"," img{width:74px;height:43px;flex:0 0 43px;","}.basketball-victoria_logo{width:122px;height:37px;flex:0 0 37px;","}p{font-size:1.125rem;line-height:1.17;color:",";text-align:center;","}"],t.mobile`
    flex-direction: row;
  `,t.mobile`
      flex: 0 0 74px;
    `,t.mobile`
      flex: 0 0 122px;
    `,e=>e.theme.darkGrey400,t.mobile`
      margin: 0 0 0 2rem;
      text-align: left;
    `),h=i.div.withConfig({componentId:"sc-1rq8l4t-8"})(["display:flex;flex-direction:column;align-items:center;padding:2rem;p{margin:0;flex:1;color:",";font-size:1.125rem;line-height:1.17;font-weight:500;}",""],e=>e.theme.blackberry400,t.tablet`
    flex-direction: row;
  `),f=i.div.withConfig({componentId:"sc-1rq8l4t-9"})(["display:flex;flex-direction:column;padding-top:1rem;a svg{transform:rotate(90deg);width:12px;}a:last-of-type{margin-top:1rem;}",""],t.tablet`
    flex-direction: row;
    padding-top: 0;

    a:last-of-type {
      margin-left: 1rem;
      margin-top: 0;
    }
  `),b=i.div.withConfig({componentId:"sc-1rq8l4t-10"})(["padding:0 0 2rem;&.benefits-wrapper--reverse-curved{background:",";clip-path:ellipse(190% 80% at 50% 80%);padding:2rem 0 4rem;"," "," ","}"],e=>e.theme.lightGrey400,t.mobile`
      clip-path: ellipse(150% 80% at 50% 80%);
    `,t.tablet`
      clip-path: ellipse(100% 80% at 50% 80%);
    `,t.desktop`
      clip-path: ellipse(70% 80% at 50% 80%);
    `),x=i.div.withConfig({componentId:"sc-1rq8l4t-11"})(["display:flex;padding:2rem 0;flex-direction:column;align-items:center;",""],t.tablet`
    flex-direction: row;
  `),u=i.div.withConfig({componentId:"sc-1rq8l4t-12"})(["text-align:center;order:2;"," "," p,ul{font-size:1rem;line-height:1.35;color:",";}ul{display:flex;align-items:center;flex-direction:column;padding-left:1rem;","}"],t.tablet`
    order: ${e=>e.alignment==="left"?"0":"2"};
    text-align: left;
  `,t.tablet`
    ${e=>e.alignment==="left"?"margin-right: 2rem;":"margin-left: 2rem;"}
  `,e=>e.theme.darkGrey400,t.tablet`
      align-items: flex-start;
    `),w=i(n).attrs({as:"h3",size:"32",weight:"700",color:"black400"}).withConfig({componentId:"sc-1rq8l4t-13"})(["padding-top:2rem;display:flex;justify-content:center;text-align:center;"]),k=i(n).attrs({as:"h4",size:"20",weight:"700",color:"black400"}).withConfig({componentId:"sc-1rq8l4t-14"})([""]),v=i.div.withConfig({componentId:"sc-1rq8l4t-15"})(["order:1;width:200px;height:200px;flex:0 0 200px;border-radius:100px;background-color:",";background-image:url(",");background-size:90px;background-repeat:no-repeat;background-position:center center;"],e=>e.theme.blackberry400,e=>e.image),y="/assets/fixtures.bc9279ce.svg",C="/assets/intuitive.71640470.svg",I="/assets/payment.661f6cfe.svg";export{a as B,f as C,l as P,s as S,c as a,g as b,m as c,h as d,p as e,d as f,b as g,w as h,x as i,u as j,k,v as l,C as m,y as n,I as p};
//# sourceMappingURL=payment.ea947ff4.js.map
