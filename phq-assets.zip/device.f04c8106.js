const e=()=>{const t=navigator.userAgent||navigator.vendor;if(/android/i.test(t))return"Android";if(/iPhone|iPod/.test(t))return"iOS"};export{e as g};
//# sourceMappingURL=device.f04c8106.js.map
