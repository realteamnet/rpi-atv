import{ax as t,r as l,ay as s}from"./vendor.281da1c4.js";var a={},r=t&&t.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(a,"__esModule",{value:!0});const n=r(l.exports),o=r(s),u=o.default.ul`
  padding: 0;
  margin: 0;
  ${e=>!e.isOrdered&&"list-style-type: none;"}
`,i=e=>n.default.createElement(u,{...e,as:e.isOrdered?"ol":"ul"},e.children);var _=a.default=i;export{a as L,_};
//# sourceMappingURL=List.c6284ff0.js.map
