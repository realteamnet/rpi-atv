import{a6 as a}from"./index.b20384c6.js";const s=n=>{var r;const{data:e}=a({context:{headers:{tenant:n}},onError:()=>null});return!!((r=e==null?void 0:e.tenantConfiguration)!=null&&r.playerNumberDisabled)};export{s as u};
//# sourceMappingURL=usePlayerNumberDisabled.7a85ab09.js.map
