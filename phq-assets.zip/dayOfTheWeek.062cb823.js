import{b4 as a}from"./index.b20384c6.js";const d={[a.Monday]:a.Monday,[a.Tuesday]:a.Tuesday,[a.Wednesday]:a.Wednesday,[a.Thursday]:a.Thursday,[a.Friday]:a.Friday,[a.Saturday]:a.Saturday,[a.Sunday]:a.Sunday},e=Object.values(d);export{e as s};
//# sourceMappingURL=dayOfTheWeek.062cb823.js.map
