import{ax as o,r as i,ay as u,aC as c}from"./vendor.281da1c4.js";var r={},l=o&&o.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(r,"__esModule",{value:!0});const t=l(i.exports),s=l(u),m=c,f=s.default.li`
  display: grid;
  grid-template-columns: 1fr auto;
  align-items: center;
  padding: 1rem;
  background-color: ${e=>e.theme.white400};
  border-bottom: 1px solid ${e=>e.theme.bodyBackground};

  ${m.media.tablet`
    padding: 1rem 2rem;
  `}
`,_=s.default.div`
  padding-left: 1rem;
`,p=t.default.forwardRef(({children:e,actions:a,...d},n)=>t.default.createElement(f,{ref:n,...d},e," ",a&&t.default.createElement(_,null,a)));var y=r.default=p;export{y as _};
//# sourceMappingURL=ListRow.f26a289f.js.map
