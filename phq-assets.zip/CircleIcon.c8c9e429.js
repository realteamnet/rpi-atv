import{ax as a,r as c,ay as s,aB as i}from"./vendor.281da1c4.js";var n={},t=a&&a.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(n,"__esModule",{value:!0});const r=t(c.exports),o=t(s),l=t(i),u=o.default.div`
  border-radius: 100%;
  width: ${e=>`${parseInt(e.size,10)/16}rem`};
  height: ${e=>`${parseInt(e.size,10)/16}rem`};
  background-color: ${e=>e.background?e.theme[e.background]:e.theme.secondary};
  position: relative;

  svg {
    width: ${e=>parseInt(e.size,10)/32}rem;
    height: ${e=>parseInt(e.size,10)/32}rem;
  }
`,d=(0,o.default)(l.default)`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
`,f=e=>r.default.createElement(u,{...e},r.default.createElement(d,{name:e.icon,color:e.iconColor,size:e.size}));var _=n.default=f;export{n as C,_};
//# sourceMappingURL=CircleIcon.c8c9e429.js.map
