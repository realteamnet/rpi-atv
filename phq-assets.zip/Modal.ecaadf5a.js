import{ax as o,r as v,ay as y,aB as x,aC as w}from"./vendor.281da1c4.js";var c={},M=o&&o.__createBinding||(Object.create?function(e,t,a,r){r===void 0&&(r=a);var n=Object.getOwnPropertyDescriptor(t,a);(!n||("get"in n?!t.__esModule:n.writable||n.configurable))&&(n={enumerable:!0,get:function(){return t[a]}}),Object.defineProperty(e,r,n)}:function(e,t,a,r){r===void 0&&(r=a),e[r]=t[a]}),$=o&&o.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),_=o&&o.__importStar||function(e){if(e&&e.__esModule)return e;var t={};if(e!=null)for(var a in e)a!=="default"&&Object.prototype.hasOwnProperty.call(e,a)&&M(t,e,a);return $(t,e),t},E=o&&o.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(c,"__esModule",{value:!0});var j=c.ModalActions=void 0;const i=_(v.exports),l=_(y),u=w,O=E(x),z=l.default.div`
  position: fixed;
  top: 0;
  left: 0;
  height: 100%;
  width: 100%;
  background-color: rgba(0, 0, 0, 0.7);
  z-index: 9999;
`,B=(0,l.keyframes)`
  from {
    opacity: 0;
    transform: translate(-50%, calc(-50% + 1rem));
  }
  to {
    opacity: 1;
    transform: translate(-50%, -50%);
  }
`,D={s:"28rem",m:"33.75rem",l:"42rem",xl:"48rem"},C=l.default.div`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background-color: ${e=>e.theme.white400};
  border-radius: 3px;
  width: calc(100% - 2rem);
  animation: ${B} 500ms ease;
  overflow: auto;
  max-height: calc(100vh - 2rem);
  max-width: ${e=>{var t;return(t=e.maxWidth)!=null?t:e.size&&D[e.size]}};

  ${e=>e.hasCloseButton&&(0,l.css)`
      max-height: calc(100vh - 4rem);
      margin-top: 1rem;
    `}

  ${u.mq.up("tablet")} {
    width: 50%;
    max-height: calc(100vh - 2rem);
    margin-top: 0;
  }
`,P=l.default.button`
  position: absolute;
  top: 0;
  right: 0;
  background: none;
  border: none;
  padding: 1rem;
  cursor: pointer;

  &:hover,
  &:focus,
  &:active {
    svg {
      fill: ${e=>e.theme.primary};
    }
  }

  ${u.mq.up("tablet")} {
    padding: 2.5rem;
  }
`;j=c.ModalActions=l.default.section`
  display: flex;
  flex-direction: column;
  justify-content: ${e=>e.align==="center"?"center":"flex-end"};
  gap: 1rem;
  padding: ${e=>e.align==="center"?"1rem 2rem 2rem":"1rem 2rem"};
  border-top: ${e=>e.align==="center"?"none":`1px solid ${e.theme.grey400}`};

  ${u.mq.up("mobile")} {
    flex-direction: row;
  }
`;const q=(0,l.default)(O.default)`
  transition: fill 150ms ease;
`,I=({className:e,children:t,hasCloseButton:a,onClickOutside:r,maxWidth:n,size:b,...g})=>{const f=i.default.createRef(),h=(s,d)=>{d&&d.current&&!d.current.contains(s.target)&&r&&r()},m=s=>{h(s,f)},p=s=>{s.key==="Escape"&&r&&r()};return(0,i.useEffect)(()=>(document.addEventListener("mousedown",m,!1),document.addEventListener("keydown",p,!1),()=>{document.removeEventListener("mousedown",m,!1),document.removeEventListener("keydown",p,!1)})),i.default.createElement(z,{role:"dialog","aria-modal":"true","aria-label":g["aria-label"]},a&&i.default.createElement(P,{"data-testid":"modal-close-button"},i.default.createElement(q,{name:"cross",color:"white400",size:"24"})),i.default.createElement(C,{className:e,hasCloseButton:a,maxWidth:n,size:b,ref:f},t))};var A=c.default=I;export{j as M,A as _};
//# sourceMappingURL=Modal.ecaadf5a.js.map
