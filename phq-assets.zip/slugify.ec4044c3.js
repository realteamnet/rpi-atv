import{s as o}from"./slugify.e6045279.js";const e=s=>o(s,{lower:!0,remove:/[^\w- ]/g});export{e as s};
//# sourceMappingURL=slugify.ec4044c3.js.map
