import{ax as l,r as m,ay as b,aN as _,aO as h,aB as g,aD as y}from"./vendor.281da1c4.js";var u={},$=l&&l.__createBinding||(Object.create?function(e,t,a,r){r===void 0&&(r=a);var i=Object.getOwnPropertyDescriptor(t,a);(!i||("get"in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[a]}}),Object.defineProperty(e,r,i)}:function(e,t,a,r){r===void 0&&(r=a),e[r]=t[a]}),v=l&&l.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),w=l&&l.__importStar||function(e){if(e&&e.__esModule)return e;var t={};if(e!=null)for(var a in e)a!=="default"&&Object.prototype.hasOwnProperty.call(e,a)&&$(t,e,a);return v(t,e),t},o=l&&l.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(u,"__esModule",{value:!0});const n=o(m.exports),d=w(b),x=o(_),j=o(h),O=o(g),E=o(y),c=d.default.input`
  left: 0;
  border: 0;
  clip: rect(0 0 0 0);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  width: 1px;
  white-space: nowrap;
`,F=(0,d.default)(j.default)`
  margin-bottom: 0.5rem;
`,C=d.default.div`
  display: grid;
  grid-auto-columns: auto;
  grid-auto-flow: column;
  grid-gap: 3.5rem;
  justify-content: start;
  position: relative;
`,f=(0,d.default)(E.default).attrs({as:"label"})`
  display: grid;
  grid-template-columns: auto 1fr;
  grid-gap: 1rem;
  align-items: center;
  cursor: pointer;

  ${e=>e.disabled&&(0,d.css)`
      opacity: 0.75;
      cursor: not-allowed;
      background: none;
      filter: none;
      transform: none;
      color: ${e.theme.darkGrey400};
    `}
`,D=d.default.i`
  width: 1.5rem;
  height: 1.5rem;
  border: 1px solid black;
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: 50%;
  border-color: ${e=>e.disabled&&e.theme.darkGrey400};

  ${e=>e.checked&&(0,d.css)`
      background-color: ${t=>t.theme.kiwi400};
      border-color: ${t=>t.theme.kiwi400};
    `}

  ${c}:focus + ${f} & {
    box-shadow: 0 0 5px 0.25rem ${e=>e.theme.primary};
  }
`,s=e=>{const t=`${e.id}-error`;return n.default.createElement(x.default,{touched:e.touched,error:e.error,errorId:t,className:e.className},n.default.createElement(F,{htmlFor:e.id,hide:e.hideLabel},typeof e.label=="string"?n.default.createElement(n.default.Fragment,null,e.label,e.required?"*":""):e.label),n.default.createElement(C,null,e.items.map(a=>{const r=e.value===a.value;return n.default.createElement(n.default.Fragment,{key:`radio-${e.name}-${a.name}`},n.default.createElement(c,{"aria-describedby":e.error?t:void 0,"aria-invalid":!!e.error,value:String(a.value),touched:e.touched,disabled:e.disabled,error:e.error,onBlur:e.onBlur,onChange:e.onChange,id:`radio-${e.name}-${a.name}`,name:e.name,type:"radio",checked:r}),n.default.createElement(f,{htmlFor:`radio-${e.name}-${a.name}`,"data-testid":`radio-${e.name}-${a.name}`,disabled:e.disabled},n.default.createElement(D,{disabled:e.disabled,checked:r},r&&n.default.createElement(O.default,{name:"tick",color:"white400",size:"8"})),a.name))})))};s.defaultProps={hideLabel:!1,type:"text",required:!1};var M=u.default=s;export{M as _};
//# sourceMappingURL=RadioGroup.595643cf.js.map
