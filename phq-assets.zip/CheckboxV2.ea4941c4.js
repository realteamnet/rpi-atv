import{ax as d,r as n,ay as u,aN as h,aO as m,aB as b,bF as f,aP as s,az as g}from"./vendor.281da1c4.js";var i={},a=d&&d.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(i,"__esModule",{value:!0});const t=a(n.exports),$=s,r=a(u),x=g,y=a(h),k=a(m),_=a(b),l=a(f),C=(0,r.default)(y.default)`
  display: grid;
  grid-gap: 0.5rem;
  grid-template-columns: ${e=>!e.hideLabel&&"auto 1fr"};
`,E=r.default.span`
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: ${e=>e.theme.white400};
  border: 2px solid
    ${e=>e.$uncheckedColor?e.theme[e.$uncheckedColor]:e.theme.darkGrey400};

  min-height: 1.25rem;
  min-width: 1.25rem;
  height: 1.25rem;
  width: 1.25rem;

  border-radius: 2px;
  cursor: pointer;

  ${l.default}:disabled + & {
    border: 2px solid ${e=>e.theme.grey400};
    background-color: ${e=>e.theme.lightGrey400};
    opacity: 0.5;
    cursor: not-allowed;
  }

  ${l.default}:checked + & {
    background-color: ${e=>e.theme.blackberry400};
    border-color: ${e=>e.theme.white400};
    border: none;
  }

  ${l.default}:focus + & {
    outline: 2px solid ${e=>e.theme.blueberry400};
  }
`,v=(0,r.default)(k.default)`
  margin-left: 0.5rem;
`,c=e=>e==null?void 0:e.split(" ").join("-"),w=e=>{const{error:o}=e;return t.default.createElement(C,{touched:e.touched,hideError:e.hideError,hideLabel:e.hideLabel||e.align==="right",error:e.error,className:e.className,errorId:`${e.name}-error`},t.default.createElement(x.Box,{as:"label",htmlFor:e.id,display:"flex",alignItems:"center",flexDirection:e.align==="right"?"row-reverse":"row",justifyContent:e.align==="right"?"space-between":"flex-start"},t.default.createElement(l.default,{as:"input",disabled:e.disabled,checked:e.value,id:e.id,type:"checkbox",onChange:e.onChange,"aria-checked":e.value,"aria-labelledby":`${c(e.id)}-checkbox-label`,role:"checkbox"}),t.default.createElement(E,{$uncheckedColor:o?"cherry400":void 0},e.value&&t.default.createElement(_.default,{name:"tick",color:"white400",size:"14"}))," ",t.default.createElement(v,{htmlFor:e.id,hide:e.hideLabel,"data-tooltip-id":`${e.id}-checkbox-tooltip`,"data-tooltip-content":e["data-tooltip-content"]||e["data-tip"],color:o&&!e.value?"cherry400":void 0,id:`${c(e.id)}-checkbox-label`},typeof e.label=="string"?t.default.createElement(t.default.Fragment,null,e.label,e.required?"*":""):e.label)),t.default.createElement($.Tooltip,{id:`${e.id}-checkbox-tooltip`,place:"right"}))};var L=i.default=w;export{L as _};
//# sourceMappingURL=CheckboxV2.ea4941c4.js.map
