import{aA as r}from"./vendor.281da1c4.js";var t=r;function a(o){return t(o).toLowerCase()}var n=a;export{n as t};
//# sourceMappingURL=toLower.7740e301.js.map
