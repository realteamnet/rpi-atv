import{r as t,t as a}from"./index.647f9079.js";function o(e){t(1,arguments);var r=a(e);return r.setHours(23,59,59,999),r}export{o as e};
//# sourceMappingURL=index.390ce73d.js.map
