import{ax as d,r as n,ay as u,aN as c,aO as h,aD as m}from"./vendor.281da1c4.js";var o={},t=d&&d.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(o,"__esModule",{value:!0});const r=t(n.exports),a=t(u),f=t(c),b=t(h),s=t(m),x=(0,a.default)(s.default)`
  padding: 1rem;
  width: 100%;
  outline: none;
  resize: ${e=>e.resize};
  font-family: inherit;
  font-weight: 600;
  border: 1px solid
    ${e=>e.touched&&e.error?e.theme.errorHighlight:e.value?e.theme.inputFullBorder:e.theme.inputEmptyBorder};
  transition: border-color 200ms ease;
  border-radius: ${e=>e.theme.inputBorderRadius};

  &::placeholder {
    color: ${e=>e.theme.placeholder};
    font-weight: 400;
  }

  &:focus {
    box-shadow: 0 0 5px 0 rgba(0, 0, 0, 0.25);
  }

  &[disabled] {
    background-color: ${e=>e.theme.inputDisabledBackground};
    border-color: ${e=>e.theme.inputDisabledBorder};
    cursor: not-allowed;
    color: currentColor;
  }
`,_=(0,a.default)(b.default)`
  margin-bottom: 0.5rem;
`,g=a.default.div`
  position: relative;
`,i=e=>{const l=e.errorId||`${e.id}-error`;return r.default.createElement(f.default,{touched:e.touched,error:e.error,errorId:l,className:e.className,hideError:e.hideError},r.default.createElement(_,{htmlFor:e.id,hide:e.hideLabel},typeof e.label=="string"?r.default.createElement(r.default.Fragment,null,e.label,e.required?"*":""):e.label),r.default.createElement(g,null,r.default.createElement(x,{as:"textarea","data-testid":e["data-testid"]||"textarea","aria-describedby":e.error?l:void 0,"aria-invalid":!!e.error,value:e.value,touched:e.touched,error:e.error,onBlur:e.onBlur,onChange:e.onChange,placeholder:e.placeholder,label:e.label,id:e.id,name:e.name,disabled:e.disabled,required:e.required,maxLength:e.maxLength,rows:e.rows,resize:e.resize})))};i.defaultProps={hideLabel:!1,hideError:!1,type:"text",required:!1,resize:"both"};var y=o.default=i;export{y as _};
//# sourceMappingURL=TextArea.7c63490b.js.map
