import{ax as r,r as s,ay as d,bK as _,aB as m}from"./vendor.281da1c4.js";var f={},y=r&&r.__createBinding||(Object.create?function(e,t,a,n){n===void 0&&(n=a);var i=Object.getOwnPropertyDescriptor(t,a);(!i||("get"in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[a]}}),Object.defineProperty(e,n,i)}:function(e,t,a,n){n===void 0&&(n=a),e[n]=t[a]}),b=r&&r.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),g=r&&r.__importStar||function(e){if(e&&e.__esModule)return e;var t={};if(e!=null)for(var a in e)a!=="default"&&Object.prototype.hasOwnProperty.call(e,a)&&y(t,e,a);return b(t,e),t},l=r&&r.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(f,"__esModule",{value:!0});const o=l(s.exports),c=g(d),p=l(_),v=l(m),h=(0,c.keyframes)`
  from {
    opacity: 0;
    transform: translateY(50%);
  }
  to {
    opacity: 1;
    transform: translateY(0%);
  }
`,O=(0,c.default)(v.default)`
  margin-right: 0.5rem;
`,j=c.default.div`
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 1.25rem;
  font-weight: 600;
  line-height: 1.125;
  color: ${e=>e.theme.white400};
  background-color: ${e=>e.theme.successHighlight};
  border-radius: 0.5rem;
  animation: ${h} 500ms ease;
`,u=e=>o.default.createElement(j,null,o.default.createElement(O,{name:"tick",color:"white400",size:"16"}),e.children),M=e=>e.fadeOutDelay?o.default.createElement(p.default,{delay:e.fadeOutDelay},o.default.createElement(u,{...e})):o.default.createElement(u,{...e});var w=f.default=M;export{w as _};
//# sourceMappingURL=ModalNotification.5955f37d.js.map
