import{s as n,r as j,k as s,j as e,ac as I,g as W,m as E,a2 as T,T as m,b as A,a3 as N,_ as q,ah as x,W as H,aj as P,a0 as U}from"./vendor.281da1c4.js";import{_ as M}from"./List.c6284ff0.js";import{_ as Q}from"./ListRow.f26a289f.js";import{_ as V}from"./Pill.57759def.js";import{_ as X,W as O}from"./WizardStepper.d6b52cac.js";import{m as l,a as D,cS as J,cT as K,j as L,f as Y,F as Z,o as ee,q as te,a7 as F}from"./index.b20384c6.js";import{a as ae,O as ie}from"./OrganisationPageWrapper.168e07c4.js";import{S as re}from"./SectionContainer.126407a1.js";import{_ as $}from"./Select.d9384d85.js";import{a as ne}from"./organisation.c289f012.js";import{s as G}from"./slugify.ec4044c3.js";import"./CircleIcon.c8c9e429.js";import"./useGlossary.051e47b6.js";import"./upperFirst.427ac793.js";import"./startCase.d9c4fdfc.js";import"./startCase.b6a27f54.js";import"./array.16bb7391.js";import"./PageHeader.215820c0.js";import"./PageNavigation.81107d24.js";import"./slugify.e6045279.js";const oe=n.form.withConfig({componentId:"sc-1bt5dly-0"})(["display:flex;display:grid;grid-gap:0.5rem;span{padding:0.5rem 2rem 0.5rem 0.5rem;}",""],l.tablet`
    grid-template-columns: repeat(3, 1fr);

    > * {
      width: 9rem;
    }
  `),se=({touched:t,values:h,setFieldValue:f,setTouched:a,handleSubmit:w,grades:C,genders:g,ageGroups:S,teams:y,onFilterChange:k})=>{const{t:c}=D();return j.exports.useEffect(()=>{k()},[h.grade,h.gender,h.age]),s(oe,{noValidate:!0,onSubmit:w,children:[e(I,{name:"grade",children:({field:i})=>e($,{...i,id:i.name,"data-testid":"team-list-filter-grade-field",hideLabel:!0,label:c("forms.teamlistfilterform.label-grade"),items:C.filter(o=>y.some(d=>!!d.grade&&d.grade.id===o.value)),placeholder:c("forms.teamlistfilterform.placeholder-all-grades"),placeholderSelectable:!0,onChange:o=>f(i.name,o),onBlur:()=>a({...t,[i.name]:!0})})}),e(I,{name:"gender",children:({field:i})=>e($,{...i,id:i.name,"data-testid":"team-list-filter-gender-field",hideLabel:!0,label:c("forms.teamlistfilterform.label-gender"),items:g.filter(o=>y.some(d=>d.gender.value===o.value)),placeholderSelectable:!0,placeholder:c("forms.teamlistfilterform.placeholder-all-genders"),onChange:o=>f(i.name,o),onBlur:()=>a({...t,[i.name]:!0})})}),e(I,{name:"age",children:({field:i})=>e($,{...i,id:i.name,"data-testid":"team-list-filter-age-field",hideLabel:!0,label:c("forms.teamlistfilterform.label-age-group"),items:S.filter(o=>y.some(d=>d.ageGroup.value===o.value)),placeholderSelectable:!0,placeholder:c("forms.teamlistfilterform.placeholder-all-age-groups"),onChange:o=>f(i.name,o),onBlur:()=>a({...t,[i.name]:!0})})})]})},le=W`
  query discoverOrganisationTeams(
    $seasonCode: String!
    $seasonId: ID!
    $organisationCode: String!
    $organisationId: ID!
  ) {
    discoverSeason(seasonID: $seasonCode) {
      id
      name
      competition {
        id
        name
        organisation {
          id
          name
          logo {
            sizes {
              url
              dimensions {
                width
                height
              }
            }
          }
        }
      }
      status {
        name
        value
      }
      grades {
        id
        name
      }
    }
    tenantConfiguration {
      label
      competition {
        ageGroups {
          name
          value
        }
        genders {
          name
          value
        }
      }
      ...TenantContactRolesConfiguration
    }
    discoverTeams(
      filter: { seasonID: $seasonId, organisationID: $organisationId }
    ) {
      id
      name
      gender {
        name
        value
      }
      ageGroup {
        name
        value
      }
      grade {
        id
        name
      }
    }
    discoverOrganisation(code: $organisationCode) {
      ...OrganisationDetails
    }
  }
  ${J}
  ${K}
`,de=n.div.withConfig({componentId:"sc-yd82ml-0"})(["display:flex;flex-direction:column;@supports (display:grid){display:grid;align-items:center;grid-gap:1rem;}",""],l.tablet`
    grid-template-columns: 2fr 3fr;
    align-items: start;

    & > * + * {
      margin-top: 1rem;

      @supports (display: grid) {
        margin-top: 0;
      }
    }
  `),me=n(L).withConfig({componentId:"sc-yd82ml-1"})(["display:grid;grid-gap:2rem;padding-top:2rem;padding-bottom:2rem;"]),ge=n(M).withConfig({componentId:"sc-yd82ml-2"})(["width:100%;grid-column:1 / -1;border-left:1px solid ",";border-right:1px solid ",";border-top:1px solid ",";",""],t=>t.theme.bodyBackground,t=>t.theme.bodyBackground,t=>t.theme.bodyBackground,l.tablet`
    border-top: none;
    margin-top: 1rem;
  `),ce=n(re).withConfig({componentId:"sc-yd82ml-3"})(["& > ol{padding:2rem;","{padding:0 2rem;}}"],E.up("tablet")),pe=n.div.withConfig({componentId:"sc-yd82ml-4"})(["display:flex;align-items:center;justify-content:center;height:100%;grid-column:2;grid-row:1 / 5;padding:0.5rem;background-color:",";svg{transition:fill 150ms ease;}",""],t=>t.theme.blackberry100,l.tablet`
    display: none;
  `),R=n(T).withConfig({componentId:"sc-yd82ml-5"})(["display:none;"," margin-right:1.5rem;"],l.tablet`
    display: block;
    justify-self: end;
    white-space: nowrap;
  `),he=n(Q).attrs({as:Y}).withConfig({componentId:"sc-yd82ml-6"})(["display:flex;word-break:break-word;text-decoration:none;border-bottom:1px solid ",";color:",";& > *:first-child{width:100%;}@supports (display:grid){display:grid;grid-template-columns:1fr auto;}&[href]{transition:background-color 150ms ",";&:hover,&:focus{background-color:",";","{background-color:",";color:",";}}}",""],t=>t.theme.bodyBackground,t=>t.theme.bodyCopy,t=>t.theme.easeInOutCirc,t=>t.theme.blackberry100,R,t=>t.theme.buttonTertiary,t=>t.theme.white400,l.tablet`
    grid-gap: 2rem;
    grid-template-columns: 1fr;
    align-items: center;
    min-height: 3.125rem;
  `),fe=n.div.withConfig({componentId:"sc-yd82ml-7"})(["display:-ms-grid;display:grid;align-items:center;padding:1rem;",""],l.tablet`
    padding: 0;
    -ms-grid-columns: 2fr 2fr 1fr 1fr 7.75rem;
    grid-template-columns: 2fr 2fr 1fr 1fr 7.75rem;
    grid-gap: 2rem;
    justify-items: start;

    & > * { display:block; }
    & > *:nth-child(2) { -ms-grid-column: 2; }
    & > *:nth-child(3) { -ms-grid-column: 3; }
    & > *:nth-child(4) { -ms-grid-column: 4; }
    & > *:nth-child(5) { -ms-grid-column: 5; }

    & > *:first-of-type {
      padding-left: 1.5rem;
    }
  `),ue=n.li.withConfig({componentId:"sc-yd82ml-8"})(["display:none;background-color:",";text-transform:uppercase;color:",";padding:0.5rem 0;align-items:center;border-bottom:1px solid ",";",""],t=>t.theme.grey400,t=>t.theme.darkGrey400,t=>t.theme.bodyBackground,l.tablet`
    display: -ms-grid;
    display: grid;
    -ms-grid-columns: 2fr 2fr 1fr 1fr 7.75rem;
    grid-template-columns: 2fr 2fr 1fr 1fr 7.75rem;
    grid-gap: 2rem;
    justify-items: start;
    padding: 0.5rem 0;

    & > * { display:block; }
    & > *:nth-child(2) { -ms-grid-column: 2; }
    & > *:nth-child(3) { -ms-grid-column: 3; }
    & > *:nth-child(4) { -ms-grid-column: 4; }

    > *:first-of-type {
      padding-left: 1.5rem;
    }
  `),ye=n.div.withConfig({componentId:"sc-yd82ml-9"})(["display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:1rem;",""],l.tablet`
    margin-bottom: 0;
  `),be=n(T).withConfig({componentId:"sc-yd82ml-10"})(["margin-left:auto;",""],l.tablet`
    display: none;
  `),ve=n.div.withConfig({componentId:"sc-yd82ml-11"})(["display:",";grid-gap:1rem;margin-bottom:2rem;",""],t=>t.visible?"grid":"none",l.tablet`
    /* Flex for IE11 */
    display: flex;
    display: grid;
    grid-gap: 0;
    justify-items: flex-end;
    grid-auto-flow: column;
    margin-bottom: 0;

    @supports (display: grid) {
      margin-top: 0;
      align-self: center;
    }
  `),we=n.div.withConfig({componentId:"sc-yd82ml-12"})(["display:flex;flex-direction:column;"]),Ce=n.div.withConfig({componentId:"sc-yd82ml-13"})(["display:grid;grid-gap:0.25rem;"]),Se=n(T).withConfig({componentId:"sc-yd82ml-14"})(["font-style:italic;color:",";padding:0;span{justify-content:start;}",""],t=>t.theme.darkGrey400,l.tablet`
    padding: 0.5rem 1rem;
  `),ke=n.div.withConfig({componentId:"sc-yd82ml-15"})(["display:grid;grid-gap:0.5rem;",""],l.tablet`
    grid-gap: 1rem;
    grid-template-columns: auto 1fr;
    align-items: center;
  `),Ie=n(ae).withConfig({componentId:"sc-yd82ml-16"})(["padding:0;grid-column:1 / -1;.organisation-name{font-size:1rem;font-weight:700;}svg{width:2rem;height:2rem;}",""],l.tablet`
    .organisation-name {
      font-size: 1.25rem;
    }

    svg {
      width: 2.5rem;
      height: 2.5rem;
    }
  `),xe=n(m).withConfig({componentId:"sc-yd82ml-17"})(["margin:0;"]),Me=({tenant:t,seasonId:h,organisationId:f})=>{const{t:a}=D(),[w,C]=j.exports.useState([]),{data:g,loading:S,error:y}=A(le,{variables:{seasonCode:String(h),seasonId:String(h),organisationCode:String(f),organisationId:String(f)},onError:()=>null}),[k,c]=N(!1);if(S)return e(q,{});if(y||!g||!g.discoverTeams||!g.tenantConfiguration||!g.discoverOrganisation)return e(me,{children:e(x,{variant:"error",children:a("pages.teamlist.there-was-an-error-retrieving-the-teams-for-this-s")})});if(!g.discoverSeason)return e(Z,{});const{discoverSeason:i,tenantConfiguration:o,discoverTeams:d,discoverOrganisation:b}=g,B=({grade:r,gender:p,age:z})=>{C(d.filter(v=>{let u=!0;return r&&(u=!!v.grade&&v.grade.id===r),u&&p&&(u=v.gender.value===p),u&&z&&(u=v.ageGroup.value===z),!u}))},_=d.filter(r=>!w.some(p=>p.id===r.id));return s(ie,{organisation:ne(b,o.contactRoles),tenant:String(t),children:[e(H,{title:a("pages.teamlist.param0-param1-teams-for-param2",{param0:i.competition.name,param1:i.name,param2:b.name.slice(0,20)}),meta:[{name:"description",content:a("pages.teamlist.view-param0-teams-in-the-param1-param2-param3-season",{param0:a(b.name),param1:a(i.competition.organisation.name),param2:a(i.competition.name),param3:a(i.name)})}]}),e(L,{children:s(ce,{noXPadding:!0,children:[s(X,{backPath:ee(`/${t}/org/${G(b.name)}/${b.id}`),children:[e(O,{count:1,children:s(we,{children:[a("pages.teamlist.select-a-season"),s(m,{size:"14",weight:"400",children:[a(i.competition.name),", ",a(i.name),e("br",{}),a(i.competition.organisation.name)]})]})}),e(O,{count:2,highlight:!0,children:a("pages.teamlist.select-a-team")})]}),e(te,{children:s(de,{children:[e(Ie,{name:a(i.competition.organisation.name),logo:i.competition.organisation.logo}),s(ye,{children:[s(Ce,{children:[e(xe,{size:"18",weight:"700",as:"h3",children:a(i.competition.name)}),s(ke,{children:[e(m,{color:"darkGrey400",children:a(i.name)}),e(V,{variant:i.status.value===F.Active?"active":i.status.value===F.Upcoming?"upcoming":"complete",small:!0,text:a(i.status.name)})]})]}),e(be,{onClick:()=>c(),variant:"tertiary",icon:"filter",size:"small",iconSize:"16",halo:!0,children:a("pages.teamlist.filters")})]}),e(P,{initialValues:{grade:"",gender:"",age:""},onSubmit:r=>B(r),children:r=>s(ve,{visible:k,children:[e(se,{...r,teams:d,grades:i.grades.map(p=>({name:p.name,value:p.id})),ageGroups:o.competition.ageGroups,genders:o.competition.genders,onFilterChange:()=>B(r.values)}),e(Se,{variant:"text","data-testid":"reset-filters-button",onClick:()=>{r.resetForm()},size:"small",children:a("pages.teamlist.reset")})]})}),s(ge,{"data-testid":"teams-list",children:[s(ue,{children:[e(m,{weight:"700",size:"14",children:a("pages.teamlist.team")}),e(m,{weight:"700",size:"14",children:a("pages.teamlist.grade")}),e(m,{weight:"700",size:"14",children:a("pages.teamlist.gender")}),e(m,{weight:"700",size:"14",children:a("pages.teamlist.age-group")})]},"heading"),d.length===0?e(x,{variant:"empty",children:a("pages.teamlist.there-are-currently-no-teams-for-this-season")}):_.length===0?e(x,{variant:"empty",children:a("pages.teamlist.no-teams-match-your-filters")}):_.map(r=>e("li",{children:s(he,{to:`../../teams/${G(r.name)}/${r.id}`,"data-testid":`team-${r.id}-link`,children:[s(fe,{children:[e(m,{weight:"600",size:"16",children:a(r.name)}),e(m,{color:"darkGrey400",children:r.grade?a(r.grade.name):"-"}),e(m,{color:"darkGrey400",children:a(r.gender.name)}),e(m,{color:"darkGrey400",children:a(r.ageGroup.name)}),e(R,{variant:"tertiary",halo:!0,icon:"right-arrow",iconPosition:"right",iconSize:"12",size:"small",children:a("pages.teamlist.select")})]}),e(pe,{children:e(U,{size:"16",name:"right-arrow",color:"blackberry400"})})]})},r.id))]})]})})]})})]})};export{le as DISCOVER_ORGANISATION_TEAMS,Me as default};
//# sourceMappingURL=TeamList.0b950650.js.map
