import{i as s,s as o,A as K,j as e,bN as V,F as $,ae as W,k as i,a0 as B,T as b,r as Y,_ as q,W as U,a4 as Z,ad as F,ah as J}from"./vendor.281da1c4.js";import{s as X}from"./startCase.b6a27f54.js";import{t as ee}from"./toLower.7740e301.js";import{a as D,j,m as g,q as te,i as ae,aZ as se,F as re,d0 as ne,o as oe,n as ie,dB as le}from"./index.b20384c6.js";import{O as ce}from"./OrganisationTile.94ca83c6.js";import{P as pe}from"./Pagination.b263696d.js";import{H as me,a as ge}from"./HomeSearchForm.aeddd9ba.js";import{u as de}from"./useDeepCompareEffect.1b25f930.js";import{O as d,u as he}from"./scout.09348d87.js";import{s as ye}from"./slugify.ec4044c3.js";import"./upperFirst.427ac793.js";import"./isEqual.1de36b38.js";import"./slugify.e6045279.js";const ue=[{name:s.t("constants.organisation-types.associations"),value:d.Association},{name:s.t("constants.organisation-types.clubs"),value:d.Club}],fe=o.label.withConfig({componentId:"sc-4my3yv-0"})(["position:relative;display:flex;justify-content:start;align-items:center;grid-column:1 / -1;cursor:pointer;&:not(:first-of-type){margin-left:1rem;}"]),be=o.input.withConfig({componentId:"sc-4my3yv-1"})(["border:0;clip:rect(0 0 0 0);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px;white-space:nowrap;"]),xe=o.span.withConfig({componentId:"sc-4my3yv-2"})(["display:flex;align-items:center;justify-content:center;background-color:transparent;border:2px solid ",";height:1.5rem;width:1.5rem;border-radius:2px;margin-right:0.5rem;",""],t=>t.theme.blueberry400,t=>t.isChecked&&K(["background-color:",";border-color:",";"],t.theme.blueberry400,t.theme.blueberry400)),we=({values:t,submitForm:r,touched:n,setFieldValue:x,setTouched:m})=>{const{t:h}=D();return de(()=>{n.types&&r()},[t.types]),e(V,{name:"types",children:()=>e($,{children:ue.map((l,y)=>{const c=t.types.includes(l.value);return e(W,{name:`types.${y}`,children:({field:u})=>i(fe,{htmlFor:u.name,isChecked:c,children:[e(be,{...u,id:u.name,type:"checkbox",checked:c,onChange:A=>(m({...n,types:!0}),A.target.checked?x("types",[...t.types,l.value]):x("types",t.types.filter(S=>S!==l.value))),"data-testid":`types-${l.value.toLowerCase()}-checkbox`}),e(xe,{isChecked:c,children:c&&e(B,{name:"tick",color:"white400",size:"12"})}),e(b,{size:"16",weight:"600",children:h(l.name)})]})},l.value)})})})},Ce={NAME:s.t("pages.sportglossary.afl.name"),SPORT:"AFL",SEARCH_PLACEHOLDER:s.t("pages.sportglossary.afl.search-placeholder")},Ee={NAME:s.t("pages.sportglossary.basketball.name"),SPORT:"BASKETBALL",SEARCH_PLACEHOLDER:s.t("pages.sportglossary.basketball.search-placeholder")},Ae={NAME:"",SPORT:"",SEARCH_PLACEHOLDER:s.t("pages.sportglossary.common.search-placeholder")},Se={NAME:s.t("pages.sportglossary.cricket.name"),SPORT:"CRICKET",SEARCH_PLACEHOLDER:s.t("pages.sportglossary.cricket.search-placeholder")},Re={NAME:s.t("pages.sportglossary.football.name"),SPORT:"FOOTBALL",SEARCH_PLACEHOLDER:s.t("pages.sportglossary.football.search-placeholder")},Le={NAME:s.t("pages.sportglossary.hockey.name"),SPORT:"HOCKEY",SEARCH_PLACEHOLDER:s.t("pages.sportglossary.hockey.search-placeholder")},ke={NAME:s.t("pages.sportglossary.netball.name"),SPORT:"NETBALL",SEARCH_PLACEHOLDER:s.t("pages.sportglossary.netball.search-placeholder")},Te={NAME:s.t("pages.sportglossary.rugby.name"),SPORT:"Rugby",SEARCH_PLACEHOLDER:s.t("pages.sportglossary.rugby.search-placeholder")},Oe={NAME:s.t("pages.sportglossary.sports.name"),SPORT:"OTHER",SEARCH_PLACEHOLDER:s.t("pages.sportglossary.sports.search-placeholder")},He=t=>{switch(t){case"afl":return Ce;case"basketball":return Ee;case"cricket":return Se;case"football":return Re;case"hockey":return Le;case"netball":return ke;case"rugby":return Te;case"sports":return Oe;default:return{}}},Pe=t=>{const r=Y.exports.useMemo(()=>({...Ae,...He(t)}),[t]);return n=>r[n]},ve=o(j).withConfig({componentId:"sc-z8gxqs-0"})(["padding-top:1rem;padding-bottom:2rem;display:flex;flex-direction:column;align-items:flex-start;& > * + *{margin:2rem 0 0;}"]),Ie=o.header.withConfig({componentId:"sc-z8gxqs-1"})(["margin:2rem 0 5rem;width:100%;height:17rem;display:flex;align-items:stretch;flex-direction:column;",";",";"],g.tablet`
    height: 14rem;
    margin: 1rem 0 8rem;
  `,g.desktop`
    height: 16rem;
  `),_e=o.div.withConfig({componentId:"sc-z8gxqs-2"})(["height:5rem;width:5rem;margin:0 auto;display:flex;align-items:center;justify-content:center;background:",";padding:0.3rem;border-radius:50%;overflow:hidden;filter:drop-shadow(0 2px 4px rgba(0,0,0,0.2));img{max-width:100%;max-height:100%;}"],t=>t.theme.white400),Ne=o(b).withConfig({componentId:"sc-z8gxqs-3"})(["text-align:center;line-height:1.5;margin:1rem auto;max-width:43rem;flex-grow:1;display:flex;",";"],g.desktop`
    max-width: none;
  `),ze=o(te).withConfig({componentId:"sc-z8gxqs-4"})(["display:grid;grid-template-rows:3rem 1fr;grid-gap:0.5rem;border:1px solid ",";svg{height:3rem;width:3rem;}",""],t=>t.theme.bodyBackground,g.tablet`
    grid-template-rows: auto;
    grid-template-columns: auto 1fr;
    grid-gap: 3.5rem;
    padding: 4rem;

    svg {
      height: 6.5rem;
      width: 6.5rem;
    }
  `),qe=o.div.withConfig({componentId:"sc-z8gxqs-5"})(["display:grid;grid-gap:0.5rem;align-content:center;"]),Fe=o.ul.withConfig({componentId:"sc-z8gxqs-6"})(["list-style-type:none;padding:0;margin:0 0 2.25rem;display:flex;flex-direction:column;li{margin-top:1rem;&:first-of-type{margin-top:0;}}@supports (display:grid){display:grid;grid-gap:1rem;li{margin-top:0;}}"," ",""],g.tablet`
    flex-direction: row;
    flex-wrap: wrap;

    li {
      flex-basis: calc(50% - (1rem / 2));

      &:nth-of-type(2) {
        margin-top: 0;
      }

      &:nth-of-type(2n+2) {
        margin-left: 1rem;
      }
    }

    @supports (display: grid) {
      grid-template-columns: repeat(2, 1fr);

      li:nth-of-type(2n+2) {
        margin-left: 0;
      }
    }
  `,g.desktop`
    li {
      flex-basis: calc((100% / 3) - (2rem / 3));
      margin-left: 1rem;

      &:nth-of-type(3) {
        margin-top: 0;
      }

      &:nth-child(3n + 1) {
        margin-left: 0;
      }
    }

    @supports (display: grid) {
      grid-template-columns: repeat(3, 1fr);

      li {
        margin-left: 0;
      }
    }
  `),Me=o(j).withConfig({componentId:"sc-z8gxqs-7"})(["margin-bottom:2.5rem;"]),$e=o.div.withConfig({componentId:"sc-z8gxqs-8"})(["display:flex;flex-direction:column;align-items:center;"]),Be=o(pe).withConfig({componentId:"sc-z8gxqs-9"})(["margin-top:1.5rem;margin-bottom:1.5rem;"]),De=o.form.withConfig({componentId:"sc-z8gxqs-10"})(["display:flex;align-self:flex-start;margin-top:1.5rem;"]),M=[d.Association,d.Club],at=({tenant:t})=>{var T,O,H,P,v,I,_;const{t:r}=D(),{queryParams:n,setQueryString:x}=ae(),m=n&&typeof n.limit=="string"?parseInt(n.limit,10):12,h=n&&typeof n.page=="string"?parseInt(n.page,10):1,l=n.types?Array.isArray(n.types)?n.types:n.types.split(","):M,y=M.filter(a=>l.includes(a)),{data:c,loading:u,error:A}=se(),S=(H=(O=(T=c==null?void 0:c.tenantConfiguration)==null?void 0:T.sport)==null?void 0:O.name.toLowerCase())!=null?H:"",w=Pe(S),L=w("NAME"),{data:k,loading:G,error:Q,variables:C}=he({variables:{filter:{meta:{page:h,limit:m},organisation:{types:y,tenantSlug:le(t)}}},context:{endpoint:"scout"},onError:()=>null});if(u||!L)return e(q,{});if(A)return e(re,{});const E=k&&k.search,p=E&&E.meta,f=E&&E.results,R=((P=ne.find(({slug:a})=>a===t))==null?void 0:P.name)||t;return i($,{children:[e(U,{title:r("pages.tenantlanding.param0-clubs-leagues-and-associations",{param0:R}),meta:[{name:"description",content:h<=1?r("pages.tenantlanding.search-for-with-params-clubs-leagues-and-associations-on-playhq-to-view-live-scores-fixtures-stats-standings-team-information-and-upcoming-match-details",{tenantName:R}):r("pages.tenantlanding.browse-more-clubs-leagues-and-associations-for-with-params-on-playhq-page-with-params-view-live-scores-fixtures-stats-standings-team-information-and-upcoming-match-details",{tenantName:R,page:h})}]}),i(ve,{children:[i(Ie,{children:[e(_e,{children:t==="sports"?e(Z,{}):e("img",{src:oe(`/static/${t}_logo.png`),alt:t})}),e(Ne,{as:"h1",weight:"700",color:"white400",size:"32",children:r("pages.tenantlanding.discover-clubs-and-associations-with-params",{param0:L})}),e(F,{initialValues:{query:""},onSubmit:a=>ie(`/search?query=${a.query}&sports=${w("SPORT")}`),validationSchema:me(r),children:a=>i("form",{onSubmit:a.handleSubmit,action:"/search",children:[e("input",{type:"hidden",name:"sports",value:w("SPORT").toString()}),e(ge,{...a,placeholder:w("SEARCH_PLACEHOLDER"),buttonText:r("pages.tenantlanding.search")})]})})]}),e(F,{initialValues:{types:y.length>0?y:[d.Association,d.Club]},onSubmit:a=>{x({...n,page:1,types:a.types})},children:a=>e(De,{onSubmit:a.handleSubmit,children:e(we,{...a})})}),G&&e(q,{}),Q&&e(J,{variant:"error",children:r("pages.tenantlanding.there-was-an-error-please-try-again-later")}),f&&f.length===0&&i(ze,{children:[e(B,{name:"binoculars",size:"56",color:"primary"}),i(qe,{children:[e(b,{size:"30",weight:"700",children:r("pages.tenantlanding.noavailable-with-params",{param0:" ",param1:r(((v=C==null?void 0:C.filter.organisation)==null?void 0:v.types.length)===1?`${(_=(I=C.filter.organisation)==null?void 0:I.types[0])==null?void 0:_.toLowerCase()}s`:r("pages.tenantlanding.organisations")),param2:" "})}),e(b,{size:"20",color:"darkGrey400",children:r("pages.tenantlanding.please-check-back-soon")})]})]})]}),f&&f.length>0&&i(Me,{children:[e(Fe,{"data-testid":"search-results",children:f.map(a=>{var N,z;return e(ce,{title:r(a.name),orgType:X(ee(a.type)),to:`/${a.tenant.slug}/org/${ye(a.name)}/${a.routingCode}`,images:(N=a.logo)==null?void 0:N.sizes,tenantImages:(z=a.tenant.logo)==null?void 0:z.sizes,tenantName:a.tenant.name},a.id)})}),p&&p.totalRecords>m&&i($e,{children:[e(b,{children:r("pages.tenantlanding.showing-of-with-params",{param0:p.page*m-m+1,param1:" ",param2:Math.min(p.page*m,p.totalRecords),param3:" ",param4:p.totalRecords})}),e(Be,{page:p.page,pagesCount:p.totalPages})]})]})]})};export{at as TenantLanding,at as default};
//# sourceMappingURL=TenantLanding.1246e037.js.map
