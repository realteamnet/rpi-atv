import{A as b}from"./vendor.281da1c4.js";const e={white400:"#ffffff",black400:"#190c32",grey400:"#dfe3e8",lightGrey400:"#f0f3f7",darkGrey400:"#626373",blackberry400:"#283593",blackberry200:"#c9cce4",blackberry100:"#e9eaf4",blueberry400:"#0c6ce2",blueberry200:"#c2daf8",blueberry100:"#e6f0fc",grape400:"#4e16c0",grape200:"#d3c5ef",grape100:"#ede7f9",kiwi400:"#00845e",kiwi200:"#bfe0d7",kiwi100:"#e5f2ef",cherry400:"#e00400",cherry200:"#f7c0bf",cherry100:"#fce5e5",pineapple400:"#fed03d",pineapple200:"#fff3ce",pineapple100:"#fffaeb",tangerine400:"#bf5917",tangerine200:"#ff771f",tangerine100:"#feddc7",watermelon400:"#f9375b",watermelon100:"#feebee",transparent:"transparent",cyan_outlier:"#00bcd4",grey8_outlier:"#d2d5d8",focus_outline:"#d4e7fa"},m={primary:e.blueberry400,secondary:e.blackberry100,tertiary:e.blackberry400,error:e.cherry400,highlight:e.blueberry400,bodyCopy:e.black400,bodyBackground:e.lightGrey400,fontFamily:"Barlow, sans-serif"},g={allocated:e.kiwi100,active:e.kiwi400,upcoming:e.blueberry400,completed:e.darkGrey400,succeeded:e.kiwi400,final:e.kiwi400,pending:e.pineapple400,inProgress:e.cyan_outlier,cancelled:e.cherry400,failed:e.cherry400,abandoned:e.cherry400,live:e.grape400,archived:e.darkGrey400},y={easeInOutCirc:"cubic-bezier(0.785, 0.135, 0.15, 0.86)",easeOutExpo:"cubic-bezier(0.19, 1, 0.22, 1)"},p={buttonPrimary:e.blueberry400,buttonPrimaryHover:e.blueberry400,buttonPrimaryColor:e.white400,buttonPrimaryHoverColor:e.white400,buttonSecondary:e.blackberry100,buttonSecondaryHover:e.grape400,buttonSecondaryColor:e.blackberry400,buttonSecondaryHoverColor:e.white400,buttonTertiary:e.blackberry400,buttonTertiaryHover:e.blackberry400,buttonTertiaryColor:e.white400,buttonTertiaryHoverColor:e.white400,buttonQuaternary:e.blueberry100,buttonQuaternaryHover:e.blueberry400,buttonQuaternaryColor:e.blueberry400,buttonQuaternaryHoverColor:e.white400,buttonQuinary:e.lightGrey400,buttonQuinaryHover:e.grey400,buttonQuinaryColor:e.black400,buttonQuinaryHoverColor:e.black400,buttonSenary:e.pineapple400,buttonSenaryHover:e.black400,buttonSenaryColor:e.black400,buttonSenaryHoverColor:e.white400,buttonSeptenary:e.black400,buttonSeptenaryHover:e.pineapple400,buttonSeptenaryColor:e.white400,buttonSeptenaryHoverColor:e.black400,buttonWhite:e.white400,buttonWhiteHover:e.blackberry200,buttonWhiteColor:e.blackberry400,buttonWhiteHoverColor:e.blackberry400,buttonText:"transparent",buttonTextHover:void 0,buttonTextColor:e.darkGrey400,buttonTextHoverColor:e.black400,buttonError:e.black400,buttonErrorHover:e.cherry400,buttonErrorColor:e.white400,buttonErrorHoverColor:e.white400,buttonFontWeight:"600",buttonPaddingExtraSmall:"0.375rem 0.75rem",buttonPaddingSmall:"0.5rem 1rem",buttonPadding:"0.5rem 1rem",buttonPaddingWide:"0.5rem 1.5rem",buttonPaddingLarge:"0.75rem 2rem",buttonPaddingTabletExtraSmall:"0.375rem 0.75rem",buttonPaddingTabletSmall:"0.5rem 1rem",buttonPaddingTablet:"0.625rem 1.5rem",buttonPaddingTabletWide:"0.625rem 2.5rem",buttonPaddingTabletLarge:"0.75rem 2rem"},f={successBackground:e.kiwi100,successHighlight:e.kiwi400,errorBackground:e.cherry100,errorHighlight:e.cherry400,warningBackground:e.pineapple400,warningHighlight:e.black400,emptyBackground:e.lightGrey400,emptyHighlight:e.darkGrey400,infoHighlight:e.blueberry400,infoBackground:e.blueberry100},k={ladderTableHeaderBackground:e.blackberry100,ladderTableHeaderColor:e.blackberry400,ladderTableRowBackground:e.lightGrey400,ladderTableRowHighlight:e.grape100,ladderSwitchBackground:e.darkGrey400},h={paginationBackground:e.blackberry100,paginationItemBackground:e.blackberry400,paginationColor:e.blackberry400},$={inputBorderRadius:"3px",inputDisabledBackground:e.lightGrey400,inputDisabledBorder:e.grey400,inputEmptyBorder:e.grey400,inputFullBorder:e.black400,placeholder:e.darkGrey400,selectArrow:e.grey400,selectArrowTouched:e.blackberry400,selectInputText:e.black400,selectOptionColor:e.black400,fieldFloatingError:"true"},w={none:"0",xxs:"0.125rem",xs:"0.25rem",s:"0.5rem",m:"1rem",l:"1.5rem",xl:"2rem",xxl:"3rem",xxxl:"4rem"},C={8:"0.5rem",10:"0.625rem",12:"0.75rem",14:"0.875rem",16:"1rem",18:"1.125rem",20:"1.25rem",22:"1.375rem",24:"1.5rem",28:"1.75rem",30:"1.875rem",32:"2rem",36:"2.25rem",48:"3rem",50:"3.125rem",72:"4.5rem",80:"5rem"},H={400:400,500:500,600:600,700:700,900:900},T={mobile:480,largeMobile:620,tablet:768,largeTablet:880,laptop:1024,desktop:1244,largeDesktop:1480},S={...p,...m,...$,...k,...f,...h,...g},u={colors:e,spacing:w,fontSizes:C,fontWeights:H,breakpoints:T,...y,...e,...S},v=(...r)=>(...t)=>b`
    @media ${b(...r)} {
      ${b(...t)}
    }
  `;Object.entries(u.breakpoints).reduce((r,[t,i])=>({...r,[t]:v`(min-width: ${i/16}em)`}),{});const B=r=>t=>{var a;return(a=t.theme)!=null&&a.breakpoints?`@media (min-width: ${(typeof r=="number"?r:t.theme.breakpoints[r])/16}rem)`:"&"},x=r=>t=>{var a;return(a=t.theme)!=null&&a.breakpoints?`@media (max-width: ${((typeof r=="number"?r:t.theme.breakpoints[r])-1)/16}rem)`:"&"},P=(r,t)=>i=>{var c;if(!((c=i.theme)!=null&&c.breakpoints))return"&";const a=typeof r=="number"?r:i.theme.breakpoints[r],s=typeof t=="number"?t:i.theme.breakpoints[t];return`@media (min-width: ${a/16}rem) and (max-width: ${(s-1)/16}rem)`},l={up:B,down:x,between:P},n=r=>{if(!!r){if(typeof r=="string"&&r!=="auto")return u.spacing[r];if(typeof r=="string"&&r==="auto")return"auto";if(typeof r=="object"){const t=Object.entries(r).map(([i,a])=>[i,a==="auto"?a:u.spacing[a]]);return Object.fromEntries(t)}}},G=r=>{if(!!r){if(typeof r=="string")return u.colors[r];if(typeof r=="object"){const t=Object.entries(r).map(([i,a])=>[i,u.colors[a]]);return Object.fromEntries(t)}}},d=r=>{if(!r)return;const t=parseInt(r,10);if(!isNaN(t))return`${t/16}rem`},j=r=>{if(!!r){if(typeof r=="string")return d(r);if(typeof r=="object"){const t=Object.entries(r).map(([i,a])=>[i,d(a)]);return Object.fromEntries(t)}}},o=(r,t)=>t===void 0?t:typeof t!="object"?b`
      ${r}: ${t};
    `:b`
    // Base
    ${r}: ${t.base};

    // Mobile
    ${l.up("mobile")} {
      ${r}: ${t.mobile};
    }

    // Large mobile
    ${l.up("largeMobile")} {
      ${r}: ${t.largeMobile};
    }

    // Tablet
    ${l.up("tablet")} {
      ${r}: ${t.tablet};
    }

    // Large tablet
    ${l.up("largeTablet")} {
      ${r}: ${t.largeTablet};
    }

    // Laptop
    ${l.up("laptop")} {
      ${r}: ${t.laptop};
    }

    // Desktop
    ${l.up("desktop")} {
      ${r}: ${t.desktop};
    }

    // Large desktop
    ${l.up("largeDesktop")} {
      ${r}: ${t.largeDesktop};
    }
  `,O=b`
  ${({padding:r})=>o("padding",n(r))};
  ${({paddingX:r})=>b`
    ${o("padding-left",n(r))};
    ${o("padding-right",n(r))};
  `}
  ${({paddingY:r})=>b`
    ${o("padding-top",n(r))};
    ${o("padding-bottom",n(r))};
  `}
${({paddingTop:r})=>o("padding-top",n(r))};
  ${({paddingRight:r})=>o("padding-right",n(r))};
  ${({paddingBottom:r})=>o("padding-bottom",n(r))};
  ${({paddingLeft:r})=>o("padding-left",n(r))};

  ${({margin:r})=>o("margin",n(r))}
  ${({marginX:r})=>b`
    ${o("margin-left",n(r))};
    ${o("margin-right",n(r))};
  `}
${({marginY:r})=>b`
    ${o("margin-top",n(r))};
    ${o("margin-bottom",n(r))};
  `}
${({marginTop:r})=>o("margin-top",n(r))};
  ${({marginRight:r})=>o("margin-right",n(r))};
  ${({marginBottom:r})=>o("margin-bottom",n(r))};
  ${({marginLeft:r})=>o("margin-left",n(r))};
`;export{n as a,j as b,e as c,G as g,l as m,o as r,O as s,u as t};
//# sourceMappingURL=spacing.debe5ff3.js.map
