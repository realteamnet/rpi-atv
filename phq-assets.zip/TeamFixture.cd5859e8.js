import{g as Z,s as d,T as Q,r as b,j as r,_ as G,ah as q,k as x,F as ee,W as te,a6 as ae,a2 as re}from"./vendor.281da1c4.js";import{E as ie,F as oe}from"./EcalButton.aa038122.js";import{dm as se,m as l,a as ne,h as z,dn as me,V as le,d0 as de,f as ce,Y as pe}from"./index.b20384c6.js";import{u as ge}from"./Innings.utils.576b238a.js";import{n as ue}from"./array.16bb7391.js";import{a as fe}from"./FixtureTeam.69799e9e.js";import{s as $}from"./slugify.ec4044c3.js";import"./Pill.57759def.js";import"./isEmpty.72054c5c.js";import"./useGlossary.051e47b6.js";import"./date.02c92264.js";import"./index.a3bca40c.js";import"./index.647f9079.js";import"./index.560c5515.js";import"./index.548bb946.js";import"./number.d970b2c6.js";import"./string.cb8c0e11.js";import"./useRedirectPath.6e9632d7.js";import"./gameTypeValue.1517fa68.js";import"./index.72d6f762.js";import"./index.656026d3.js";import"./CircleIcon.c8c9e429.js";import"./path.c99c5624.js";import"./slugify.e6045279.js";const We=Z`
  query teamFixture($teamID: ID!) {
    discoverTeam(teamID: $teamID) {
      id
      name
      season {
        id
        name
      }
      grade {
        id
        name
      }
      organisation {
        id
        name
      }
    }
    discoverTeamFixture(teamID: $teamID) {
      id
      name
      isStale
      provisionalDates
      grade {
        id
        name
        type
        season {
          id
          name
          competition {
            id
            name
            organisation {
              id
              name
            }
            type
          }
        }
        hideScores
      }
      fixture {
        ...RoundFixtureFragment
      }
    }
    tenantConfiguration {
      label
      gradeTypes {
        value
        isAllPlay
        features {
          hasRounds
          hasSeasonStats
          hasCareerStats
          hasGameStats
          hasFixture
          hasLadder
        }
      }
    }
  }
  ${se}
`,c=d.div.withConfig({componentId:"sc-1pr338c-0"})(["padding:0 1rem;",""],l.tablet`
    padding-left: 2.625rem;
    padding-right: 2.625rem;
  `),he=d.div.withConfig({componentId:"sc-1pr338c-1"})(["padding:0;margin:0;> div:not(:last-of-type){margin-bottom:1rem;}",""],l.tablet`
    > div:not(:last-of-type) {
      margin-bottom: 3rem;
    }
  `),ye=d(c).withConfig({componentId:"sc-1pr338c-2"})(["display:flex;align-items:center;margin:0 1rem;background-color:",";color:",";padding-top:0.5rem;padding-bottom:0.5rem;border-radius:0.5rem;"," .button{margin-left:auto;padding-right:0;font-weight:700;color:",";font-size:0.875rem;text-transform:uppercase;","}"],t=>t.theme.blackberry200,t=>t.theme.blackberry400,l.tablet`
    margin: 0;
    border-radius: 0;
    padding-top: 0.25rem;
    padding-bottom: 0.25rem;
  `,t=>t.theme.blackberry400,l.tablet`
      font-size: 1rem;
    `),be=d(c).withConfig({componentId:"sc-1pr338c-3"})(["display:flex;align-items:center;margin:0 1rem;",""],l.tablet`
    margin: 0;
    padding-top: 0.25rem;
    padding-bottom: 0.25rem;
  `),H=d(c).withConfig({componentId:"sc-1pr338c-4"})(["display:flex;justify-content:",";margin-top:1rem;margin-bottom:2rem;",""],t=>t.$alignRight?"flex-end":"space-between",l.tablet`
  margin-top: 1.5rem;
  margin-bottom: 2.5rem;
`),xe=d(c).withConfig({componentId:"sc-1pr338c-5"})(["margin-top:1rem;",""],l.tablet`
    margin-top: 2rem;
  `),Se=d(Q).attrs({as:"h2"}).withConfig({componentId:"sc-1pr338c-6"})(["color:",";"],t=>t.theme.blackberry400),Te=t=>{var s,f,p,i,m,g;return t&&t.length>0&&((s=t[0])==null?void 0:s.fixture)&&((f=t[0])==null?void 0:f.fixture.games.length)>0&&((i=(p=t[0])==null?void 0:p.fixture.games[0])==null?void 0:i.pool)&&((g=(m=t[0])==null?void 0:m.fixture.games[0])==null?void 0:g.pool.name)||null},Xe=({teamId:t,tenant:s,organisationName:f,competitionSeasonName:p})=>{var D,I,k,E,P,A,L,j,O;const{t:i}=ne(),[m,g]=b.exports.useState("sortedByRound"),M=z("layup-ecal-embed"),S=z("layup-sort-by-date-and-round"),u=b.exports.useRef(null),{data:a,loading:V,error:W}=me({variables:{teamID:String(t)},fetchPolicy:"cache-and-network",onError:()=>null}),{data:T}=ge({variables:{ids:(D=a==null?void 0:a.discoverTeamFixture.map(e=>e.fixture.games.filter(n=>n.status.value===le.InProgress).map(n=>n.id)).flat().filter(ue))!=null?D:[]},context:{endpoint:"spectator",headers:{"X-PHQ-Tenant":(I=a==null?void 0:a.tenantConfiguration)==null?void 0:I.label}},skip:!(a!=null&&a.discoverTeamFixture)});if(b.exports.useEffect(()=>{S&&g(s==="basketball-england"?"sortedByDate":"sortedByRound")},[s,S]),b.exports.useEffect(()=>{u&&u.current&&u.current.scrollIntoView()},[u,a]),V)return r(G,{});if(W||!a||!a.discoverTeamFixture)return r(c,{children:r(q,{variant:"error",children:i("pages.teamfixture.there-was-a-problem-getting-the-fixture-for-the-te")})});const{discoverTeamFixture:h}=a,y=fe({rounds:h,gradeTypesConfiguration:(k=a.tenantConfiguration)==null?void 0:k.gradeTypes,sortByDate:m==="sortedByDate"}),N=h.flatMap(e=>{let n=e.fixture.games.map(w=>({isStale:w.isStale,roundName:e.name}));return e.fixture.byes.length>0&&n.push({isStale:e.isStale,roundName:e.name}),n}),v=N.find(e=>e.isStale===!1),X=v==null?void 0:v.roundName,U=N.some(e=>e.isStale),F=h&&Te(h),R=(E=a.discoverTeam)==null?void 0:E.name,B=(P=a.discoverTeam)==null?void 0:P.organisation.name,Y=(L=(A=a.discoverTeam)==null?void 0:A.grade)==null?void 0:L.name,C=(j=a.discoverTeam)==null?void 0:j.season.name,J=((O=de.find(({slug:e})=>e===s))==null?void 0:O.name)||s;return x(ee,{children:[r(te,{title:i("pages.teamfixture.param0-fixture-for-param1-param2-param3",{param0:R,param1:B,param2:Y,param3:C}),meta:[{name:"description",content:i("pages.teamfixture.view-the-complete-fixture-schedule-for-with-params-in-with-params-with-params-explore-upcoming-matches-and-venues-recent-results-and-stats-for-with-params-competitions-on-playhq",{helmetTeamName:R,helmetOrgName:B,helmetSeasonName:C,tenantName:J})}]}),S&&r(H,{$alignRight:!0,children:x(ae,{name:"outcome",placeholder:"Select outcome",value:m,onChange:e=>g(e.target.value),iconName:m!=="sortedByDate"?"list":"calendar","data-testid":"select-sort",children:[r("option",{value:"sortedByDate",children:i("pages.teamfixture.sort-by-date")},"sortedByDate"),r("option",{value:"sortedByRound",children:i("pages.teamfixture.sort-by-round")},"sortedByRound")]})}),y.length===0&&r(c,{children:r(q,{variant:"empty",children:i("pages.teamfixture.there-is-no-fixture-available-for-this-team")})}),y.length>0&&r(he,{children:y.map((e,n)=>{const w=M&&(y.length===1||e.rounds.some(o=>!o.isStale&&o.fixture.games.length>0));return x("div",{"data-testid":`grade-${e.grade.id}-${n}`,children:[x(ye,{children:[r(Q,{textTransform:"uppercase",weight:"700",children:i(e.grade.name)}),r(re,{as:ce,to:`/${s}/org/${f}/${p}/${$(e.grade.name)}/${e.grade.id}`,variant:"text",icon:"right-arrow-strong",iconPosition:"right",className:"button","data-testid":`grade-${e.grade.id}-button`,children:i("pages.teamfixture.view-grade")})]}),F&&r(be,{children:r(Se,{size:"18",weight:"700",children:i(F)})}),w&&r(H,{children:r(ie,{calendarReference:`${e.grade.id}-team-${t}`})}),e.rounds.map((o,K)=>{var _;return r(xe,{ref:X===o.name&&e.grade.season.competition.type!==pe.Tournament&&U?u:void 0,"aria-label":i("pages.teamfixture.with-params-game-with-params",{gradeName:e.grade.name,gameNumber:K+1}),children:r(oe,{tenant:String(s),organisationNameSlug:$(e.grade.season.competition.organisation.name),competitionSeasonNameSlug:p||"",gradeNameSlug:$(e.grade.name),byes:o.fixture.byes,games:o.fixture.games,gamesLive:T==null?void 0:T.games,roundName:o.name,roundDate:o.date,isStale:(_=o.isStale)!=null?_:!1,isTeamFixture:!0,hideScores:e.grade.hideScores,gradeType:e.gradeType,roundType:o.type,selectedSort:m})},`${o.name}-grade-${e.grade.id}`)})]},`${e.grade.id}-${n}`)})})]})};export{We as TEAM_FIXTURE,Xe as default};
//# sourceMappingURL=TeamFixture.cd5859e8.js.map
