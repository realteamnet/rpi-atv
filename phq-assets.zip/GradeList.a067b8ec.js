import{s as d,r as k,k as l,j as r,ac as D,g as M,a2 as B,m as P,a3 as Q,_ as U,ah as G,W as V,T as f,aj as Y,a0 as N}from"./vendor.281da1c4.js";import{_ as X}from"./List.c6284ff0.js";import{_ as J}from"./ListRow.f26a289f.js";import{_ as K}from"./Pill.57759def.js";import{_ as Z,W as O}from"./WizardStepper.d6b52cac.js";import{m as g,a as W,cS as ee,cT as te,j as H,f as re,cV as ie,i as ae,F as oe,Y as A,o as ne,q as se,a7 as T}from"./index.b20384c6.js";import{O as de}from"./OrganisationPageWrapper.168e07c4.js";import{S as le}from"./SectionContainer.126407a1.js";import{_}from"./Select.d9384d85.js";import{s as R}from"./dayOfTheWeek.062cb823.js";import{a as me}from"./organisation.c289f012.js";import{s as E}from"./slugify.ec4044c3.js";import"./CircleIcon.c8c9e429.js";import"./useGlossary.051e47b6.js";import"./upperFirst.427ac793.js";import"./startCase.d9c4fdfc.js";import"./startCase.b6a27f54.js";import"./array.16bb7391.js";import"./PageHeader.215820c0.js";import"./PageNavigation.81107d24.js";import"./slugify.e6045279.js";const ce=d.form.withConfig({componentId:"sc-wn5aw-0"})(["display:flex;display:grid;grid-gap:0.5rem;grid-template-columns:repeat(auto-fill,1fr);span{padding:0.5rem 2rem 0.5rem 0.5rem;}",""],g.tablet`
    grid-auto-flow: column;
  `),ge=({values:t,setFieldValue:S,setFieldTouched:i,handleSubmit:I,season:y,tenantConfiguration:p,onFilterChange:j,updateQueryParameter:$})=>{const{t:m}=W();k.exports.useEffect(()=>{j()},[t.day,t.gender,t.age]);const x=k.exports.useMemo(()=>y.competition.type==="HOME_AND_AWAY",[y]),c=k.exports.useMemo(()=>y.grades.map(a=>a.day).reduce((a,e)=>{const n=!e&&x?{name:m("forms.gradelistfilterform.multiple-days"),value:"MULTIPLE"}:e;return!n||a.find(s=>s.value===n.value)?a:a.concat(n)},[]).sort((a,e)=>p?R.findIndex(n=>n===a.value)-R.findIndex(n=>n===e.value):0),[x,y]),v=(a,e)=>{S(a,e),$(a,e)};return l(ce,{noValidate:!0,onSubmit:I,children:[t.day!==void 0&&r(D,{name:"day",children:({field:a})=>r(_,{...a,id:a.name,"data-testid":"grade-list-filter-day-field",hideLabel:!0,label:m("forms.gradelistfilterform.label-day"),items:c,placeholder:m("forms.gradelistfilterform.placeholder-all-days"),placeholderSelectable:!0,onChange:e=>v(m(a.name),e),onBlur:()=>i(m(a.name))})}),r(D,{name:"gender",children:({field:a})=>r(_,{...a,id:a.name,"data-testid":"grade-list-filter-gender-field",hideLabel:!0,label:m("forms.gradelistfilterform.label-gender"),items:y.grades.map(e=>e.gender).reduce((e,n)=>!n||e.find(s=>s.value===n.value)?e:[...e,n],[]).sort((e,n)=>{if(!p)return 0;const s=p.competition.genders;return s.findIndex(u=>u.value===e.value)-s.findIndex(u=>u.value===n.value)}),placeholderSelectable:!0,placeholder:m("forms.gradelistfilterform.placeholder-all-genders"),onChange:e=>v(a.name,e),onBlur:()=>i(a.name)})}),r(D,{name:"age",children:({field:a})=>r(_,{...a,id:a.name,"data-testid":"grade-list-filter-age-field",hideLabel:!0,label:m("forms.gradelistfilterform.label-age-group"),items:y.grades.map(e=>e.age).reduce((e,n)=>!n||e.find(s=>s.value===n.value)?e:[...e,n],[]).sort((e,n)=>{if(!p)return 0;const s=p.competition.ageGroups;return s.findIndex(u=>u.value===e.value)-s.findIndex(u=>u.value===n.value)}),placeholderSelectable:!0,placeholder:m("forms.gradelistfilterform.placeholder-all-age-groups"),onChange:e=>v(m(a.name),e),onBlur:()=>i(m(a.name))})})]})},Ne=M`
  query gradeListDiscoverSeason($id: String!) {
    discoverSeason(seasonID: $id) {
      id
      name
      competition {
        id
        name
        type
        organisation {
          ...OrganisationDetails
        }
      }
      status {
        name
        value
      }
      grades {
        id
        name
        day {
          name
          value
        }
        gender {
          name
          value
        }
        age {
          name
          value
        }
      }
    }
    tenantConfiguration {
      label
      competition {
        ageGroups {
          name
          value
        }
        genders {
          name
          value
        }
      }
      ...TenantContactRolesConfiguration
    }
  }
  ${ee}
  ${te}
`,pe=d.div.withConfig({componentId:"sc-1ifg5oj-0"})(["display:flex;flex-direction:column;@supports (display:grid){display:grid;align-items:center;}",""],g.tablet`
    grid-template-columns: 2fr 3fr;
    align-items: start;
    grid-gap: 2.5rem 1rem;

    & > * + * {
      margin-top: 1rem;

      @supports (display: grid) {
        margin-top: 0;
      }
    }
  `),fe=d(H).withConfig({componentId:"sc-1ifg5oj-1"})(["display:grid;grid-gap:2rem;padding-top:2rem;padding-bottom:2rem;"]),ue=d(X).withConfig({componentId:"sc-1ifg5oj-2"})(["width:100%;grid-column:1 / -1;border-left:1px solid ",";border-right:1px solid ",";border-top:1px solid ",";",""],t=>t.theme.bodyBackground,t=>t.theme.bodyBackground,t=>t.theme.bodyBackground,g.tablet`
    border-top: none;
  `),he=d.div.withConfig({componentId:"sc-1ifg5oj-3"})(["display:flex;align-items:center;justify-content:center;height:100%;grid-column:2;grid-row:1 / 5;padding:0.5rem;background-color:",";svg{transition:fill 150ms ease;}",""],t=>t.theme.blackberry100,g.tablet`
    display: none;
  `),q=d(B).withConfig({componentId:"sc-1ifg5oj-4"})(["display:none;",""],g.tablet`
    display: block;
  `),ye=d(J).attrs({as:re}).withConfig({componentId:"sc-1ifg5oj-5"})(["display:flex;word-break:break-word;text-decoration:none;border-bottom:1px solid ",";color:",";& > *:first-child{width:100%;}@supports (display:grid){display:grid;grid-template-columns:1fr auto;}&[href]{transition:background-color 150ms ",";&:hover,&:focus{background-color:",";","{background-color:",";color:",";}}}",""],t=>t.theme.bodyBackground,t=>t.theme.bodyCopy,t=>t.theme.easeInOutCirc,t=>t.theme.blackberry100,q,t=>t.theme.buttonTertiary,t=>t.theme.white400,g.tablet`
    grid-gap: 2rem;
    grid-template-columns: 1fr;
    align-items: center;
    min-height: 3.125rem;
  `),be=d.div.withConfig({componentId:"sc-1ifg5oj-6"})(["display:-ms-grid;display:grid;align-items:center;padding:1rem;",""],g.tablet`
    padding: 0;
    -ms-grid-columns: ${t=>t.isDomestic?"2fr 1fr 1fr 1fr 7.75rem":"2fr 1fr 1fr 7.75rem"};
    grid-template-columns: ${t=>t.isDomestic?"2fr 1fr 1fr 1fr 7.75rem":"2fr 1fr 1fr 7.75rem"};
    grid-gap: 2rem;
    justify-items: start;

    & > * { display:block; }
    & > *:nth-child(2) { -ms-grid-column: 2; }
    & > *:nth-child(3) { -ms-grid-column: 3; }
    & > *:nth-child(4) { -ms-grid-column: 4; }
    & > *:nth-child(5) { -ms-grid-column: 5; }

    & > *:first-of-type {
      padding-left: 1.5rem;
    }
  `),ve=d.li.withConfig({componentId:"sc-1ifg5oj-7"})(["display:none;background-color:",";text-transform:uppercase;color:",";padding:0.5rem 0;align-items:center;border-bottom:1px solid ",";",""],t=>t.theme.grey400,t=>t.theme.darkGrey400,t=>t.theme.bodyBackground,g.tablet`
    display: -ms-grid;
    display: grid;
    -ms-grid-columns: ${t=>t.isDomestic?"2fr 1fr 1fr 1fr 7.75rem":"2fr 1fr 1fr 7.75rem"};
    grid-template-columns: ${t=>t.isDomestic?"2fr 1fr 1fr 1fr 7.75rem":"2fr 1fr 1fr 7.75rem"};
    grid-gap: 2rem;
    justify-items: start;
    padding: 0.5rem 0;

    & > * { display:block; }
    & > *:nth-child(2) { -ms-grid-column: 2; }
    & > *:nth-child(3) { -ms-grid-column: 3; }
    & > *:nth-child(4) { -ms-grid-column: 4; }

    > *:first-of-type {
      padding-left: 1.5rem;
    }
  `),we=d.div.withConfig({componentId:"sc-1ifg5oj-8"})(["display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:1rem;",""],g.tablet`
    margin-bottom: 0;
  `),Ce=d(B).withConfig({componentId:"sc-1ifg5oj-9"})(["margin-left:auto;",""],g.tablet`
    display: none;
  `),Se=d.div.withConfig({componentId:"sc-1ifg5oj-10"})(["display:",";grid-gap:1rem;margin-bottom:2rem;","{display:flex;display:grid;grid-gap:0;justify-items:stretch;grid-auto-flow:column;margin-bottom:0;@supports (display:grid){margin-top:0;align-self:center;}}"],t=>t.visible?"grid":"none",P.up("tablet")),xe=d.div.withConfig({componentId:"sc-1ifg5oj-11"})(["display:flex;flex-direction:column;"]),ke=d.div.withConfig({componentId:"sc-1ifg5oj-12"})(["display:grid;grid-gap:0.25rem;"]),Ie=d(B).withConfig({componentId:"sc-1ifg5oj-13"})(["font-style:italic;color:",";padding:0;span{justify-content:start;}",""],t=>t.theme.darkGrey400,g.tablet`
    padding: 0.5rem 1rem;
  `),je=d.div.withConfig({componentId:"sc-1ifg5oj-14"})(["display:grid;grid-gap:0.5rem;",""],g.tablet`
    grid-gap: 1rem;
    grid-template-columns: auto 1fr;
    align-items: center;
  `),$e=d(le).withConfig({componentId:"sc-1ifg5oj-15"})(["& > ol{padding:2rem;","{padding:0 2rem;}}"],P.up("tablet")),Xe=({seasonId:t,tenant:S})=>{const{t:i}=W(),[I,y]=k.exports.useState([]),{data:p,loading:j,error:$}=ie({variables:{id:String(t)},onError:()=>null}),[m,x]=Q(!1),{queryParams:c,setQueryString:v}=ae(),a=(o,h)=>{v({...c,[o]:h})};if(j)return r(U,{});if($||!p||!p.tenantConfiguration)return r(fe,{children:r(G,{variant:"error",children:i("pages.gradelist.there-was-an-error-retrieving-the-grades-for-this")})});if(!p.discoverSeason)return r(oe,{});const{discoverSeason:e,tenantConfiguration:{contactRoles:n}}=p,s=e.competition.type===A.Domestic||e.competition.type===A.HomeAndAway,u=({day:o,gender:h,age:w})=>{y(e.grades.filter(C=>{var F,L;let b=!0;return o&&C.day&&(b=C.day.value===o),o==="MULTIPLE"&&!C.day&&(b=!0),b&&h&&(b=((F=C.gender)==null?void 0:F.value)===h),b&&w&&(b=((L=C.age)==null?void 0:L.value)===w),!b}))},z=e.grades.filter(o=>!I.some(h=>h.id===o.id));return l(de,{organisation:me(e.competition.organisation,n),tenant:String(S),children:[r(V,{title:i("pages.gradelist.param0-param1-grades-for-param2",{param0:i(e.competition.name),param1:i(e.name),param2:i(e.competition.organisation.name).slice(0,20)}),meta:[{name:"description",content:i("pages.gradelist.meta-description-view-param0s-grades-in-the-param1-param2-season",{param0:i(e.competition.organisation.name),param1:i(e.competition.name),param2:i(e.name)})}]}),r(H,{children:l($e,{noXPadding:!0,children:[l(Z,{backPath:ne(`/${S}/org/${E(e.competition.organisation.name)}/${e.competition.organisation.id}`),children:[r(O,{count:1,children:l(xe,{children:[i("pages.gradelist.select-a-season"),l(f,{size:"14",weight:"400",children:[i(e.competition.name),r("br",{}),i(e.name)]})]})}),r(O,{count:2,highlight:!0,children:i("pages.gradelist.select-a-grade")})]}),r(se,{children:l(pe,{children:[l(we,{children:[l(ke,{children:[r(f,{size:"20",weight:"700",as:"div",children:i(e.competition.name)}),l(je,{children:[r(f,{color:"darkGrey400",children:i(e.name)}),r(K,{variant:e.status.value===T.Active?"active":e.status.value===T.Upcoming?"upcoming":"complete",small:!0,text:i(e.status.name)})]})]}),r(Ce,{onClick:()=>x(),variant:"tertiary",icon:"filter",size:"small",iconSize:"16",halo:!0,children:i("pages.gradelist.filters")})]}),r(Y,{enableReinitialize:!0,initialValues:{day:s?c.day&&typeof c.day=="string"?c.day:"":void 0,age:c.age&&typeof c.age=="string"?c.age:"",gender:c.gender&&typeof c.gender=="string"?c.gender:""},onSubmit:o=>u(o),children:o=>l(Se,{visible:m,children:[r(ge,{...o,season:e,tenantConfiguration:p.tenantConfiguration,onFilterChange:()=>u(o.values),updateQueryParameter:a}),r(Ie,{variant:"text","data-testid":"reset-filters-button",onClick:()=>v({}),size:"small",children:i("pages.gradelist.reset")})]})}),l(ue,{"data-testid":"grades-list",children:[l(ve,{isDomestic:s,children:[r(f,{weight:"700",size:"14",children:i("pages.gradelist.grade")}),s&&r(f,{weight:"700",size:"14",children:i("pages.gradelist.day")}),r(f,{weight:"700",size:"14",children:i("pages.gradelist.gender")}),r(f,{weight:"700",size:"14",children:i("pages.gradelist.age-group")})]},"heading"),e.grades.length===0?r(G,{variant:"empty",children:i("pages.gradelist.there-are-currently-no-grades-for-this-season")}):z.length===0?r(G,{variant:"empty",children:i("pages.gradelist.no-grades-match-your-filters")}):z.map(o=>{var h,w;return r("li",{children:l(ye,{to:`../${E(o.name)}/${o.id}`,"data-testid":`grade-${o.id}-link`,children:[l(be,{isDomestic:s,children:[r(f,{weight:"600",size:"16",children:i(o.name)}),s&&r(f,{color:"darkGrey400",children:o.day?i(o.day.name):i("pages.gradelist.multiple-days")}),r(f,{color:"darkGrey400",children:(h=o.gender)!=null&&h.name?i(o.gender.name):""}),r(f,{color:"darkGrey400",children:(w=o.age)!=null&&w.name?i(o.age.name):""}),r(q,{variant:"tertiary",halo:!0,icon:"right-arrow-strong",iconPosition:"right",iconSize:"12",size:"small",children:i("pages.gradelist.select")})]}),r(he,{children:r(N,{size:"16",name:"right-arrow",color:"blackberry400"})})]})},o.id)})]})]})})]})})]})};export{Ne as DISCOVER_SEASON,Xe as default};
//# sourceMappingURL=GradeList.a067b8ec.js.map
