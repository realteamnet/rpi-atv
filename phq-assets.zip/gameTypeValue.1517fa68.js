var D=(o=>(o.T20="t20",o.OneDay="oneDay",o.TwoDay="twoDay",o))(D||{});const r="overall";export{D as G,r as L};
//# sourceMappingURL=gameTypeValue.1517fa68.js.map
