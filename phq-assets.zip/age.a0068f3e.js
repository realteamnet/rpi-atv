const c=(t,a)=>{var g;const s=((g=a==null?void 0:a.getTime())!=null?g:Date.now())-t.getTime(),o=new Date(s);return Math.abs(o.getUTCFullYear()-1970)},l=(t=18)=>(a,s)=>c(a,s)<t;export{c as a,l as c};
//# sourceMappingURL=age.a0068f3e.js.map
