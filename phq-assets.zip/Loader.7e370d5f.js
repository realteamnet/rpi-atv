import{af as r,s as t,k as a,j as o}from"./vendor.281da1c4.js";const i=r`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,s=r`
0% {
    stroke-dasharray: 1, 200;
    stroke-dashoffset: 0;
  }
  50% {
    stroke-dasharray: 89, 200;
    stroke-dashoffset: -35px;
  }
  100% {
    stroke-dasharray: 89, 200;
    stroke-dashoffset: -124px;
  }
`,n=t.div`
  position: relative;
  margin: ${e=>e.size?e.size/2:3}rem auto;
  width: ${e=>e.size||6}rem;

  &::before {
    content: '';
    display: block;
    padding-top: ${e=>e.size||6}rem;
  }
`,d=t.svg`
  animation: ${i} 2500ms linear infinite;
  height: 100%;
  transform-origin: center center;
  width: 100%;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  margin: auto;
  stroke: ${e=>e.color?e.theme[e.color]:e.theme.primary};
`,c=t.circle`
  stroke-dasharray: 1, 200;
  stroke-dashoffset: 0;
  stroke-linecap: round;
  animation: ${s} 2000ms ease-in-out infinite;
`,l=t.span`
  border: 0;
  clip: rect(0 0 0 0);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  width: 1px;
  white-space: nowrap;
`,h=e=>a(n,{...e,"data-testid":"loader",children:[o(d,{viewBox:"25 25 50 50",color:e.color,children:o(c,{cx:"50",cy:"50",r:"20",fill:"none",strokeWidth:"3",strokeMiterlimit:"10"})}),o(l,{children:"Loading"})]});h.defaultProps={size:6};export{h as L};
//# sourceMappingURL=Loader.7e370d5f.js.map
