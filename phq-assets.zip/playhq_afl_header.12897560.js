const a="/assets/playhq_afl_header.30824f65.jpg";export{a};
//# sourceMappingURL=playhq_afl_header.12897560.js.map
