import{s as e,T as h,k as m,j as t,g as z,_ as B,ah as L,W as _}from"./vendor.281da1c4.js";import{m as i,f as F,a as v,cS as R,cT as q,q as E,dk as P,F as W,o as G}from"./index.b20384c6.js";import{O as N}from"./OrganisationPageWrapper.168e07c4.js";import{S as U}from"./SectionContainer.126407a1.js";import{T as X,N as C}from"./TabNavigation.dc454599.js";import{_ as k}from"./CircleIcon.c8c9e429.js";import{u as A}from"./useGlossary.051e47b6.js";import{a as H}from"./organisation.c289f012.js";import{s as M}from"./slugify.ec4044c3.js";import"./upperFirst.427ac793.js";import"./startCase.d9c4fdfc.js";import"./startCase.b6a27f54.js";import"./array.16bb7391.js";import"./Pill.57759def.js";import"./PageHeader.215820c0.js";import"./PageNavigation.81107d24.js";import"./slugify.e6045279.js";const Q=e.div.withConfig({componentId:"sc-1ttrao6-0"})(["position:relative;margin-left:1rem;margin-right:1rem;padding-bottom:1.5rem;",";"],i.tablet`
    margin-left: 2.625rem;
    margin-right: 2.625rem;
    padding-bottom: 1.5rem;
  `),V=e.div.withConfig({componentId:"sc-1ttrao6-1"})(["",""],i.desktop`
    position: absolute;
    right: 0;
    top: 0;
  `),$=e(k).withConfig({componentId:"sc-1ttrao6-2"})(["transition:background-color 150ms ",";"],a=>a.theme.easeInOutCirc),J=e(F).withConfig({componentId:"sc-1ttrao6-3"})(["position:absolute;top:2rem;left:0;transform:translateX(-30%);"," &:hover,&:focus{","{background-color:",";}}"],i.desktop`
    transform: translateX(-50%);
  `,$,a=>a.theme.blackberry400),K=e.img.withConfig({componentId:"sc-1ttrao6-4"})(["margin-top:-1.5rem;margin-bottom:0.25rem;width:3.5rem;height:3.5rem;border-radius:50%;",""],i.tablet`
    margin-top: -3rem;
  `),Y=e(k).withConfig({componentId:"sc-1ttrao6-5"})(["margin-top:-1.5rem;margin-bottom:0.25rem;height:3.5rem;width:3.5rem;svg{width:2.25rem;height:2.25rem;}",""],i.tablet`
    margin-top: -3rem;
  `),Z=e(h).withConfig({componentId:"sc-1ttrao6-6"})(["opacity:0.6;"]),tt=e.div.withConfig({componentId:"sc-1ttrao6-7"})(["display:grid;grid-gap:0.25rem;margin-bottom:1.5rem;justify-items:center;",""],i.desktop`
    margin-bottom: 0.5rem;
    max-width: 24rem;
    margin-left: auto;
    margin-right: auto;
  `),at=({logoUrl:a,name:c,subtitle:g,backPath:n,children:d})=>{const{t:o}=v();return m("header",{children:[n&&t(J,{to:n,"data-testid":"back-button","aria-label":"Back",children:t($,{icon:"left-arrow-strong",iconColor:"white400",background:"blueberry400",size:"32"})}),m(Q,{children:[m(tt,{children:[a?t(K,{src:a,alt:o("components.teamheader.alt-team-logo-with-params",{param0:o(c)}),"data-testid":"team-logo"}):t(Y,{icon:"shield-swoosh",size:"48",background:"darkGrey400",iconColor:"white400","data-testid":"team-icon"}),t(h,{size:"20",as:"div",weight:"700",color:"black400","data-testid":"team-header-name",children:o(c)}),g&&t(Z,{as:"div",size:"16",color:"black400",children:o(g)})]}),t(V,{children:d})]})]})},kt=z`
  query discoverTeam($teamID: ID!) {
    discoverTeam(teamID: $teamID) {
      id
      name
      logo {
        sizes {
          url
          dimensions {
            width
            height
          }
        }
      }
      grade {
        id
        name
      }
      season {
        id
        name
        competition {
          id
          name
          organisation {
            id
            name
          }
        }
      }
      organisation {
        ...OrganisationDetails
      }
    }
    tenantConfiguration {
      label
      ...TenantContactRolesConfiguration
    }
  }
  ${R}
  ${q}
`,et=e(E).withConfig({componentId:"sc-1njxcju-0"})(["position:relative;max-width:calc(100vw - 2rem);width:100%;margin:0 auto;&{padding-left:0;padding-right:0;}",""],i.tablet`
    max-width: 60rem;

    /* Overriding box padding */
    padding-top: 1.75rem;
  `),ot=e(U).withConfig({componentId:"sc-1njxcju-1"})(["&{padding-bottom:4.875rem;}"]),$t=({tenant:a,organisationId:c,teamId:g,organisationName:n,competitionSeasonName:d,location:o,children:I})=>{const{t:l}=v(),{data:p,loading:T,error:x}=P({variables:{teamID:String(g)},onError:()=>null}),{ladder:u}=A();if(T)return t(B,{});if(x||!p)return t(L,{variant:"error",children:l("pages.team.there-was-an-error-retrieving-the-team-please-try")});if(!p.discoverTeam||!p.tenantConfiguration)return t(W,{});const{discoverTeam:r,tenantConfiguration:{contactRoles:y}}=p,{grade:f,season:s,organisation:D}=r,{competition:b}=s,w=r.logo&&r.logo.sizes.find(S=>S.dimensions.width===48*2),O=w?w.url:void 0,j=D.type==="CLUB"?`/${a}/org/${n}/${c}/${d}/${s.id}/teams`:f?`/${a}/org/${n}/${d}/${M(f.name)}/${f.id.split("-",1)}`:`/${a}/org/${n}/${d}/${s.id.split("-",1)}`;return m(N,{organisation:H(r.organisation,y),tenant:String(a),children:[t(_,{title:l("pages.team.fixture-and-param0-for-param1",{param0:u.singular,param1:r.name}),meta:[{name:"description",content:l("pages.team.view-with-params-fixture-and-with-params-for-the-with-params-with-params-season",{teamName:r.name,ladderSingular:u.singular.toLowerCase(),competitionName:s.competition.name,seasonName:s.name})}]}),t(ot,{children:m(et,{children:[t(at,{logoUrl:O,name:r.name,subtitle:`${b.organisation.name}, ${b.name}, ${s.name}`,backPath:G(j),children:m(X,{children:[t(C,{to:"","data-testid":"fixture-link","aria-current":o&&o.pathname.includes(r.id)&&o.pathname.split("/").pop()!=="ladder"?"page":void 0,children:t(h,{children:l("pages.team.fixture")})}),t(C,{to:"ladder","data-testid":"ladder-link",children:t(h,{children:u.singular})})]})}),I]})})]})};export{kt as DISCOVER_TEAM,$t as default};
//# sourceMappingURL=Team.c613a152.js.map
