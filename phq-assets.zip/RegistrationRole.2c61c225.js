import{s as v,T as q,A as J,k as S,j as i,F as K,ah as se,ac as W,a$ as Z,a0 as d,a1 as ee,a2 as ie,g as x,r as $,_ as De,aj as Fe,aa as qe,ab as Oe}from"./vendor.281da1c4.js";import{R as Ne}from"./RequestToPlayPendingApprovedModal.8a4708e7.js";import{m as le,aN as r,a as de,h as je,aT as ze,bu as Ge,bv as F,bw as Ae,bx as Me,by as Qe,bz as Be,n as z,bA as te}from"./index.b20384c6.js";import{S as He}from"./SectionContainer.126407a1.js";import{R as Le}from"./RegistrationContext.4a5f2bb3.js";import{_ as Ue}from"./Pill.57759def.js";import{F as re}from"./FeatureFlag.c73a3c81.js";import{u as Ve}from"./useAnalytics.b003ff05.js";import{R as Ye}from"./RegistrationNavigation.61086bd6.js";import{T as Xe,R as Je}from"./RegistrationParticipantDetailsForm.579748ec.js";import{s as Ke}from"./slugify.ec4044c3.js";import"./Modal.ecaadf5a.js";import"./date.02c92264.js";import"./index.a3bca40c.js";import"./index.647f9079.js";import"./index.560c5515.js";import"./index.548bb946.js";import"./number.d970b2c6.js";import"./registrationSession.4d08738e.js";import"./index.93ab3024.js";import"./DatePicker.2aae765d.js";import"./Grid.fd113e74.js";import"./Select.d9384d85.js";import"./TextArea.7c63490b.js";import"./Registration.f6efd8a7.js";import"./index.ea938195.js";import"./index.656026d3.js";import"./useScript.ea85eaab.js";import"./FeedbackAndSupport.6b7330d1.js";import"./OrganisationPageWrapper.168e07c4.js";import"./useGlossary.051e47b6.js";import"./organisation.c289f012.js";import"./startCase.d9c4fdfc.js";import"./startCase.b6a27f54.js";import"./upperFirst.427ac793.js";import"./array.16bb7391.js";import"./PageHeader.215820c0.js";import"./PageNavigation.81107d24.js";import"./track.7bfd3cd8.js";import"./lodash.0c30be5c.js";import"./useRegRoleIdvRequired.6e7658ae.js";import"./RegistrationExternalID.styles.aa41805d.js";import"./Steps.bd35588c.js";import"./List.c6284ff0.js";import"./index.72d6f762.js";import"./AddressInputV2.197ce484.js";import"./debounce.50646d11.js";import"./useRegistrationFeatureFlagOn.541125a5.js";import"./age.a0068f3e.js";import"./ethnicityValueHelpers.a58efba4.js";import"./useOhoEnabledForRoles.5d933fd2.js";import"./string.cb8c0e11.js";import"./ConfirmProfileDetailsModal.95de45be.js";import"./GroupLabel.af6f8af5.js";import"./capitalize.b2fec627.js";import"./MobileNumberInput.8b6fe593.js";import"./MutationErrorNotification.0f51f69d.js";import"./ErrorNotification.2e6bec7f.js";import"./scout.09348d87.js";import"./useLocalisation.a5e65550.js";import"./Icon.a2ddfd25.js";import"./uniq.3eafb518.js";import"./Accordion.321a3777.js";import"./slugify.e6045279.js";const We=v.div.withConfig({componentId:"sc-1kjo09t-0"})(["display:flex;flex-direction:column;> * + *{margin-top:2rem;}"]),ae=v.div.withConfig({componentId:"sc-1kjo09t-1"})(["display:grid;grid-gap:2rem 1rem;"]),Ze=v.input.withConfig({componentId:"sc-1kjo09t-2"})(["left:0;border:0;clip:rect(0 0 0 0);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px;white-space:nowrap;"]),oe=v(Ue).withConfig({componentId:"sc-1kjo09t-3"})(["border-radius:1rem;text-transform:capitalize;letter-spacing:0.05rem;padding:0.5rem 0.75rem;"]),ei=v(q).attrs({as:"label"}).withConfig({componentId:"sc-1kjo09t-4"})(["display:flex;justify-content:space-between;align-items:center;padding:1rem;cursor:pointer;border:1px solid ",";background-color:",";transition:filter 200ms ",",transform 200ms ",";@supports (display:grid){display:grid;grid-template-columns:2.5rem 1fr auto;grid-gap:1rem;}"," "," &:active{filter:none;transform:none;}svg{justify-self:center;}",""],e=>e.theme.inputEmptyBorder,e=>e.theme.white400,e=>e.theme.easeInOutCirc,e=>e.theme.easeInOutCirc,e=>e.error&&`
    border-color: ${e.theme.cherry400};
  `,e=>e.$disabled?J(["background-color:",";border-color:",";color:",";cursor:not-allowed;svg{fill:",";}"],e.theme.lightGrey400,e.theme.grey400,e.theme.darkGrey400,e.theme.darkGrey400):J(["&:hover,&:focus{filter:drop-shadow(0 3px 3px rgba(0,0,0,0.1));transform:translateY(-1px);}"]),le.tablet`
    padding: 1rem 1.5rem;
    grid-gap: 2rem;
  `),ii=v.i.withConfig({componentId:"sc-1kjo09t-5"})(["width:1.5rem;height:1.5rem;border:2px solid ",";display:flex;justify-content:center;align-items:center;border-radius:50%;input:checked + label > &{background-color:",";border-color:",";}input:focus + label > &{box-shadow:0 0 5px 0.25rem ",";}"],e=>e.theme.blackberry400,e=>e.theme.kiwi400,e=>e.theme.kiwi400,e=>e.theme.blackberry200),ti=v.div.withConfig({componentId:"sc-1kjo09t-6"})(["display:flex;flex-direction:column;align-items:center;padding:0 0 1rem;> * + *{margin-top:1rem;}",""],le.tablet`
    padding: 0.5rem 0 1rem;
  `),ri=v.ul.withConfig({componentId:"sc-1kjo09t-7"})(["margin:0;padding:0;list-style-type:none;display:flex;flex-direction:column;> * + *{margin-top:0.5rem;}"]),ai={[r.Player]:"profile",[r.Coach]:"squad-coach",[r.TeamManager]:"squad-manager",[r.Official]:"squad-manager",[r.Volunteer]:"profile",[r.MedicalOfficer]:"injury",[r.BenchPersonnel]:"squad-players",[r.Statistician]:"clipboard",[r.TableOfficial]:"squad-manager",[r.CommitteeBoardMember]:"managers",[r.Coordinator]:"player-coach-manager",[r.Supporter]:"hand-open"},oi=({touched:e,errors:n,onCancel:u,values:T,submitCount:g,isValid:P,registrationUserTypes:I,submitForm:C})=>{const{t:c}=de(),O=Ve();return S("fieldset",{children:[i("legend",{style:{display:"none"},children:c("forms.registrationroleform.aria-label-register-as-a")}),S(We,{children:[i(re,{name:"registration-ui-enhancements",off:S(K,{children:[g>0&&!P&&i(se,{variant:"error",children:c("forms.registrationroleform.there-is-an-issue-with-selecting-what-you-would-li")}),i(q,{as:"legend",size:"22",weight:"700",children:c("forms.registrationroleform.register-as-a")}),i(ae,{children:i(W,{name:"registrationType","aria-label":c("forms.registrationroleform.aria-label-register-as-a"),children:({field:o})=>i(K,{children:i(Z,{touched:e.registrationType,error:n.registrationType,errorId:"registrationType",children:i(ri,{children:I.map(t=>{var y,R;const f=!!((y=t.registrationLimit)!=null&&y.limitReached);return S("li",{children:[i(Ze,{...o,"aria-describedby":n.registrationType&&"registrationType","aria-invalid":!!n.registrationType,touched:e.registrationType,error:n.registrationType,id:`radio-registrationType-${t.value}`,type:"radio",value:t.value,defaultChecked:T.registrationType===t.value,disabled:f,"aria-label":t.value}),S(ei,{htmlFor:`radio-registrationType-${t.value}`,error:!!n.registrationType,"data-testid":`radio-registrationType-${t.value}`,$disabled:f,children:[t.value===r.Player&&i(d,{name:"player-profile-outline",size:"24"}),t.value===r.Coach&&i(d,{name:"coach",size:"24"}),t.value===r.TeamManager&&i(d,{name:"managers",size:"40"}),t.value===r.Official&&i(d,{name:"player-profile-outline",size:"24"}),t.value===r.Volunteer&&i(d,{name:"player-profile-outline",size:"24"}),t.value===r.MedicalOfficer&&i(d,{name:"profile-medical",size:"24"}),t.value===r.TableOfficial&&i(d,{name:"squad-manager",size:"24"}),t.value===r.BenchPersonnel&&i(d,{name:"squad-players",size:"24"}),t.value===r.Statistician&&i(d,{name:"clipboard",size:"24"}),t.value===r.CommitteeBoardMember&&i(d,{name:"managers",size:"40"}),t.value===r.Coordinator&&i(d,{name:"player-coach-manager",size:"40"}),t.value===r.Supporter&&i(d,{name:"hand-open",size:"24"}),i(q,{weight:"600",children:c((R=t.displayName)!=null?R:t.name)}),f?i(oe,{text:c("forms.registrationroleform.full"),background:"black400",color:"white400"}):i(ii,{children:i(d,{name:"tick",color:"white400",size:"8"})})]})]},`usertype-${t.value}`)})})})})})})]}),children:i(ae,{children:i(W,{name:"registrationType",children:({field:o})=>i(Xe,{children:i(Z,{touched:e.registrationType,error:n.registrationType,errorId:"registrationType",children:i(ee,{gap:"m",children:I.map(t=>{var R,p;const f=!!((R=t.registrationLimit)!=null&&R.limitReached),y=T.registrationType===t.value;return i(Je,{...o,"aria-describedby":n.registrationType&&"registrationType","aria-invalid":!!n.registrationType,error:n.registrationType,id:`radio-registrationType-${t.value}`,value:t.value,checked:y,disabled:f,"aria-label":t.value,"data-testid":`radio-registrationType-${t.value}`,children:S(ee,{direction:"row",gap:"m",alignItems:"center",children:[i(d,{name:ai[t.value],size:"24",color:y?"white400":"black400"}),i(q,{weight:"600",color:y?"white400":"black400",children:c((p=t.displayName)!=null?p:t.name)}),f&&i(oe,{small:!0,text:c("forms.registrationroleform.full"),background:"black400",color:"white400"})]})},`usertype-${t.value}`)})})})})})})}),i(re,{name:"registration-ui-enhancements",off:S(ti,{children:[i(ie,{variant:"primary",type:"submit",size:"wide",icon:"right-arrow-strong",iconPosition:"right","data-testid":"continue-button",disabled:I.every(({registrationLimit:o})=>o==null?void 0:o.limitReached),children:c("forms.registrationroleform.continue")}),i(ie,{variant:"quinary",type:"button","data-testid":"cancel-button",onClick:o=>{o.preventDefault(),u()},children:c("forms.registrationroleform.back")})]}),children:i(Ye,{onBack:o=>{o.preventDefault(),u()},onNext:()=>{P&&O("reg:chooseRole_continue_click"),C()},nextDisabled:I.every(({registrationLimit:o})=>o==null?void 0:o.limitReached)})})]})]})},St=x`
  query getPendingTransferRequestForPrimaryProfile(
    $filter: TransferRequestsFilter
  ) {
    account {
      id
      profile {
        id
        transferRequests(filter: $filter) {
          id
        }
      }
    }
  }
`,vt=x`
  query getPendingTransferRequestForExistingDependant(
    $profileID: ID!
    $filter: TransferRequestsFilter
  ) {
    dependantProfile(id: $profileID) {
      id
      transferRequests(filter: $filter) {
        id
      }
    }
  }
`,Tt=x`
  query discoverSeasonRegistration($registrationId: String!) {
    discoverSeasonRegistration(registrationID: $registrationId) {
      id
      registrationUserTypes {
        name
        displayName
        value
        registrationLimit {
          limitReached
        }
      }
    }
  }
`,ni=x`
  fragment RegistrationHistoryFragment on Profile {
    id
    registrationHistory {
      ... on Participant {
        id
        type
        seasonRegistration {
          id
          season {
            ... on DiscoverSeason {
              id
              competition {
                id
              }
            }
            ... on ProgramSeason {
              id
              program {
                id
              }
            }
          }
          organisation {
            id
          }
        }
      }
    }
  }
`,Pt=x`
  query profileRegistrationHistory {
    account {
      id
      profile {
        ...RegistrationHistoryFragment
        dependants {
          ...RegistrationHistoryFragment
        }
      }
    }
  }
  ${ni}
`,ne=e=>qe().shape({registrationType:Oe().oneOf(Object.values(r),e("pages.registrationrole.validation-please-select-a-valid-option")).required(e("pages.registrationrole.validation-please-choose-who-you-want-to-register-as"))}),si=e=>(e==null?void 0:e.__typename)==="DiscoverSeason"?e.competition.id:(e==null?void 0:e.__typename)==="ProgramSeason"?e.program.id:"",kt=({tenant:e,registrationCode:n})=>{var A,M,Q;const{t:u}=de(),T=String(n).split("-")[0],g=$.exports.useContext(Le),P=g.who==="myself",I=g.who==="new-dependant",C=!P&&!I,[c,O]=$.exports.useState(""),[o,t]=$.exports.useState(),[f,y]=$.exports.useState(),[R,p]=$.exports.useState(null),m=je("layup-block-pending-request-to-play"),{data:a,loading:ce,error:ge}=ze({variables:{code:String(T),role:g.registrationType||void 0,skipTenantConfig:!0},onError:()=>null}),pe=ge||!a||!a.registrationSettings,N=si((A=a==null?void 0:a.registrationSettings)==null?void 0:A.season),j=a&&a.registrationSettings&&a.registrationSettings.__typename==="DiscoverRegistration"?a.registrationSettings.organisation.id:"",{data:k,loading:me,error:ue}=Ge({fetchPolicy:"cache-and-network",skip:!P||m,variables:{filter:{competitionID:N,destinationClubID:j,status:F.Pending}},onError:()=>null}),fe=P&&(ue||!k||!k.account||!k.account.profile),{data:E,loading:he,error:ye}=Ae({fetchPolicy:"cache-and-network",skip:!C||m,variables:{profileID:String(g.profileId),filter:{competitionID:N,destinationClubID:j,status:F.Pending}},onError:()=>null}),Re=C&&(ye||!E||!E.dependantProfile),{data:w,loading:be,error:Se}=Me({fetchPolicy:"cache-and-network",variables:{registrationId:String(T)},onError:()=>null}),{data:_,loading:ve,error:Te}=Qe({fetchPolicy:"cache-and-network",onError:()=>null,skip:m}),{refetch:Pe,loading:ke}=Be({skip:!0,onError:s=>y(s)}),Ie=a&&a.registrationSettings&&a.registrationSettings.__typename==="DiscoverRegistration"?`/${e}/org/${Ke(u(a.registrationSettings.organisation.name))}/${a.registrationSettings.organisation.id}/register`:`/${e}/register/${T}`,we=`/${e}/register/${n}/participant/3?type=${c}`,_e=`/${e}/register/${n}/participant/${(M=o==null?void 0:o.registrationCheck)==null?void 0:M.approvedParticipantID}/fees`,Ee=Se||!w||w.discoverSeasonRegistration.registrationUserTypes.length===0;if(ce||be||ke||!m&&me||!m&&he||!m&&ve)return i(De,{});if(pe||Ee||f||!m&&fe||!m&&Re||!m&&Te)return i(se,{variant:"error",children:u("pages.registrationrole.there-was-a-problem-getting-the-participant-detail")});const G={registrationType:g.registrationType||""};return S(He,{noYPadding:!0,noXPadding:!0,children:[i(Fe,{initialValues:G,validationSchema:ne(u),isInitialValid:ne(u).isValidSync(G),onSubmit:async s=>{var B,H,L,U,V,Y;if(O(s.registrationType),g.who==="new-dependant")return z(`/${e}/register/${n}/participant/3?type=${s.registrationType}`);if(m){let l={};try{l=await Pe({input:{role:s.registrationType,registrationCode:String(T),activityID:String(N).split("-")[0],profileID:String(g.profileId),destinationOrganisationID:j}}).then(X=>X.data)}catch{}if(!l||f)return null;t(l);const{alreadyRegisteredToRole:D,transferRequest:h,permitRequest:b}=l.registrationCheck||{};if(D)return p("duplicate-registration");if(s.registrationType===r.Player&&(h==null?void 0:h.status)===F.Approved)return p("transfer-approved");if(s.registrationType===r.Player&&(h==null?void 0:h.status)===F.Pending)return p("transfer-in-progress");if(s.registrationType===r.Player&&(b==null?void 0:b.status)===te.Approved)return p("permit-approved");if(s.registrationType===r.Player&&(b==null?void 0:b.status)===te.Pending)return p("permit-pending")}const $e=s.registrationType===r.Player,xe=k&&k.account&&k.account.profile&&k.account.profile.transferRequests.length>0,Ce=E&&E.dependantProfile&&E.dependantProfile.transferRequests.length>0;if((Y=(V=P?(B=_==null?void 0:_.account)==null?void 0:B.profile:(U=(L=(H=_==null?void 0:_.account)==null?void 0:H.profile)==null?void 0:L.dependants)==null?void 0:U.find(l=>l.id===g.profileId))==null?void 0:V.registrationHistory)==null?void 0:Y.some(l=>{var D,h;return l.__typename==="Participant"&&((D=w.discoverSeasonRegistration.registrationUserTypes.find(b=>b.name===l.type))==null?void 0:D.value)===s.registrationType&&((h=a.registrationSettings)==null?void 0:h.__typename)==="DiscoverRegistration"&&l.seasonRegistration.organisation.id===a.registrationSettings.organisation.id&&l.seasonRegistration.season.id===a.registrationSettings.season.id&&(l.seasonRegistration.season.__typename==="DiscoverSeason"&&a.registrationSettings.season.__typename==="DiscoverSeason"&&l.seasonRegistration.season.competition.id===a.registrationSettings.season.competition.id||l.seasonRegistration.season.__typename==="ProgramSeason"&&a.registrationSettings.season.__typename==="ProgramSeason"&&l.seasonRegistration.season.program.id===a.registrationSettings.season.program.id)}))return p("duplicate-registration");if($e&&(xe||Ce))return p("transfer-pending");z(`/${e}/register/${n}/participant/3?type=${s.registrationType}`)},children:s=>i("form",{onSubmit:s.handleSubmit,children:i(oi,{...s,registrationUserTypes:(w==null?void 0:w.discoverSeasonRegistration.registrationUserTypes)||[],onCancel:()=>z(`/${e}/register/${n}/participant/1`)})})}),!!R&&i(Ne,{type:R,tenant:e,registrationLink:Ie,participantDetailsLink:we,registrationCompleteLink:_e,registrationCheckData:o,registrationType:((Q=a==null?void 0:a.registrationSettings)==null?void 0:Q.season.__typename)==="ProgramSeason"?u("pages.registrationrole.program"):u("pages.registrationrole.competition")})]})};export{Tt as DISCOVER_SEASON_REGISTRATION,vt as GET_PENDING_TRANSFER_REQUEST_FOR_EXISTING_DEPENDANT,St as GET_PENDING_TRANSFER_REQUEST_FOR_PRIMARY_PROFILE,Pt as GET_PROFILE_REGISTRATION_HISTORY,ni as REGISTRATION_HISTORY_FRAGMENT,kt as default};
//# sourceMappingURL=RegistrationRole.2c61c225.js.map
