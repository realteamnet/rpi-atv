import{s as n,A as r,R as i,j as s}from"./vendor.281da1c4.js";const c=n.svg`
  width: ${e=>e.size&&`${parseInt(e.size,10)/16}rem`};
  height: ${e=>e.size&&`${parseInt(e.size,10)/16}rem`};
  ${e=>e.color&&e.theme&&r`
      fill: ${e.theme[e.color]};
      color: ${e.theme[e.color]};
    `}
`,a=i.memo(function({size:t="16",...o}){return s(c,{size:t,...o,children:s("use",{xlinkHref:`#icon_${o.name}`})})});export{a as I};
//# sourceMappingURL=Icon.a2ddfd25.js.map
