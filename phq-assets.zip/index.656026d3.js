import{r as i,t as e}from"./index.647f9079.js";function s(r,t){i(2,arguments);var a=e(r),o=e(t);return a.getTime()<o.getTime()}export{s as i};
//# sourceMappingURL=index.656026d3.js.map
