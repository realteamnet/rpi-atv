import{s as o}from"./vendor.281da1c4.js";import{m as t}from"./index.b20384c6.js";const a=o.section.withConfig({componentId:"sc-1ou63w8-0"})(["display:flex;flex-direction:column;padding:",";"," & > *:not(:last-child){margin-bottom:1rem;","}@supports (display:grid){display:grid;grid-template-columns:100%;grid-gap:1rem;"," & > *:not(:last-child){margin-bottom:0;}}"],i=>`${i.noYPadding?"0":"1rem"} ${i.noXPadding?"0":"1rem"}`,t.desktop`
    padding: ${i=>`${i.noYPadding?"0":"2.5rem"} ${i.noXPadding?"0":"2.5rem"}`};
  `,t.tablet`
      margin-bottom: 1.5rem;
    `,t.tablet`
      grid-gap: 1.5rem;
    `);export{a as S};
//# sourceMappingURL=SectionContainer.126407a1.js.map
