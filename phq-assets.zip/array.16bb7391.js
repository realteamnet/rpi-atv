function n(r){return r!=null}function o(r){return!!r}const t=(r,e)=>typeof r.order=="number"&&typeof e.order=="number"?r.order-e.order:typeof r.order=="number"?-1:typeof e.order=="number"?1:0;export{o as a,n,t as s};
//# sourceMappingURL=array.16bb7391.js.map
