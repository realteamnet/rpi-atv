import{ax as s,r as h,ay as _,aN as y,aO as g,aB as v,aD as $,aC as w,aP as E,aQ as I}from"./vendor.281da1c4.js";var m={},r=s&&s.__importDefault||function(t){return t&&t.__esModule?t:{default:t}};Object.defineProperty(m,"__esModule",{value:!0});const a=r(h.exports),x=E,d=r(_),S=I,B=w,C=r(y),F=r(g),q=r(v),k=r($),D=d.default.div`
  display: flex;
  flex-direction: column;
  position: relative;
`,z=(0,d.default)(F.default)`
  margin-bottom: 0.5rem;
`,L=d.default.div`
  display: block;
  height: 100%;
  width: 100%;
  white-space: nowrap;
  overflow: hidden;
`,N=(0,d.default)(q.default)`
  position: absolute;
  right: 1rem;
  top: 50%;
  transform: translateY(-50%);
  pointer-events: none;
`,f=(0,d.default)(k.default)`
  line-height: normal;
  font-size: 1rem;
  font-family: ${t=>t.theme.fontFamily};
  padding: 1rem 2rem 1rem 1rem;
  width: 100%;
  outline: none;
  border: 1px solid
    ${t=>t.touched&&t.error?t.theme.errorHighlight:t.value?t.theme.inputFullBorder:t.theme.inputEmptyBorder};
  border-radius: ${t=>t.theme.inputBorderRadius};
  transition: border-color 200ms ease;
  color: ${t=>!t.value&&t.theme.placeholder};
  background-color: ${t=>t.theme.white400};

  ${B.mq.up("tablet")} {
    font-size: 1rem;
  }

  &[disabled] {
    background-color: ${t=>t.theme.inputDisabledBackground};
    border-color: ${t=>t.theme.inputDisabledBorder};
    cursor: not-allowed;
  }
`,T=d.default.select`
  appearance: none;
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  padding: 0;
  opacity: 0;
  font-size: 1rem;
  cursor: pointer;

  &:focus {
    ~ ${f} {
      box-shadow: 0 0 5px 0 rgba(0, 0, 0, 0.25);
    }
  }

  &[disabled] {
    cursor: not-allowed;
  }
`,j=({value:t="",placeholder:o="",...e})=>{const b=(0,S.useId)(),i=e.errorId||`${e.id}-error`,n=e.items.find(l=>l.value===t),u=e["data-tooltip-id"]||b,c=e["data-tooltip-content"]||e["data-tip"];return a.default.createElement(C.default,{touched:e.touched,error:e.error,errorId:i,hideError:e.hideError},e.label&&a.default.createElement(z,{hide:e.hideLabel,htmlFor:e.id},typeof e.label=="string"?a.default.createElement(a.default.Fragment,null,e.label,e.required?"*":""):e.label),a.default.createElement(D,{"data-tooltip-id":u,"data-tooltip-content":c},a.default.createElement(T,{id:e.id,name:e.name,placeholder:o,disabled:e.disabled,required:e.required,onBlur:e.onBlur,onChange:l=>e.onChange(l.target.value),value:t,"aria-describedby":e["aria-describedby"]||(e.error?i:void 0),"aria-invalid":!!e.error,"data-testid":e["data-testid"]||"select-value"},a.default.createElement("option",{value:"",disabled:e.required||e.placeholderSelectable===!1},o),e.items.map(l=>a.default.createElement("option",{value:l.value,key:l.value,disabled:l.disabled},l.name||l.value))),a.default.createElement(f,{weight:t?"600":"400",touched:e.touched,error:e.error,value:t,disabled:e.disabled,className:e.className},a.default.createElement(L,null,n?n.displayName||n.name:o),a.default.createElement(N,{name:"down-arrow",size:"8",color:e.arrowColor||(e.touched||t?e.error?"cherry400":"black400":"grey400")}))),c&&a.default.createElement(x.Tooltip,{id:u}))};var O=m.default=j;export{O as _};
//# sourceMappingURL=Select.d9384d85.js.map
