import{s,j as t,k as p,T as g,r as x,ah as _,W as L,a2 as I,_ as S,a0 as j}from"./vendor.281da1c4.js";import{_ as B}from"./List.c6284ff0.js";import{f as E,a as z,a7 as y,m as $,q as G,D as R,e3 as q}from"./index.b20384c6.js";import{_ as A}from"./CircleIcon.c8c9e429.js";import{_ as D}from"./Pill.57759def.js";import{s as O}from"./slugify.ec4044c3.js";import"./slugify.e6045279.js";const P=s.li.withConfig({componentId:"sc-1houyv0-0"})(["padding:0;margin:0;min-height:9rem;"]),F=s(E).withConfig({componentId:"sc-1houyv0-1"})(["display:flex;padding:1rem;height:100%;flex-direction:column;background-color:",";border:1px solid ",";border-radius:3px;color:",";text-decoration:none;will-change:box-shadow,transform;transition:box-shadow 150ms ",",transform 150ms ",";&:hover,&:focus{box-shadow:0 0 14px 0 rgba(39,39,39,0.16);transform:translateY(-2px);}"],n=>n.highlight?n.theme.blackberry200:n.theme.colors.white400,n=>n.theme.grey400,n=>n.theme.black400,n=>n.theme.easeInOutCirc,n=>n.theme.easeInOutCirc),M=s.div.withConfig({componentId:"sc-1houyv0-2"})(["display:flex;align-items:flex-end;width:100%;margin-top:auto;padding-top:0.5rem;"]),N=s.div.withConfig({componentId:"sc-1houyv0-3"})(["margin-left:auto;img{display:flex;width:3rem;height:3rem;border-radius:50%;}"]),Q=({id:n,title:a,description:d,status:i,to:v,images:r})=>{const{t:m}=z(),h=(r==null?void 0:r.find(l=>l.dimensions.width===48))||(r==null?void 0:r[0]);return t(P,{children:p(F,{to:v,highlight:i.value===y.Completed,"data-testid":`team-tile-${n}`,children:[t(g,{weight:"700",children:m(a)}),t(g,{color:"darkGrey400",size:"14",weight:"500",children:m(d)}),p(M,{children:[t(D,{variant:i.value===y.Active?"active":i.value===y.Upcoming?"upcoming":"complete",small:!0,text:m(i.name)}),t(N,{children:r?t("img",{srcSet:r.map(l=>`${l.url} ${l.dimensions.width}w`).join(", "),src:h==null?void 0:h.url,alt:m(a)}):t(A,{icon:"shield-swoosh",size:"48",background:"darkGrey400",iconColor:"white400"})})]})]})})},U=s(B).withConfig({componentId:"sc-1vflz5u-0"})(["display:flex;flex-wrap:wrap;> li{flex-basis:100%;&:nth-child(n + 1){margin-top:1rem;}}"," ",""],$.mobile`
    > li {
      flex-basis: calc((100% - 1rem) / 2);

      /* Reset first row margin */
      &:nth-child(-n + 2) {
        margin-top: 0;
      }

      /* Everything not in the first column */
      &:nth-child(2n) {
        margin-left: 1rem;
      }
    }
  `,$.tablet`
    > li {
      flex-basis: calc((100% - 2rem) / 3);

      /* Reset first row margin */
      &:nth-child(-n + 3) {
        margin-top: 0;
      }

      /* Reset left margin from previous breakpoint */
      &:nth-child(2n) {
        margin-left: 0;
      }

      /* Everything not in the first column */
      &:not(:nth-child(3n - 2)) {
        margin-left: 1rem;
      }
    }
  `),W=s.div.withConfig({componentId:"sc-1vflz5u-1"})(["display:flex;flex-flow:column nowrap;align-items:center;justify-content:center;padding:2rem;"]),Y=s(G).withConfig({componentId:"sc-1vflz5u-2"})(["display:flex;flex-direction:column;gap:2rem;"]),J=s.header.withConfig({componentId:"sc-1vflz5u-3"})(["display:flex;justify-content:space-between;align-items:center;gap:0.5rem;flex-wrap:wrap;"]),K=s.div.withConfig({componentId:"sc-1vflz5u-4"})(["display:flex;gap:0.5rem;flex-wrap:wrap;"]),ie=({location:n,tenantHistory:a,profileId:d})=>{var C,T,k;const{t:i}=z(),{tenant:v}=n?R(n):{tenant:void 0},[r,{loading:m,error:h,data:l}]=q({fetchPolicy:"no-cache"}),[c,b]=x.exports.useState();x.exports.useEffect(()=>{var e,u;!c&&a&&a.length>0&&b(((e=a.find(w=>w.value===v))==null?void 0:e.value)||((u=a[0])==null?void 0:u.value))},[a]),x.exports.useEffect(()=>{c&&r({context:{headers:{tenant:c}}})},[c]);const o=(C=l==null?void 0:l.account)==null?void 0:C.profile,f=(o==null?void 0:o.id)===d?o:((T=o==null?void 0:o.dependants)==null?void 0:T.find(e=>e.id===d))||o;return h?t(_,{variant:"error",children:i("pages.profileteams.there-was-a-problem-getting-your-teams-details-ple")}):p(Y,{children:[t(L,{title:i("pages.profileteams.title-my-teams")}),p(J,{children:[t(g,{as:"h2",weight:"700",size:"20",children:i("pages.profileteams.teams")}),a&&a.length>0&&t(K,{children:a.map(e=>t(I,{size:"small",variant:c===e.value?"primary":"quinary",onClick:()=>b(e.value),style:{pointerEvents:c===e.value?"none":"revert"},children:t(g,{weight:"400",children:i(e.name)})},e.value))})]}),m?t(S,{}):((k=f==null?void 0:f.myTeamsList)==null?void 0:k.results)&&f.myTeamsList.results.length>0?t(U,{children:f.myTeamsList.results.map(e=>{var u,w;return t(Q,{id:e.id,title:i(e.name),description:[i((u=e.grade)==null?void 0:u.name),i(e.season.name)].filter(Boolean).join(" - "),status:e.season.status,to:`/account/my-teams/${c}/${O(i(e.name))}/${e.id}${(o==null?void 0:o.id)!==d?`?id=${d}`:""}`,images:(w=e.logo)==null?void 0:w.sizes},e.id)})}):p(W,{children:[t(j,{name:"shield-outline",size:"40",color:"darkGrey400"}),t(g,{as:"p",color:"darkGrey400",fontStyle:"italic",weight:"400",children:i("pages.profileteams.you-have-not-been-allocated-to-a-team")})]})]})};export{ie as default};
//# sourceMappingURL=ProfileTeams.c67fc538.js.map
