var e={};Object.defineProperty(e,"__esModule",{value:!0});const t=()=>({}).REACT_APP_COGNITO_MOCKS==="true";e.default=t;export{e as i};
//# sourceMappingURL=isAuthMocked.f062bc6a.js.map
