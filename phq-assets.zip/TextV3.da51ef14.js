import{s as o,A as s}from"./vendor.281da1c4.js";import{r as e,b as i,g as a,s as r}from"./spacing.debe5ff3.js";const $=o.span`
  margin: 0;
  ${({size:t})=>e("font-size",i(t))};
  ${({weight:t})=>e("font-weight",t)};
  ${({lineHeight:t})=>e("line-height",t)};
  ${({textAlign:t})=>e("text-align",t)};
  ${({fontStyle:t})=>e("font-style",t)};
  ${({textTransform:t})=>e("text-transform",t)};
  ${({color:t})=>e("color",a(t))};
  ${({family:t})=>e("font-family",t)};
  ${({numberOfLines:t})=>t&&s`
      overflow: hidden;
      display: -webkit-box;
      -webkit-line-clamp: ${t};
      -webkit-box-orient: vertical;
    `};
  ${r}
`;export{$ as T};
//# sourceMappingURL=TextV3.da51ef14.js.map
