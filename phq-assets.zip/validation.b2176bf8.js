import{bp as e,aa as r,ab as o}from"./vendor.281da1c4.js";const m=(t,a)=>Object.keys(t).reduce((s,c)=>typeof a=="function"?(s[c]=a(c),s):(s[c]=a,s),{}),u=t=>e(a=>r(m(a,t))),b=t=>o().matches(/^(\d+)?$/,t),d=t=>o().matches(/^-?\d*\.?\d*$/,t);export{u as Y,b as a,d as b};
//# sourceMappingURL=validation.b2176bf8.js.map
