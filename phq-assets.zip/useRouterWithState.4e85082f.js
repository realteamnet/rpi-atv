import{l as t}from"./vendor.281da1c4.js";import{z as a}from"./index.b20384c6.js";const e=()=>a(),i=()=>t();export{e as a,i as u};
//# sourceMappingURL=useRouterWithState.4e85082f.js.map
