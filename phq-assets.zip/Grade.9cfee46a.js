import{s as r,m as v,T as g,k as s,j as a,g as N,_ as W,ah as _,W as j}from"./vendor.281da1c4.js";import{f as B,a as D,cS as G,cT as A,q as E,m as P,h as z,cW as T,F as X,a0 as H,o as M}from"./index.b20384c6.js";import{_ as Q}from"./CircleIcon.c8c9e429.js";import{N as U}from"./NoMarginText.ae73ace5.js";import{O as V}from"./OrganisationPageWrapper.168e07c4.js";import{S as J}from"./SectionContainer.126407a1.js";import{T as K,N as b}from"./TabNavigation.dc454599.js";import{u as Y}from"./useGlossary.051e47b6.js";import{a as Z}from"./organisation.c289f012.js";import{s as y}from"./slugify.ec4044c3.js";import"./upperFirst.427ac793.js";import"./startCase.d9c4fdfc.js";import"./startCase.b6a27f54.js";import"./array.16bb7391.js";import"./Pill.57759def.js";import"./PageHeader.215820c0.js";import"./PageNavigation.81107d24.js";import"./slugify.e6045279.js";const aa=r.div.withConfig({componentId:"sc-1yvcp66-0"})(["padding-left:1rem;padding-right:1rem;padding-bottom:1rem;","{display:flex;justify-content:space-between;align-items:flex-start;padding-left:2.625rem;padding-right:2.625rem;padding-bottom:2.375rem;}"],v.up("tablet")),F=r(Q).withConfig({componentId:"sc-1yvcp66-1"})(["transition:background-color 150ms ",";"],n=>n.theme.easeInOutCirc),ta=r(B).withConfig({componentId:"sc-1yvcp66-2"})(["position:absolute;top:2rem;left:0;transform:translateX(-30%);","{transform:translateX(-50%);}&:hover,&:focus{","{background-color:",";}}"],v.up("tablet"),F,n=>n.theme.blackberry400),ea=r(g).withConfig({componentId:"sc-1yvcp66-3"})(["opacity:0.6;"]),ia=r.div.withConfig({componentId:"sc-1yvcp66-4"})(["display:grid;grid-gap:0.5rem;margin-bottom:1rem;align-items:center;justify-content:center;text-align:center;","{margin-bottom:0;align-items:initial;text-align:left;}"],v.up("tablet")),na=({heading:n,subheading:o,backPath:d,children:m})=>{const{t:i}=D();return s("header",{children:[d&&a(ta,{to:d,"aria-label":"Back",children:a(F,{icon:"left-arrow-strong",iconColor:"white400",background:"blueberry400",size:"32"})}),s(aa,{children:[s(ia,{children:[a(U,{size:"20",as:"h2",weight:"700",color:"black400",children:i(n)}),o&&a(ea,{as:"div",size:"16",color:"black400",children:i(o)})]}),a("div",{children:m})]})]})},Da=N`
  query discoverGrade($gradeID: ID!) {
    discoverGrade(gradeID: $gradeID) {
      id
      name
      type
      season {
        id
        name
        competition {
          id
          name
          organisation {
            ...OrganisationDetails
          }
        }
      }
    }
    tenantConfiguration {
      label
      statistics {
        enabled
      }
      ...TenantContactRolesConfiguration
      gradeTypes {
        value
        isAllPlay
        features {
          hasRounds
          hasSeasonStats
          hasCareerStats
          hasGameStats
          hasFixture
          hasLadder
        }
      }
    }
  }
  ${G}
  ${A}
`,ra=r(E).withConfig({componentId:"sc-116q0pi-0"})(["position:relative;max-width:calc(100vw - 2rem);width:100%;margin:0 auto;&{padding-left:0;padding-right:0;}",""],P.tablet`
    max-width: 60rem;

    /* Overriding box padding */
    padding-top: 1.75rem;
  `),oa=r(J).withConfig({componentId:"sc-116q0pi-1"})(["&{padding-bottom:4.875rem;}"]),Fa=({gradeId:n,location:o,children:d,tenant:m})=>{var x,w,I,k,S;const{t:i}=D(),$=z("layup-hide-grade-stats"),{data:c,loading:O,error:L}=T({variables:{gradeID:String(n)},onError:()=>null}),{ladder:p}=Y();if(O)return a(W,{});if(L||!c||!c.tenantConfiguration)return a(_,{variant:"error",children:i("pages.grade.there-was-an-error-retrieving-the-grade-for-this-s")});if(!c.discoverGrade)return a(X,{});const{discoverGrade:e,tenantConfiguration:{contactRoles:R,statistics:h,gradeTypes:f}}=c,t=f==null?void 0:f.find(({value:u})=>{var l;return u===((l=e==null?void 0:e.type)!=null?l:H.Regular)}),C=!$&&(h==null?void 0:h.enabled)&&((x=t==null?void 0:t.features)==null?void 0:x.hasGameStats),q=((w=t==null?void 0:t.features)==null?void 0:w.hasFixture)||((I=t==null?void 0:t.features)==null?void 0:I.hasLadder)||C;return s(V,{organisation:Z(e.season.competition.organisation,R),tenant:String(m),children:[a(j,{title:i("pages.grade.param0-fixture-and-param1",{param0:i(e.name),param1:p.singular}),meta:[{name:"description",content:i("pages.grade.meta-description-view-param0-fixture-and-param1-for-the-param2-param3-season",{param0:i(e.name),param1:p.singular.toLowerCase(),param2:i(e.season.competition.name),param3:i(e.season.name)})}]}),a(oa,{children:s(ra,{children:[a(na,{heading:e.name,subheading:`${e.season.competition.name}, ${e.season.name}`,backPath:M(`/${m}/org/${y(e.season.competition.organisation.name)}/${y(e.season.name)}/${e.season.id}`),children:q&&s(K,{children:[((k=t==null?void 0:t.features)==null?void 0:k.hasFixture)&&a(b,{to:"","data-testid":"fixture-link",getProps:({isCurrent:u,isPartiallyCurrent:l})=>({"aria-current":(u||l)&&o&&!o.pathname.endsWith("/ladder")&&!o.pathname.endsWith("/statistics")?"page":void 0}),children:a(g,{children:i("pages.grade.fixture")})}),((S=t==null?void 0:t.features)==null?void 0:S.hasLadder)&&a(b,{to:"ladder","data-testid":"ladder-link",children:a(g,{children:p.singular})}),C&&a(b,{to:"statistics","data-testid":"statistics-link",children:a(g,{children:i("pages.grade.statistics")})})]})}),d]})})]})};export{Da as DISCOVER_GRADE,Fa as default};
//# sourceMappingURL=Grade.9cfee46a.js.map
