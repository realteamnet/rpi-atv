import{s,ah as p,a0 as y,r as S,k as o,j as e,T as f,a2 as h,g as T,_ as x}from"./vendor.281da1c4.js";import{m as $,a as I,T as z,o as A,f as E,h as _,cJ as b,cK as k,aW as D}from"./index.b20384c6.js";import{S as j}from"./SectionContainer.126407a1.js";import{R as P}from"./RegistrationSuccessV2.3444192d.js";import"./Grid.fd113e74.js";import"./AppPromoBanner.4e479361.js";import"./appVariantConfigs.87f80809.js";import"./track.7bfd3cd8.js";import"./lodash.0c30be5c.js";import"./RegistrationContext.4a5f2bb3.js";import"./registrationSession.4d08738e.js";import"./index.93ab3024.js";import"./index.647f9079.js";import"./useAnalytics.b003ff05.js";import"./slugify.ec4044c3.js";import"./slugify.e6045279.js";import"./useIdentityVerificationUrl.2d96276f.js";import"./useProfileIdvRequired.23c058ae.js";import"./useRegRoleIdvRequired.6e7658ae.js";import"./organisation.c289f012.js";import"./startCase.d9c4fdfc.js";import"./startCase.b6a27f54.js";import"./upperFirst.427ac793.js";import"./Accordion.321a3777.js";import"./StackV2.1e9411b4.js";import"./spacing.debe5ff3.js";import"./FailedVerificationAlert.9969b7d2.js";import"./noImage.3eec2646.js";import"./useLocalisation.a5e65550.js";const L=s.div.withConfig({componentId:"sc-2zf64s-0"})(["display:grid;grid-gap:1.5rem;justify-items:center;align-items:center;text-align:center;"]),N=s(p).withConfig({componentId:"sc-2zf64s-1"})(["text-align:left;",""],$.tablet`
    width: 50%;
  `),O=s.div.withConfig({componentId:"sc-2zf64s-2"})(["display:grid;grid-gap:1.5rem;align-items:center;"]),q=s.div.withConfig({componentId:"sc-2zf64s-3"})(["display:grid;grid-gap:1rem;"]),F=s.div.withConfig({componentId:"sc-2zf64s-4"})(["display:grid;align-items:end;justify-content:center;grid-template-columns:auto auto;grid-gap:1rem;"]),B=s(y).withConfig({componentId:"sc-2zf64s-5"})(["margin-bottom:0.5rem;"]),Q=({team:i,registration:a,tenant:c})=>{const{t}=I(),{isWebview:d}=S.exports.useContext(z);return o(L,{children:[e(N,{variant:"success",children:t("components.registrationteamsuccesspanel.thanks-has-been-successfully-registered-with-a-pre-with-params",{param0:t(i.name),param1:i.preferredGrade?t(i.preferredGrade):i.preferredGrade})}),a&&o(O,{children:[o(q,{children:[e(f,{size:"22",weight:"700",children:t("components.registrationteamsuccesspanel.want-to-play-for-with-params",{param0:t(i.name)})}),e(f,{color:"darkGrey400",children:t("components.registrationteamsuccesspanel.join-the-team-as-a-participant-now")})]}),o(F,{children:[e(B,{name:"player-to-team-1",size:"24",color:"darkGrey400"}),e(y,{name:"player-to-team-2",size:"48",color:"darkGrey400"})]}),e(h,{"data-testid":"register-to-team-link",onClick:()=>window.location.assign(A(`/${c}/register/${a.registrationCode}-${i.id}`)),children:t("components.registrationteamsuccesspanel.register")})]}),!d&&e(h,{variant:"text",as:E,to:"/account",children:t("components.registrationteamsuccesspanel.go-to-my-account")})]})},Te=T`
  query seasonRegistrations($seasonId: ID!) {
    seasonRegistrations(seasonID: $seasonId) {
      id
      type
      registrationCode
    }
  }
`,Ie=T`
  query getTeamAndSeasonReg($code: String!, $teamId: ID!) {
    discoverTeam(teamID: $teamId) {
      id
      name
      preferredGrade
    }
    registrationSettings(code: $code) {
      ... on DiscoverSocialTeamRegistration {
        id
        season {
          id
          name
          competition {
            id
            name
            organisation {
              id
              name
            }
          }
        }
      }
    }
  }
`,we=({registrationCode:i,teamId:a,tenant:c})=>{const{t}=I(),d=_("registration-referrals"),{data:r,error:w,loading:l}=b({variables:{teamId:String(a),code:String(i)},onError:()=>null}),[v,{data:u,loading:R,error:C}]=k(),m=(r==null?void 0:r.registrationSettings)&&"season"in r.registrationSettings&&r.registrationSettings.season.id||void 0;if(S.exports.useEffect(()=>{m&&v({variables:{seasonId:m}})},[m]),l||R)return e(x,{});if(w||!r||!r.registrationSettings||!r.discoverTeam)return e(p,{variant:"error",children:t("pages.registrationteamsuccess.there-was-a-problem-getting-the-registration-detai")});const{discoverTeam:g}=r;if(C||!u||!g.preferredGrade)return e(p,{variant:"error",children:t("pages.registrationteamsuccess.there-was-a-problem-getting-the-registration-detai")});const n=u.seasonRegistrations.find(G=>G.type===D.ParticipantToTeam);return d?e(P,{teamRegistrationCode:n==null?void 0:n.registrationCode,discoverTeam:g,discoverTeamLoading:l}):e(j,{noYPadding:!0,noXPadding:!0,children:e(Q,{tenant:String(c),team:g,registration:n})})};export{Te as GET_REGISTRATIONS,Ie as GET_TEAM_AND_SEASON_REG,we as default};
//# sourceMappingURL=RegistrationTeamSuccess.96808c6d.js.map
