const a="change-email-id",e="change-email-email";export{a as C,e as a};
//# sourceMappingURL=changeEmailKey.bdb06ed3.js.map
