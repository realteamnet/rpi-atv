import{s,a0 as C,T as a,a3 as T,k as n,j as t,F as z,g as G,d as R,r as b,ah as I,W as B,a2 as O,_ as E}from"./vendor.281da1c4.js";import{_ as N}from"./List.c6284ff0.js";import{m as w,a as P,aW as q,bK as u,q as A}from"./index.b20384c6.js";import{_ as k}from"./Pill.57759def.js";import{_ as j}from"./ToggleButton.d6f70f8f.js";import{N as D}from"./NoMarginText.ae73ace5.js";import{f as y}from"./date.02c92264.js";import"./index.a3bca40c.js";import"./index.647f9079.js";import"./index.560c5515.js";import"./index.548bb946.js";import"./number.d970b2c6.js";const $={Coach:"coach","Team Manager":"managers",Player:"player-profile-outline",Volunteer:"player-profile-outline","Medical Officer":"profile-medical"},H=s.li.withConfig({componentId:"sc-di9owt-0"})(["border:1px solid ",";border-radius:3px;"],e=>e.theme.inputEmptyBorder),L=s.div.withConfig({componentId:"sc-di9owt-1"})(["display:flex;display:grid;justify-content:space-between;padding:1.5rem;grid-gap:1rem 2rem;grid-template-columns:1fr auto;",""],w.tablet`
    grid-template-columns: 1fr 1fr auto;
  `),F=s.div.withConfig({componentId:"sc-di9owt-2"})(["display:grid;grid-gap:0.5rem 1rem;grid-template-columns:2rem 1fr;grid-column:1 / -1;align-self:start;",""],w.tablet`
    grid-column: 1;
  `),W=s(C).withConfig({componentId:"sc-di9owt-3"})(["grid-row:1 / 6;justify-self:center;"]),Y=s.div.withConfig({componentId:"sc-di9owt-4"})(["grid-column:1;",""],w.tablet`
    grid-column: 2;
    text-align: right;
  `),K=s.div.withConfig({componentId:"sc-di9owt-5"})(["grid-column:2;align-self:center;",""],w.tablet`
    grid-column: auto;
  `),Q=s.div.withConfig({componentId:"sc-di9owt-6"})(["display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));grid-gap:2rem;padding:1.5rem;border-top:1px solid ",";background-color:",";border-radius:0 0 3px 3px;"],e=>e.theme.inputEmptyBorder,e=>e.theme.lightGrey400),m=s.div.withConfig({componentId:"sc-di9owt-7"})(["margin-top:1rem;"]),M=s(a).attrs({weight:"600",as:"div"}).withConfig({componentId:"sc-di9owt-8"})(["display:grid;grid-template-columns:auto 1fr;align-items:center;grid-gap:0.5rem;margin-bottom:0.5rem;",""],w.tablet`
    grid-template-columns: 1fr auto;
    justify-items: end;
  `),_=s(k).withConfig({componentId:"sc-di9owt-9"})(["border-radius:1rem;text-transform:unset;font-weight:300;padding:0.5rem 1rem;font-size:1rem;"]),V=({status:e,displayName:i})=>{const{t:o}=P();switch(e){case u.Cancelled:return t(_,{variant:"cancelled","aria-label":o("components.registrationhistoryitem.aria-label-registration-cancelled"),text:o("components.registrationhistoryitem.text-registration-cancelled")});case u.Registered:return t(_,{variant:"active","aria-label":o(i||""),text:o(i||"")});case u.Completed:return t(_,{variant:"complete","aria-label":o(i||""),text:o(i||"")});case u.PendingActivation:case u.PendingRegistration:return t(_,{variant:"pending","aria-label":o("components.registrationhistoryitem.aria-label-registration-pending"),text:o("components.registrationhistoryitem.text-registration-pending")});default:return null}},J=({registration:e})=>{var f;const{t:i}=P(),[o,x]=T(),g=e.__typename==="Participant"?i((f=e.displayName)!=null?f:e.type):i("components.registrationhistoryitem.team"),v=e.__typename==="Participant"?e.registeredAt:e.__typename==="DiscoverTeam"?e.registeredDate:"",h=e.__typename==="Participant"?i(e.teamName||""):e.__typename==="DiscoverTeam"?i(e.name):void 0,d=e.__typename==="Participant"&&e.seasonRegistration,r=e.__typename==="Participant"?e.seasonRegistration.season:e.__typename==="DiscoverTeam"?e.season:void 0,l=(r==null?void 0:r.__typename)==="ProgramSeason"?[i(r.program.name||""),i(r.program.alias||"")].filter(Boolean).join(" - "):(r==null?void 0:r.__typename)==="DiscoverSeason"?i(r.competition.name||""):void 0,p=(r==null?void 0:r.__typename)==="ProgramSeason"?i("components.registrationhistoryitem.program"):(r==null?void 0:r.__typename)==="DiscoverSeason"?i("components.registrationhistoryitem.competition"):void 0;return n(H,{children:[n(L,{children:[n(F,{children:[t(W,{name:$[g]||"team",size:g==="Team Manager"||g==="Team"?"28":"24",color:"blackberry400"}),t(a,{size:"18",weight:"600",color:"blackberry400",children:g}),e.__typename==="Participant"&&e.permit?n(a,{size:"14",color:"black400",as:"div",children:[i("components.registrationhistoryitem.season-permit")," ",t(a,{as:"span",children:y(e.permit.fromDate,"dd MMM yyyy")})," ","-"," ",t(a,{as:"span",children:y(e.permit.toDate,"dd MMM yyyy")})]}):n(a,{size:"14",color:"black400",as:"div",children:[i("components.registrationhistoryitem.registered")," ",v&&t(a,{as:"span",children:y(v,"dd MMM yyyy")})]}),e.__typename==="Participant"&&e.cancelledAt&&n(a,{size:"14",color:"black400",as:"div",children:[i("components.registrationhistoryitem.cancelled")," ",t(a,{as:"span",children:y(e.cancelledAt,"dd MMM yyyy")})]}),p&&t(k,{variant:"complete",text:p}),e.__typename==="Participant"&&e.registrationStatus&&t(V,{status:e.registrationStatus.value,displayName:i(e.registrationStatus.name)})]}),n(Y,{children:[h&&n(M,{children:[t(C,{name:"shield-swoosh"}),h]}),!h&&d&&d.type===q.ParticipantToClub&&n(M,{children:[t(C,{name:"world"}),i(d.organisation.name)]}),(l||(r==null?void 0:r.name))&&n(D,{color:"darkGrey400",as:"p",children:[l&&`${l}, `,r&&i(r.name)]}),(r==null?void 0:r.__typename)==="DiscoverSeason"&&t(D,{color:"darkGrey400",as:"p",children:i(r.competition.organisation.name)}),d&&(r==null?void 0:r.__typename)==="ProgramSeason"&&t(D,{color:"darkGrey400",as:"p",children:i(d.organisation.name)})]}),t(K,{children:t(j,{on:o,onClick:x,"data-testid":`registration-${e.id}-toggle-button`})})]}),o&&n(Q,{"data-testid":`registration-${e.id}-content`,children:[e.__typename==="Participant"&&n(z,{children:[n("div",{children:[t(a,{weight:"600",size:"14",as:"h3",children:i("components.registrationhistoryitem.details-entered-at-the-point-of-registration")}),n(m,{children:[t(a,{color:"darkGrey400",as:"div",size:"14",weight:"600",children:"DOB"}),t(a,{as:"div",children:y(e.dateOfBirth,"dd MMM yyyy")})]}),n(m,{children:[t(a,{color:"darkGrey400",as:"div",size:"14",weight:"600",children:i("components.registrationhistoryitem.gender")}),t(a,{as:"div",children:i(e.gender||"")})]})]}),(e.wwcNumber||e.wwcStateOfIssue||e.wwcExpiryDate)&&n("div",{children:[t(a,{weight:"600",size:"14",as:"h3",children:"WWC"}),n(m,{children:[t(a,{color:"darkGrey400",as:"div",size:"14",weight:"600",children:i("components.registrationhistoryitem.number")}),n(a,{as:"div",children:[e.wwcNumber||"-"," ",e.wwcStateOfIssue||"-"]})]}),n(m,{children:[t(a,{color:"darkGrey400",as:"div",size:"14",weight:"600",children:i("components.registrationhistoryitem.expiry-date")}),e.wwcExpiryDate?t(a,{as:"div",children:y(e.wwcExpiryDate,"dd MMM yyyy")}):t(a,{children:"-"})]})]}),e.coachingAccreditationLevel&&n("div",{children:[t(a,{weight:"600",size:"14",as:"h3",children:i("components.registrationhistoryitem.coaching-accreditation")}),n(m,{children:[t(a,{color:"darkGrey400",as:"div",size:"14",weight:"600",children:i("components.registrationhistoryitem.level")}),t(a,{as:"div",children:e.coachingAccreditationLevel||"-"})]})]}),(e.school||e.schoolYear)&&n("div",{children:[t(a,{weight:"600",size:"14",as:"h3",children:i("components.registrationhistoryitem.additional-questions")}),e.school&&n(m,{children:[t(a,{color:"darkGrey400",as:"div",size:"14",weight:"600",children:i("components.registrationhistoryitem.what-school-does-the-participant-attend")}),t(a,{as:"div",children:e.school})]}),e.schoolYear&&n(m,{children:[t(a,{color:"darkGrey400",as:"div",size:"14",weight:"600",children:i("components.registrationhistoryitem.what-school-year-is-the-participant-in")}),t(a,{as:"div",children:e.schoolYear})]})]}),e.preferredGroup&&n("div",{children:[t(a,{weight:"600",size:"14",as:"h3",children:i("components.registrationhistoryitem.preferred-group")}),t(m,{children:t(a,{as:"div",children:i(e.preferredGroup.name)})})]})]}),e.__typename==="DiscoverTeam"&&t(z,{children:n("div",{children:[t(a,{size:"14",weight:"600",as:"h3",children:i("components.registrationhistoryitem.registration-details")}),n(m,{children:[t(a,{as:"div",size:"14",weight:"600",color:"darkGrey400",children:i("components.registrationhistoryitem.preferred-grade")}),t(a,{as:"div",children:i(e.preferredGrade||"")})]})]})})]})]})},U=G`
  query profileHistory {
    account {
      id
      profile {
        ...HistoryFragment
        dependants {
          ...HistoryFragment
        }
      }
    }
  }

  fragment HistoryFragment on Profile {
    id
    registrationHistory {
      ... on DiscoverTeam {
        id
        name
        preferredGrade
        registeredDate
        season {
          ... on DiscoverSeason {
            id
            name
            competition {
              id
              name
              organisation {
                id
                name
              }
            }
            availableRegistrations {
              id
              type
              registrationCode
            }
          }
        }
      }
      ... on Participant {
        id
        type
        displayName
        gender
        dateOfBirth
        wwcNumber
        wwcExpiryDate
        wwcStateOfIssue
        coachingAccreditationLevel
        teamName
        school
        schoolYear
        seasonRegistration {
          id
          type
          season {
            ... on ProgramSeason {
              id
              name
              program {
                id
                name
                alias
              }
            }
            ... on DiscoverSeason {
              id
              name
              competition {
                id
                name
                organisation {
                  id
                  name
                }
              }
            }
          }
          organisation {
            id
            name
          }
        }
        registeredAt
        cancelledAt
        preferredGroup {
          id
          name
        }
        permit {
          id
          fromDate
          toDate
        }
        registrationStatus {
          name
          value
        }
      }
    }
  }
`,X=s(N).withConfig({componentId:"sc-q1taf8-0"})(["display:flex;flex-direction:column;background-color:",";& > * + *{margin-top:1rem;}"],e=>e.theme.white400),Z=s(A).withConfig({componentId:"sc-q1taf8-1"})(["display:flex;flex-direction:column;gap:2rem;"]),ee=s.header.withConfig({componentId:"sc-q1taf8-2"})(["display:flex;justify-content:space-between;align-items:center;gap:0.5rem;flex-wrap:wrap;"]),te=s.div.withConfig({componentId:"sc-q1taf8-3"})(["display:flex;gap:0.5rem;flex-wrap:wrap;"]),ge=({tenantHistory:e,profileId:i})=>{var f,S;const{t:o}=P(),[x,{loading:g,error:v,data:h}]=R(U,{fetchPolicy:"no-cache"}),[d,r]=b.exports.useState();b.exports.useEffect(()=>{var c;!d&&e&&e.length>0&&r((c=e[0])==null?void 0:c.value)},[e]),b.exports.useEffect(()=>{d&&x({context:{headers:{tenant:d}}})},[d]);const l=(f=h==null?void 0:h.account)==null?void 0:f.profile,p=(l==null?void 0:l.id)===i?l:(S=l==null?void 0:l.dependants)==null?void 0:S.find(c=>c.id===i);return v?t(I,{variant:"error",children:o("pages.profilehistory.there-was-a-problem-getting-your-registration-hist")}):n(Z,{children:[t(B,{title:o("pages.profilehistory.title-registration-history")}),n(ee,{children:[t(a,{as:"h2",weight:"700",size:"20",children:o("pages.profilehistory.registrations")}),e&&e.length>0&&t(te,{children:e.map(c=>t(O,{size:"small",variant:d===c.value?"primary":"quinary",onClick:()=>r(c.value),style:{pointerEvents:d===c.value?"none":"revert"},children:t(a,{weight:"400",children:o(c.name)})},c.value))})]}),g?t(E,{}):(p==null?void 0:p.registrationHistory)&&p.registrationHistory.length>0?t(X,{children:p.registrationHistory.map(c=>t(J,{registration:c},c.id))}):t(I,{variant:"empty",children:o("pages.profilehistory.you-have-no-registrations")})]})};export{U as PROFILE_HISTORY,ge as default};
//# sourceMappingURL=ProfileHistory.fe72b28f.js.map
