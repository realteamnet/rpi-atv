import{ax as d,r as E,ay as y,aN as B,aO as M,aB as $,aD as p,aZ as D,a_ as I}from"./vendor.281da1c4.js";var x={},s=d&&d.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(x,"__esModule",{value:!0});const o=s(E.exports),b=s(y),O=s(B),V=s(M),j=s($),C=s(p),F=(e=!1)=>{const[r,l]=o.default.useState(e);return[r,()=>l(!r)]},A=(0,b.default)(C.default)`
  font-size: 1rem;
  padding: 1rem;
  width: 100%;
  outline: none;
  border: 1px solid
    ${e=>e.touched&&e.error?e.theme.errorHighlight:e.value?e.theme.inputFullBorder:e.theme.inputEmptyBorder};
  transition: border-color 200ms ease;
  border-radius: ${e=>e.theme.inputBorderRadius};

  &::placeholder {
    color: ${e=>e.theme.placeholder};
    font-weight: 400;
  }

  &:focus {
    box-shadow: 0 0 5px 0 rgba(0, 0, 0, 0.25);
  }

  &[disabled] {
    background-color: ${e=>e.theme.inputDisabledBackground};
    border-color: ${e=>e.theme.inputDisabledBorder};
    cursor: not-allowed;
  }
`,R=(0,b.default)(V.default)`
  margin-bottom: 0.5rem;
`,S=b.default.div`
  position: relative;
`,L=b.default.button`
  position: absolute;
  right: 0.75rem;
  top: 50%;
  transform: translateY(-50%);
  background: none;
  border: none;
  padding: 0;
  cursor: pointer;
`,k=({hideLabel:e=!1,hideError:r=!1,required:l=!1,preventAutoComplete:n=!1,...t})=>{const[u,f]=F(!1),v=`${t.id}-error`,P=!!t.error&&!!t.touched&&!r;return o.default.createElement(O.default,{touched:t.touched,error:t.error,errorId:v,className:t.className,hideError:r},o.default.createElement(R,{htmlFor:t.id,hide:e},t.label,l?"*":""),o.default.createElement(S,null,o.default.createElement(A,{as:"input",weight:t.value?"700":"400","data-testid":t["data-testid"]||"input","aria-describedby":P?v:void 0,"aria-invalid":!!t.error,value:t.value,touched:t.touched,error:t.error,onBlur:t.onBlur,onChange:t.onChange,placeholder:t.placeholder,label:t.label,id:t.id,name:t.name,type:u?"text":"password",autoComplete:n?"chrome-off":"",disabled:t.disabled,maxLength:t.maxLength,inputMode:t.inputMode,autoFocus:t.autoFocus}),t.value&&o.default.createElement(L,{type:"button","data-testid":"password-reveal-button",onMouseDown:()=>f(),onClick:()=>f()},o.default.createElement(j.default,{name:u?"hidden":"visible",color:"darkGrey400",size:"16","aria-label":u?"Hide password":"Show password"}))))};var W=x.default=k,_={};const z=D(I);var T=d&&d.__createBinding||(Object.create?function(e,r,l,n){n===void 0&&(n=l);var t=Object.getOwnPropertyDescriptor(r,l);(!t||("get"in t?!r.__esModule:t.writable||t.configurable))&&(t={enumerable:!0,get:function(){return r[l]}}),Object.defineProperty(e,n,t)}:function(e,r,l,n){n===void 0&&(n=l),e[n]=r[l]}),q=d&&d.__setModuleDefault||(Object.create?function(e,r){Object.defineProperty(e,"default",{enumerable:!0,value:r})}:function(e,r){e.default=r}),N=d&&d.__importStar||function(e){if(e&&e.__esModule)return e;var r={};if(e!=null)for(var l in e)l!=="default"&&Object.prototype.hasOwnProperty.call(e,l)&&T(r,e,l);return q(r,e),r},w=d&&d.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(_,"__esModule",{value:!0});var H=_.passwordValidationRule=void 0;const a=w(E.exports),c=w(y),Z=N(z),G=w($),i=w(p),Y=c.default.div`
  border: 1px solid ${e=>e.theme.inputEmptyBorder};
  border-radius: ${e=>e.theme.inputBorderRadius};
  padding: 1rem;
`,J=c.default.ul`
  list-style-type: none;
  padding: 0;
  margin: 0;
`,m=c.default.li`
  display: flex;
  margin-bottom: 0.5rem;

  &:last-of-type {
    margin-bottom: 0;
  }
`,h=c.default.div`
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: 50%;
  background-color: ${e=>e.valid?e.theme.kiwi400:e.theme.errorHighlight};
  height: 1.5rem;
  width: 1.5rem;
  margin-right: 1rem;
  flex-shrink: 0;
`,g=(0,c.default)(G.default).attrs({size:"8",color:"white400"})`
  /* EMPTY */
`,K=(0,c.default)(i.default)`
  display: block;
  margin-bottom: 1rem;
`;H=_.passwordValidationRule=Z.string().matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*>_()<\-\\/`~#%^:;"',.{}[\]|?&])[A-Za-z\d@$!%*>_()<\-\\/`~#%^:;"',.{}[\]|?&]{8,}$/,"Password must be at least 8 characters long and have at least 1 uppercase letter, 1 lowercase letter, 1 number, and 1 special character.").required("Password is required");const Q=({value:e,className:r})=>{const l=e.length>=8,n=/[A-Z]/g.test(e),t=/[a-z]/g.test(e),u=/[\d]/g.test(e),f=/[@$!%*>_()<\-\\/`~#%^:;"',.{}[\]|?&]/g.test(e);return a.default.createElement(Y,{className:r,"data-testid":"password-validator"},a.default.createElement(K,null,"Password must meet the following requirements:"),a.default.createElement(J,null,a.default.createElement(m,null,a.default.createElement(h,{valid:n},a.default.createElement(g,{name:n?"tick":"cross","data-testid":"uppercase-validation-icon"})),a.default.createElement(i.default,{weight:"500"},"At least 1 uppercase letter")),a.default.createElement(m,null,a.default.createElement(h,{valid:t},a.default.createElement(g,{name:t?"tick":"cross","data-testid":"lowercase-validation-icon"})),a.default.createElement(i.default,{weight:"500"},"At least 1 lowercase letter")),a.default.createElement(m,null,a.default.createElement(h,{valid:u},a.default.createElement(g,{name:u?"tick":"cross","data-testid":"number-validation-icon"})),a.default.createElement(i.default,{weight:"500"},"At least 1 number")),a.default.createElement(m,null,a.default.createElement(h,{valid:f},a.default.createElement(g,{name:f?"tick":"cross","data-testid":"special-character-validation-icon"})),a.default.createElement(i.default,{weight:"500"},"At least 1 special character"," ",a.default.createElement(i.default,{color:"darkGrey400",weight:"400"},"(excluding + or =)"))),a.default.createElement(m,null,a.default.createElement(h,{valid:l},a.default.createElement(g,{name:l?"tick":"cross","data-testid":"length-validation-icon"})),a.default.createElement(i.default,{weight:"500"},"Be at least 8 characters"))))};var X=_.default=Q;export{X as _,W as a,H as p};
//# sourceMappingURL=PasswordValidator.7ece7fcb.js.map
