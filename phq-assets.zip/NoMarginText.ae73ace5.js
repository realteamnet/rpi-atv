import{s as o,T as t}from"./vendor.281da1c4.js";const n=o(t).withConfig({componentId:"sc-1yvkkpo-0"})(["margin:0;"]);export{n as N};
//# sourceMappingURL=NoMarginText.ae73ace5.js.map
