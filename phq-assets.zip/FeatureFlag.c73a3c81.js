import{aY as u}from"./index.b20384c6.js";import{j as t,F as e}from"./vendor.281da1c4.js";const i=({attributes:a,name:n,children:s,off:r})=>{const[o]=u(n,a);return o==="on"?t(e,{children:s}):r?t(e,{children:r}):null};export{i as F};
//# sourceMappingURL=FeatureFlag.c73a3c81.js.map
