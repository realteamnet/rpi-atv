import{ax as l,r as _,ay as m,bh as y,aB as b}from"./vendor.281da1c4.js";var s={},g=l&&l.__createBinding||(Object.create?function(e,t,a,n){n===void 0&&(n=a);var r=Object.getOwnPropertyDescriptor(t,a);(!r||("get"in r?!t.__esModule:r.writable||r.configurable))&&(r={enumerable:!0,get:function(){return t[a]}}),Object.defineProperty(e,n,r)}:function(e,t,a,n){n===void 0&&(n=a),e[n]=t[a]}),v=l&&l.__setModuleDefault||(Object.create?function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}:function(e,t){e.default=t}),O=l&&l.__importStar||function(e){if(e&&e.__esModule)return e;var t={};if(e!=null)for(var a in e)a!=="default"&&Object.prototype.hasOwnProperty.call(e,a)&&g(t,e,a);return v(t,e),t},u=l&&l.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(s,"__esModule",{value:!0});const o=u(_.exports),i=O(m),h=u(y),c=u(b),j=(0,i.keyframes)`
  0% {
    opacity: 1;
  }
  50% {
    opacity: 1;
  }
  100% {
    opacity: 0;
    transform: rotate(90deg);
  }
`,w=(0,i.keyframes)`
  0% {
    opacity: 0;
  }
  50% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
`,B=(0,i.default)(c.default)`
  opacity: 0;
  position: absolute;
  animation: ${j} 350ms ease;
  transition: fill 175ms ease;
`,M=(0,i.default)(c.default)`
  animation: ${w} 350ms ease;
  transition: fill 175ms ease;
`,P=(0,i.default)(c.default)`
  transition: fill 175ms ease;
`,x=(0,i.default)(h.default)`
  padding: 0.5rem;
`,E=i.default.span`
  border: 0;
  clip: rect(0 0 0 0);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  width: 1px;
  white-space: nowrap;
`,D=({on:e,onClick:t,label:a,openIconColor:n="white400",closedIconColor:r="blackberry400",openVariant:f="tertiary",closedVariant:d="quinary",...p})=>o.default.createElement(x,{variant:e?f:d,size:"small",onClick:t,...p},e?o.default.createElement(o.default.Fragment,null,o.default.createElement(B,{color:r,name:"plus"}),o.default.createElement(M,{color:n,name:"minus"})):o.default.createElement(P,{color:r,name:"plus"}),a&&o.default.createElement(E,null,a));var $=s.default=D;export{$ as _};
//# sourceMappingURL=ToggleButton.d6f70f8f.js.map
