import{R as a,j as o}from"./vendor.281da1c4.js";const r=a.createContext({team:void 0}),m=({team:e,children:t})=>o(r.Provider,{value:{team:e},children:t});export{r as M,m as a};
//# sourceMappingURL=MyTeamsContext.d697bf2a.js.map
