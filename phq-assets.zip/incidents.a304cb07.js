import{af as e}from"./index.b20384c6.js";import{i as t}from"./vendor.281da1c4.js";const o=[{value:e.Concussion,name:t.t("utils.incidents.injury-concussion")}],r=n=>{var i;return n&&((i=o.find(({value:s})=>s===n))==null?void 0:i.name)||""};export{r as g,o as i};
//# sourceMappingURL=incidents.a304cb07.js.map
