import{g as G,s as g,T as v,a2 as F,A as x,bD as q,r as C,j as m,_ as H,ah as M,k as c,W as Q,R as A,a0 as V,a3 as X}from"./vendor.281da1c4.js";import{_ as J}from"./Pill.57759def.js";import{i as K}from"./index.ea938195.js";import{i as Y}from"./index.656026d3.js";import{t as $}from"./index.647f9079.js";import{cT as Z,m as D,a as T,dp as ee,cR as S,j as te,aW as _,f as ie}from"./index.b20384c6.js";import{a as ae,O as se}from"./OrganisationPageWrapper.168e07c4.js";import{S as oe}from"./SectionContainer.126407a1.js";import{u as j}from"./useAnalytics.b003ff05.js";import{a as ne}from"./organisation.c289f012.js";import{f}from"./date.02c92264.js";import{z as P}from"./index.72d6f762.js";import"./useGlossary.051e47b6.js";import"./slugify.ec4044c3.js";import"./slugify.e6045279.js";import"./upperFirst.427ac793.js";import"./startCase.d9c4fdfc.js";import"./startCase.b6a27f54.js";import"./array.16bb7391.js";import"./PageHeader.215820c0.js";import"./PageNavigation.81107d24.js";import"./index.a3bca40c.js";import"./index.560c5515.js";import"./index.548bb946.js";import"./number.d970b2c6.js";const qe=G`
  query organisationRegistrations($code: ID!, $codeString: String!) {
    discoverOrganisation(code: $codeString) {
      id
      type
      name
      email
      contactNumber
      websiteUrl
      address {
        id
        line1
        suburb
        postcode
        state
        country
      }
      logo {
        sizes {
          url
          dimensions {
            width
            height
          }
        }
      }
      contacts {
        id
        firstName
        lastName
        position
        email
        phone
      }
      shopVisible
    }
    organisationRegistrations(code: $code) {
      id
      type
      registrationCode
      startDate {
        date
        time
        timezone
      }
      endDate {
        date
        time
        timezone
      }
      season {
        ... on ProgramSeason {
          id
          name
          startDate
          endDate
          program {
            id
            name
            description
            alias
          }
        }
        ... on DiscoverSeason {
          id
          name
          startDate
          endDate
          competition {
            id
            name
          }
        }
      }
      hostOrganisation {
        id
        name
        type
        logo {
          sizes {
            url
            dimensions {
              width
              height
            }
          }
        }
      }
      registrationUserTypes {
        name
        displayName
        value
      }
    }
    tenantConfiguration {
      label
      sport {
        name
      }
      ...TenantContactRolesConfiguration
    }
  }
  ${Z}
`,B=g.section.withConfig({componentId:"sc-xicau3-0"})(["background-color:",";border:solid 1px ",";border-radius:3px;box-shadow:0 8px 20px 0 rgba(0,0,0,0.15);"],a=>a.theme.white400,a=>a.theme.grey400),re=g(v).attrs({as:"h3",color:"blackberry400",weight:"700",textTransform:"uppercase",size:"14"}).withConfig({componentId:"sc-xicau3-1"})(["background-color:",";padding:1rem;margin:0;",""],a=>a.theme.blackberry100,D.tablet`
    padding: 1rem 2.625rem;
  `),de=g.div.withConfig({componentId:"sc-xicau3-2"})(["padding:1rem;",""],D.tablet`
    padding: 1.875rem 2.625rem 2.375rem;
  `),me=g(ae).attrs({weight:"700"}).withConfig({componentId:"sc-xicau3-3"})(["padding:0;margin-top:2.5rem;margin-bottom:1rem;&:first-child{margin-top:0;}"]),ge=g.div.withConfig({componentId:"sc-xicau3-4"})(["& + &{margin-top:1.5rem;}"]),pe=g(v).attrs({size:"18",weight:"700",as:"h2"}).withConfig({componentId:"sc-xicau3-5"})(["margin:0;"]),le=g.section.withConfig({componentId:"sc-xicau3-6"})(["& + &{margin-top:1rem;}"]),ce=g(v).attrs({color:"darkGrey400",weight:"500",as:"p"}).withConfig({componentId:"sc-xicau3-7"})(["margin:0.5rem 0 0;"]),ye=g(B).withConfig({componentId:"sc-xicau3-8"})(["display:grid;grid-gap:1rem;padding:1rem;",""],D.tablet`
    grid-gap: 2.125rem;
    padding: 3rem;
  `),L=g(F).withConfig({componentId:"sc-xicau3-9"})(["display:none;min-width:fit-content;",""],D.tablet`
    display: block;
  `),he=g.div.withConfig({componentId:"sc-xicau3-10"})(["display:flex;justify-content:space-between;align-items:center;padding:0.75rem 1.5rem;border:1px solid ",";text-decoration:none;color:",";transition:background-color 150ms ",";margin:1rem 0;@supports (display:grid){display:grid;grid-template-columns:auto 1fr;grid-gap:1rem;}&:last-child{margin-bottom:0;}.pill,button{grid-column:span 2;}svg{display:block;fill:currentColor;}"," ",""],a=>a.theme.bodyBackground,a=>a.disabled?a.theme.darkGrey400:a.theme.bodyCopy,a=>a.theme.easeInOutCirc,a=>a.disabled?x(["background-color:",";"],a.theme.lightGrey400):x(["&:hover,&:focus{background-color:",";","{background-color:",";color:",";}}"],a.theme.blackberry100,L,a.theme.buttonTertiary,a.theme.white400),D.tablet`
    grid-template-columns: 2rem 2fr 1fr auto;
    align-items: center;

    .pill,
    button {
      grid-column: initial;
    }
  `),ve=a=>a===_.SocialTeamToSeason?"team":a===_.ParticipantProgram?"player-profile-outline":"player-coach-manager",N=a=>a.reduce((t,e)=>{var o;const i=t.findIndex(n=>n.id===e.hostOrganisation.id);if(i!==-1){const n=t[i].activityDetails.findIndex(r=>r.id===(e.season.__typename==="ProgramSeason"?e.season.program.id:e.season.__typename==="DiscoverSeason"?e.season.competition.id:""));if(n!==-1){const r=t[i].activityDetails[n].seasons.findIndex(s=>s.id===e.season.id);return r!==-1?[...t.slice(0,i),{...t[i],activityDetails:[...t[i].activityDetails.slice(0,n),{...t[i].activityDetails[n],seasons:[...t[i].activityDetails[n].seasons.slice(0,r),{...t[i].activityDetails[n].seasons[r],registrations:[...t[i].activityDetails[n].seasons[r].registrations,{id:e.id,type:e.type,code:e.registrationCode,startDate:e.startDate,endDate:e.endDate,registrationUserTypes:e.registrationUserTypes}]},...t[i].activityDetails[n].seasons.slice(r+1)]},...t[i].activityDetails.slice(n+1)]},...t.slice(i+1)]:[...t.slice(0,i),{...t[i],activityDetails:[...t[i].activityDetails.slice(0,n),{...t[i].activityDetails[n],seasons:[...t[i].activityDetails[n].seasons,{id:e.season.id,startDate:e.season.startDate,endDate:e.season.endDate,name:e.season.name,registrations:[{id:e.id,type:e.type,code:e.registrationCode,startDate:e.startDate,endDate:e.endDate,registrationUserTypes:e.registrationUserTypes}]}]},...t[i].activityDetails.slice(n+1)]},...t.slice(i+1)]}return[...t.slice(0,i),{...t[i],activityDetails:[...t[i].activityDetails,{id:e.season.__typename==="ProgramSeason"?e.season.program.id:e.season.__typename==="DiscoverSeason"?e.season.competition.id:"",name:e.season.__typename==="ProgramSeason"?[e.season.program.name,e.season.program.alias].filter(Boolean).join(" - "):e.season.__typename==="DiscoverSeason"?e.season.competition.name:"",description:e.season.__typename==="ProgramSeason"?e.season.program.description:void 0,seasons:[{id:e.season.id,startDate:e.season.startDate,endDate:e.season.endDate,name:e.season.name,registrations:[{id:e.id,type:e.type,code:e.registrationCode,startDate:e.startDate,endDate:e.endDate,registrationUserTypes:e.registrationUserTypes}]}]}]},...t.slice(i+1)]}return[...t,{id:e.hostOrganisation.id,name:e.hostOrganisation.name,type:e.hostOrganisation.type,logo:(o=e.hostOrganisation.logo)!=null?o:void 0,activityDetails:[{id:e.season.__typename==="ProgramSeason"?e.season.program.id:e.season.__typename==="DiscoverSeason"?e.season.competition.id:"",name:e.season.__typename==="ProgramSeason"?[e.season.program.name,e.season.program.alias].filter(Boolean).join(" - "):e.season.__typename==="DiscoverSeason"?e.season.competition.name:"",description:e.season.__typename==="ProgramSeason"?e.season.program.description:void 0,seasons:[{id:e.season.id,startDate:e.season.startDate,endDate:e.season.endDate,name:e.season.name,registrations:[{id:e.id,type:e.type,code:e.registrationCode,startDate:e.startDate,endDate:e.endDate,registrationUserTypes:e.registrationUserTypes}]}]}]}]},[]),fe=g.div.withConfig({componentId:"sc-xicau3-11"})(["margin-top:0.5rem;display:flex;"]),De=g(v).attrs({color:"darkGrey400",as:"p"}).withConfig({componentId:"sc-xicau3-12"})(["margin:0;",""],a=>!a.readMore&&x(["white-space:nowrap;text-overflow:ellipsis;overflow:hidden;"])),U=g(v).attrs({as:"button"}).withConfig({componentId:"sc-xicau3-13"})(["flex-shrink:0;background:none;border:none;padding:0;margin:0 0 0 0.25rem;cursor:pointer;font-family:inherit;line-height:1;text-decoration:underline;&:focus,&:hover{text-decoration:none;}"]),we=({children:a})=>{const{t}=T(),[e,i]=X(!1),[o,n]=C.exports.useState(!1),r=C.exports.useRef(null),s=()=>{const y=e||(r.current?r.current.offsetWidth<r.current.scrollWidth:!1);n(y)};return A.useEffect(()=>(s(),window.addEventListener("resize",s),()=>{window.removeEventListener("resize",s)}),[e]),c(fe,{children:[c(De,{readMore:o&&e,ref:r,children:[a,o&&e&&m(U,{onClick:i,children:t("pages.discoverregistrations.read-less")})]}),o&&!e&&m(U,{onClick:i,children:t("pages.discoverregistrations.read-more")})]})},E=({name:a,organisation:t,hostOrganisations:e,tenant:i})=>{const{t:o}=T(),n=j();return c(B,{"data-testid":`${a.toLowerCase()}-container`,children:[m(re,{children:o(a)}),m(de,{children:e.map(r=>c(A.Fragment,{children:[t&&t.type===S.Club&&r.type===S.Association&&m(me,{name:o(r.name),logo:r.logo}),r.activityDetails.map(s=>c(ge,{children:[m(pe,{children:o(s.name)}),s.description&&m(we,{children:o(s.description)}),s.seasons.map(y=>c(le,{children:[c(ce,{children:[o(y.name)," ",m(v,{color:"grey400",size:"18",children:"\xA0\u2022\xA0"})," ",f(y.startDate,"dd MMM yyyy")," -"," ",f(y.endDate,"dd MMM yyyy")]}),y.registrations.map(d=>{const w=d.type===_.SocialTeamToSeason,h=Y($(new Date),P(`${d.startDate.date}T${d.startDate.time}`,d.startDate.timezone))?"upcoming":K($(new Date),P(`${d.endDate.date}T${d.endDate.time}`,d.endDate.timezone))?"completed":"active",b=d.registrationUserTypes.length>1?d.registrationUserTypes.slice(0,-1).map(p=>{var l;return o((l=p.displayName)!=null?l:p.name)}).join(", ")+` ${o("pages.discoverregistrations.or")} `+d.registrationUserTypes.slice(-1).map(p=>{var l;return o((l=p.displayName)!=null?l:p.name)}).join():d.registrationUserTypes.map(p=>{var l;return o((l=p.displayName)!=null?l:p.name)}).join();return c(he,{disabled:h==="completed"||h==="upcoming",to:"",...h==="active"&&{as:ie,to:`/${i}/register/${d.code}`,"data-testid":`registration-${d.id}-link`},children:[m(V,{name:ve(d.type),size:"28"}),m(v,{size:"16",weight:"600",children:w?o("pages.discoverregistrations.register-a-team"):o("pages.discoverregistrations.register-a-with-params",{param0:b})}),m(J,{variant:h==="upcoming"?"upcoming":h==="completed"?"complete":"active",text:h==="upcoming"?o("pages.discoverregistrations.opens-on-with-params",{param0:f(d.startDate.date,"dd MMM yyyy")}):h==="completed"?o("pages.discoverregistrations.closed-with-params",{param0:f(d.endDate.date,"dd MMM yyyy")}):o("pages.discoverregistrations.open-until-with-params",{param0:f(d.endDate.date,"dd MMM yyyy")}),className:"pill"}),h==="active"&&m(L,{variant:"tertiary",halo:!0,icon:"right-arrow-strong",iconPosition:"right",iconSize:"12",size:"small",onClick:()=>{n("orgpage:register_select_click")},children:o("pages.discoverregistrations.select")})]},d.id)})]},y.id))]},s.id))]},r.id))})]})},He=a=>{var R,k,I,O,z;const{t}=T(),e=j(),{tenant:i,organisationId:o}=q(),{loading:n,error:r,data:s}=ee({variables:{code:String(o),codeString:String(o)},fetchPolicy:"no-cache",onError:()=>null}),y=(I=(k=(R=s==null?void 0:s.tenantConfiguration)==null?void 0:R.sport)==null?void 0:k.name.toLowerCase())!=null?I:"";if(C.exports.useEffect(()=>{e("orgpage:register_view")},[]),n)return m(H,{});if(r||!(s!=null&&s.discoverOrganisation)||!(s!=null&&s.organisationRegistrations))return m(M,{variant:"error",children:t("pages.discoverregistrations.there-was-an-error-loading-the-organisations-regis")});const d=s.organisationRegistrations.length>0,w=s.discoverOrganisation.type===S.Club,h=s.organisationRegistrations.filter(u=>u.season.__typename==="ProgramSeason"),b=s.organisationRegistrations.filter(u=>u.season.__typename==="DiscoverSeason"),p=N(h),l=N(b),W=ne(s.discoverOrganisation,(z=(O=s.tenantConfiguration)==null?void 0:O.contactRoles)!=null?z:[]);return c(se,{tenant:String(i),organisation:W,children:[m(Q,{title:t("pages.discoverregistrations.register-to-param0",{param0:t(s.discoverOrganisation.name)}),meta:[{name:"description",content:t("pages.discoverregistrations.join-param0-through-playhq-register-for-param1-competitions-and-programs-and-start-your-season-with-param2",{param0:t(s.discoverOrganisation.name),param1:y?` ${t(y)}`:"",param2:t(s.discoverOrganisation.name)})}]}),m(te,{children:c(oe,{noXPadding:!0,children:[!d&&c(ye,{children:[m(v,{size:"20",weight:"700",children:t("pages.discoverregistrations.no-registrations-available")}),m(M,{variant:"empty",children:t("pages.discoverregistrations.the-is-not-currently-taking-online-registrations-p-with-params",{param0:t(w?"pages.discoverregistrations.club":"pages.discoverregistrations.association"),param1:" ",param2:t(w?"pages.discoverregistrations.club":"pages.discoverregistrations.association")})})]}),p.length>0&&m(E,{name:t("pages.discoverregistrations.programs"),hostOrganisations:p,tenant:i}),l.length>0&&m(E,{name:t("pages.discoverregistrations.competitions"),organisation:s.discoverOrganisation,hostOrganisations:l,tenant:i})]})})]})};export{qe as ORGANISATION_REGISTRATIONS,He as default};
//# sourceMappingURL=DiscoverRegistrations.dddf1ba3.js.map
