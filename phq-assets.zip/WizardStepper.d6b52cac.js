import{aZ as c,b6 as m,ax as l,r as p,ay as u,aD as f,aC as g}from"./vendor.281da1c4.js";import{C as h}from"./CircleIcon.c8c9e429.js";var i={};const b=c(m);var o=l&&l.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(i,"__esModule",{value:!0});var y=i.WizardStep=void 0;const x=b,r=o(p.exports),t=o(u),n=g,_=o(h),$=o(f),k=t.default.section`
  background-color: ${e=>e.theme.white400};
  border: solid 1px ${e=>e.theme.grey400};
  border-radius: 3px;
  padding: ${({noPadding:e})=>!e&&"1rem"};
  box-shadow: 0 8px 20px 0 rgba(0, 0, 0, 0.15);

  ${n.mq.up("tablet")} {
    padding: ${({noPadding:e})=>!e&&"2.375rem 2.625rem"};
  }
`,z=t.default.span`
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 0.75rem;
  padding: 0.35rem;
  border-radius: 1.5rem;
  height: 1.75rem;
  width: 1.75rem;
  font-weight: 700;
  color: ${e=>e.highlight?e.theme.white400:e.theme.darkGrey400};
  background-color: ${e=>e.highlight?e.theme.bodyCopy:e.theme.grey400};
`,w=t.default.li`
  display: flex;
  flex-direction: column;

  ${n.media.tablet`
    flex-direction: row;

    &:not(:first-of-type) {
      margin-top: 0;
    }

    &::before {
      display: block;
    }
  `}
`,C=(0,t.default)($.default).attrs({weight:"600",size:"18"})`
  display: flex;
  align-items: center;
  text-decoration: none;
  line-height: 1.2;

  &[href] {
    transition: transform 150ms ${e=>e.theme.easeInOutCirc};

    &:hover,
    &:focus {
      transform: translateY(-2px);
    }
  }
`,v=t.default.div`
  position: relative;
`,W=(0,t.default)(k).attrs({as:"ol"})`
  display: flex;
  align-items: center;
  min-height: 4.75rem;
  margin: 0;
  padding-top: 1rem;
  padding-bottom: 1rem;
  list-style-type: none;

  > * + * {
    margin-left: 1rem;
  }

  @supports (display: grid) {
    display: grid;
    grid-gap: 0.75rem;

    > * + * {
      margin-left: 0;
    }
  }

  ${n.media.tablet`
    grid-gap: 1rem;
    grid-template-columns: 1fr 1fr 1fr;
    height: 5.375rem;
    padding-top: 0;
    padding-bottom: 0;
  `}
`,d=(0,t.default)(_.default)`
  transition: background-color 150ms ${e=>e.theme.easeInOutCirc};
`,S=(0,t.default)(x.Link)`
  position: absolute;
  top: 0.25rem;
  left: 0;
  transform: translateX(-50%);
  z-index: 1;

  &:hover,
  &:focus {
    ${d} {
      background-color: ${e=>e.theme.blackberry400};
    }
  }

  ${n.media.tablet`
    top: 50%;
    transform: translate(-50%, -50%);
  `}
`,E=({count:e,highlight:a,children:s})=>r.default.createElement(w,{highlight:a},r.default.createElement(C,{color:a?"black400":"darkGrey400","data-testid":`wizard-step-${e}`},r.default.createElement(z,{highlight:a},e),s));y=i.WizardStep=E;const I=({backPath:e,children:a})=>r.default.createElement(v,null,e&&r.default.createElement(S,{to:e,"data-testid":"wizard-stepper-back-link","aria-label":"Back"},r.default.createElement(d,{icon:"left-arrow-strong",iconColor:"white400",background:"blueberry400",size:"32"})),r.default.createElement(W,{"data-testid":"wizard-stepper"},a));var q=i.default=I;export{y as W,q as _};
//# sourceMappingURL=WizardStepper.d6b52cac.js.map
