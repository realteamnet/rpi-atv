import{s as N,T as M,g as ie,r as h,j as o,_ as Se,ah as Te,k as q,W as qe,a2 as _}from"./vendor.281da1c4.js";import{c as Ie}from"./capitalize.b2fec627.js";import{C as $e,D as I}from"./DuplicateProfileCategorySection.03b94f78.js";import{F as xe}from"./FeatureFlag.c73a3c81.js";import{R as Ce}from"./RequestToPlayModal.3d94cac5.js";import{R as we}from"./RequestToPlayPendingApprovedModal.8a4708e7.js";import{m as Ee,a as Ae,h as De,bR as Le,aT as _e,bo as ke,bS as Me,bT as Ne,aH as $,n as g,g as Ge,aN as k,bv as Oe,bA as Ve,bs as Z,bJ as ze,bt as Fe}from"./index.b20384c6.js";import{S as Ue}from"./SectionContainer.126407a1.js";import{R as je}from"./RegistrationContext.4a5f2bb3.js";import{u as Qe}from"./useAnalytics.b003ff05.js";import{u as Be}from"./useIdentityVerificationUrl.2d96276f.js";import{u as He}from"./useProfileIdvRequired.23c058ae.js";import{u as Ye}from"./useRegRoleIdvRequired.6e7658ae.js";import{s as Je}from"./slugify.ec4044c3.js";import{R as We}from"./RegistrationNavigation.61086bd6.js";import{P as Xe}from"./ParticipantDetailsModals.35337641.js";import{g as ee}from"./RegistrationProfilePhotoVerification.utils.7a52a331.js";import"./upperFirst.427ac793.js";import"./CircleIcon.c8c9e429.js";import"./Modal.ecaadf5a.js";import"./date.02c92264.js";import"./index.a3bca40c.js";import"./index.647f9079.js";import"./index.560c5515.js";import"./index.548bb946.js";import"./number.d970b2c6.js";import"./registrationSession.4d08738e.js";import"./index.93ab3024.js";import"./slugify.e6045279.js";const Ke=N(M).withConfig({componentId:"sc-jfgl5v-0"})(["color:",";margin:1.5rem 0 2rem;"],t=>t.theme.darkGrey400),Ze=N.div.withConfig({componentId:"sc-jfgl5v-1"})(["display:flex;flex-direction:column;align-items:center;text-align:center;border:1px solid ",";color:",";padding:2rem;margin-bottom:3rem;gap:1rem;"],t=>t.theme.lightGrey400,t=>t.theme.darkGrey400),ei=N.div.withConfig({componentId:"sc-jfgl5v-2"})(["display:flex;flex-direction:column;align-items:center;padding:0 0 1rem;> * + *{margin-top:1rem;}",""],Ee.tablet`
    padding: 0.5rem 0 1rem;
  `),Ai=ie`
  query getDuplicateProfiles($participantID: ID!, $registrationCode: String!) {
    tenantConfiguration {
      label
      claimProfilesIsMandatory
    }
    participant(id: $participantID) {
      id
      profile {
        id
        duplicateProfiles(registrationCode: $registrationCode) {
          id
          firstName
          lastName
          email
          mobileNumber
          lastRegisteredRole
          lastRegisteredSeason {
            id
            name
          }
          lastRegisteredOrganisation {
            id
            name
          }
          claimability
          isPrivate
          isMigrated
        }
      }
    }
  }
`,Di=ie`
  query getParticipantTransferRequests($participantID: ID!) {
    participant(id: $participantID) {
      id
      type
      transferRequired {
        pendingTransferRequest {
          id
          destinationClub {
            name
          }
        }
        exceptionPeriod {
          id
        }
        hasRegistrationInSameSeason
        transferDeniedReason
      }
      profile {
        id
      }
      seasonRegistration {
        id
        season {
          ... on DiscoverSeason {
            id
            competition {
              id
              organisation {
                id
              }
            }
          }
        }
      }
      status
      clubChangeOptions
    }
    tenantConfiguration {
      transfers {
        transferSettingsOwner
      }
    }
  }
`,Li=({registrationCode:t,participantId:c,tenant:s})=>{const{t:n}=Ae(),re=Qe(),{links:te}=Ge(),oe=De("layup-request-to-play"),[x,G]=h.exports.useState([]),[ne,se]=h.exports.useState(null),[O,V]=h.exports.useState(null),[z,C]=h.exports.useState(null),[ae,le]=h.exports.useState(!1),l=h.exports.useContext(je),[m]=String(t).split("-"),F=Ye({registrationCode:t,role:l.registrationType}),U=He({profileId:ne,isDependant:l.who!=="myself"}),{fetchIdentityVerificationUrlForIdvPage:j}=Be(),{data:p,loading:pe,error:ce}=Le({variables:{participantID:String(c),registrationCode:m},fetchPolicy:"cache-and-network",onCompleted:({participant:e})=>{var i;(i=e.profile)!=null&&i.duplicateProfiles&&G(e.profile.duplicateProfiles.map(({id:a})=>a))}}),{data:f,loading:de,error:fe}=_e({variables:{code:String(m),role:l.registrationType||void 0,skipTenantConfig:!0},onError:()=>null}),ue=fe||!f||!f.registrationSettings,[ge,{loading:me,error:ye}]=ke({onCompleted:async e=>{var b,R,S,T,P,X,K;const{registrationCheck:i}=e;if(l.registrationType===k.Player&&((b=i==null?void 0:i.transferRequest)==null?void 0:b.status)===Oe.Approved)return V("transfer-approved");if(l.registrationType===k.Player&&((R=i==null?void 0:i.permitRequest)==null?void 0:R.status)===Ve.Approved)return V("permit-approved");const a=!!(r!=null&&r.participant.transferRequired),d=(S=r==null?void 0:r.participant.clubChangeOptions)==null?void 0:S.includes(Z.Transfer),y=((T=r==null?void 0:r.participant.transferRequired)==null?void 0:T.transferDeniedReason)===ze.ClubAdminLedPreference||!1,u=!(i!=null&&i.permitRequest)&&((P=r==null?void 0:r.participant.clubChangeOptions)==null?void 0:P.includes(Z.Permit)),v=((X=r==null?void 0:r.tenantConfiguration)==null?void 0:X.transfers.transferSettingsOwner)===Fe.Tenant;return a&&(u||d&&!y&&(v?!(i!=null&&i.transferRequest):!0))?C("required"):a&&!d&&!u&&y&&(v?!(i!=null&&i.transferRequest):!0)?C("admin-led"):a&&(!u&&!d||v&&!!(i!=null&&i.transferRequest))?C("not-accepting"):F&&U&&await j({tenant:s,registrationCode:t,participantId:c})?g(`/${s}/register/${t}/participant/${c}/identity-verification`):l.isPhotoVerificationActive?g(ee({tenant:s,registrationCode:t,participantId:c})):g(`/${s}/register/${t}/participant/${(K=r==null?void 0:r.participant)==null?void 0:K.id}/${l.hasExternalIdStep?"external-id":"fees"}`)}}),[Q,{data:r,loading:w,error:Pe}]=Me({fetchPolicy:"network-only",onCompleted:async({participant:e})=>{var i;if(oe){const a=(i=e==null?void 0:e.profile)==null?void 0:i.id,d=e==null?void 0:e.id,y=(e==null?void 0:e.seasonRegistration.season.__typename)==="DiscoverSeason"?e.seasonRegistration.season.competition.id:void 0,u=(e==null?void 0:e.seasonRegistration.season.__typename)==="DiscoverSeason"?e.seasonRegistration.season.competition.organisation.id:void 0;if(e.type.toUpperCase()==="PLAYER"&&!!a&&!!d&&!!y&&!!u)return ge({variables:{input:{registrationCode:String(m),role:k.Player,profileID:a,participantID:d,activityID:y,destinationOrganisationID:u}}})}return e!=null&&e.transferRequired?le(!0):F&&U&&await j({tenant:s,registrationCode:t,participantId:c})?g(`/${s}/register/${t}/participant/${c}/identity-verification`):l.isPhotoVerificationActive?g(ee({tenant:s,registrationCode:t,participantId:c})):g(`/${s}/register/${t}/participant/${e.id}/${l.hasExternalIdStep?"external-id":"fees"}`)},onError:()=>null}),[B,{loading:H,error:he}]=Ne({fetchPolicy:"network-only",onError:()=>null,onCompleted:({account:e})=>{var i;(i=e==null?void 0:e.profile)!=null&&i.externalAccounts.some(a=>a.tenantSlug===s)&&l.setHasExternalIdLinked(!0)}}),Y=f&&f.registrationSettings&&f.registrationSettings.__typename==="DiscoverRegistration"?`/${s}/org/${Je(f.registrationSettings.organisation.name)}/${f.registrationSettings.organisation.id}/register`:`/${s}/register/${m}`,ve=`/${s}/register/${t}/participant/${p==null?void 0:p.participant.id}/${l.hasExternalIdStep?"external-id":"fees"}`;if(pe||de||me)return o(Se,{});if(ce||!p||!p.tenantConfiguration||!p.participant.profile||!p.participant.profile.duplicateProfiles||p.participant.profile.duplicateProfiles.length===0||ue||Pe||he||ye)return o(Te,{variant:"error",children:n("pages.registrationclaimprofiles.there-was-a-problem-getting-duplicate-profile-deta")});const Re=p.participant.profile,J=p.participant.profile.duplicateProfiles,W=p.tenantConfiguration.claimProfilesIsMandatory,E=[],A=[],D=[],L=[],be=e=>{G(x.filter(i=>i!==e)),se(e)};return J.forEach(({id:e,lastRegisteredRole:i,lastRegisteredSeason:a,lastRegisteredOrganisation:d,firstName:y,lastName:u,email:v,mobileNumber:b,claimability:R,isMigrated:S,isPrivate:T})=>{const P={id:e,name:`${y} ${u}`,lastRegistration:[Ie(n(i||"")),n((a==null?void 0:a.name)||""),n((d==null?void 0:d.name)||"")].filter(Boolean).join(", "),email:v,claimability:R,mobileNumber:b,isMigrated:S,isPrivate:T};switch(R){case $.VerificationNotRequired:E.push(P);return;case $.ManuallyVerified:A.push(P);return;case $.VerificationRequired:D.push(P);return;case $.SupportRequired:L.push(P);return}}),o($e.Provider,{value:{profileId:Re.id,registrationCode:m,onProfileClaimed:be},children:q(Ue,{noYPadding:!0,noXPadding:!0,children:[q("div",{children:[o(qe,{title:n("pages.registrationclaimprofiles.title-claim-profiles")}),o(M,{size:"22",weight:"700",children:n("pages.registrationclaimprofiles.claim-profiles")}),o(Ke,{as:"p",children:n("pages.registrationclaimprofiles.playhq-has-found-one-or-more-duplicate-profiles-th-with-params",{param0:J.some(e=>e.mobileNumber)?n("pages.registrationclaimprofiles.please-verify-via-mobile-number-or-email-address"):""})}),E.length>0&&o(I,{sectionId:"verification-not-required-profiles",title:n("pages.registrationclaimprofiles.title-profiles-found-with-the-same-email-address"),tooltip:n("pages.registrationclaimprofiles.tooltip-claiming-the-profile-will-automatically-merge-it-w"),duplicateProfiles:E}),A.length>0&&o(I,{sectionId:"manually-verified-profiles",title:n("pages.registrationclaimprofiles.title-manually-verified-profiles-found"),tooltip:n("pages.registrationclaimprofiles.tooltip-claiming-the-profile-will-automatically-merge-it-w"),duplicateProfiles:A}),D.length>0&&o(I,{sectionId:"verification-required-profiles",duplicateProfiles:D}),L.length>0&&o(I,{sectionId:"support-required-profiles",title:n("pages.registrationclaimprofiles.title-profiles-found-which-can-not-be-actioned"),tooltip:n("pages.registrationclaimprofiles.tooltip-we-are-unable-to-automatically-complete-the-claimi"),duplicateProfiles:L}),q(Ze,{"data-testid":"contact-support-section",children:[o(M,{size:"14",weight:"500",children:n("pages.registrationclaimprofiles.if-you-need-assistance-to-claim-these-profiles-or")}),o(_,{variant:"quinary",color:"blackberry400",type:"button",size:"wide",icon:"share",iconPosition:"right",as:"a",href:te.contact,target:"_blank",rel:"noopener noreferrer",children:n("pages.registrationclaimprofiles.contact-support")})]}),o(xe,{name:"registration-ui-enhancements",off:q(ei,{children:[o(_,{variant:"primary",type:"button",size:"wide",icon:"right-arrow-strong",iconPosition:"right",disabled:!!W&&(x.length>0||w||H),onClick:()=>{B(),Q({variables:{participantID:String(c)}})},children:n("pages.registrationclaimprofiles.continue")}),o(_,{variant:"quinary",type:"button",disabled:w,onClick:()=>{l.setHasDuplicateProfiles(!1),g(`/${s}/register/${t}/participant/3`)},children:n("pages.registrationclaimprofiles.back")})]}),children:o(We,{nextDisabled:!!W&&(x.length>0||w||H),onNext:()=>{re("reg:claimProfiles_continue_click"),B(),Q({variables:{participantID:String(c)}})},onBack:e=>{e.preventDefault(),g(`/${s}/register/${t}/participant/3`)}})})]}),ae&&o(Xe,{participantId:r==null?void 0:r.participant.id,transferRequired:r==null?void 0:r.participant.transferRequired,registrationSettings:f.registrationSettings,tenant:s,regCode:m}),!!O&&o(we,{type:O,tenant:String(s),registrationLink:Y,registrationCompleteLink:ve,participantDetailsLink:""}),!!z&&o(Ce,{type:z,tenant:String(s),registrationCode:String(m),participantId:String(c),registrationLink:Y})]})})};export{Ai as GET_DUPLICATE_PROFILES,Di as GET_PARTICIPANT_TRANSFER_REQUESTS,Li as default};
//# sourceMappingURL=RegistrationClaimProfiles.9c5bed67.js.map
