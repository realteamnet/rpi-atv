import{g as G,s as v,m as B,T as J,r as K,j as n,_ as Z,ah as C,k as $,W as ee,F as ae,a7 as q}from"./vendor.281da1c4.js";import{_ as te}from"./Select.d9384d85.js";import{L as re}from"./LadderTables.f78e005f.js";import{a as ne,dl as se,F as ie,Y as le,d0 as oe}from"./index.b20384c6.js";import{u as de}from"./useGlossary.051e47b6.js";import{L as u}from"./gameTypeValue.1517fa68.js";import"./number.d970b2c6.js";import"./path.c99c5624.js";import"./slugify.ec4044c3.js";import"./slugify.e6045279.js";const Le=G`
  query teamLadder($teamID: ID!) {
    discoverTeam(teamID: $teamID) {
      id
      name
      season {
        id
        name
        competition {
          id
          type
        }
      }
      organisation {
        id
        name
      }
      grade {
        id
        name
        ladderType
        ladder(filter: { teamID: $teamID }) {
          pool {
            id
            name
          }
          generatedFrom {
            id
            name
          }
          standings {
            team {
              id
              name
              season {
                id
                name
                competition {
                  id
                  name
                }
              }
              organisation {
                id
                name
                type
              }
            }
            played
            won
            lost
            drawn
            byes
            pointsFor
            pointsAgainst
            pointsDifference
            percentage
            alternatePercentage
            competitionPoints
            pointsAverage
            forfeits
            disqualifications
            adjustments
            competitionPoints
            pointsAverage
            noResults
            ties
            quotient
            netRunRate
            runsFor
            oversFaced
            wicketsLost
            runsAgainst
            oversBowled
            wicketsTaken
            winOutright
            winFirstInnings
            lossOutright
            lossFirstInnings
            matchRatio
            bonusPoints
            losingBonus
            tryBonus
            triesFor
            triesAgainst
            tryDifference
          }
          gameTypeValue
        }
        gameTypes {
          name
          value
          ladderFields {
            shortName
            key
            toolTip
            extendedToolTip
            type
            displayOrder
            dataType
            decimals
          }
          ladderRankingFields {
            fullName
            shortName
            key
            sortOrder
            toolTip
          }
        }
        overallLadderFields {
          shortName
          key
          toolTip
          type
          displayOrder
          dataType
          decimals
        }
        overallLadderRankingFields {
          fullName
          shortName
          key
          sortOrder
          toolTip
        }
      }
    }
  }
`,_=v.div.withConfig({componentId:"sc-q67fr3-0"})(["","{padding-left:2.625rem;padding-right:2.625rem;}"],B.up("tablet")),me=v(J).attrs({as:"div"}).withConfig({componentId:"sc-q67fr3-1"})(["margin-bottom:1rem;","{padding:0 1rem;}"],B.down("tablet")),pe=v(te).withConfig({componentId:"sc-q67fr3-2"})(["border-color:",";color:",";font-weight:600;svg{fill:",";}"],o=>o.theme.inputFullBorder,o=>o.theme.black400,o=>o.theme.black400),ke=({teamId:o,tenant:f})=>{var b,R,N,S,D,I,A,x;const{t:s}=ne(),{data:d,loading:E,error:V}=se({variables:{teamID:String(o)},fetchPolicy:"cache-and-network",onError:()=>null}),[m,P]=K.exports.useState(u),{ladder:l}=de();if(E)return n(Z,{});if(V||!d)return n(_,{children:n(C,{variant:"error",children:s("pages.teamladder.there-was-a-problem-getting-the-for-the-team-pleas-with-params",{param0:" ",param1:l.singular.toLowerCase()})})});if(!d.discoverTeam)return n(ie,{});const{grade:e,season:j,id:H}=d.discoverTeam,Q=e&&e.ladderType,p=e==null?void 0:e.ladder.slice().filter(a=>a.standings.length>0).map(a=>a.gameTypeValue).filter(function(t,i,r){return r.indexOf(t)===i}),W=[{name:s("pages.teamladder.overall-with-params",{ladderSingular:l.singular.toLowerCase()}),value:u},...(b=Array.from(p||[]))==null?void 0:b.map(a=>{var i;const t=(i=e==null?void 0:e.gameTypes)==null?void 0:i.find(r=>(r==null?void 0:r.value)===a);return{name:(t==null?void 0:t.name)||"",value:(t==null?void 0:t.value)||""}})].filter(a=>a.name&&a.value),h=p&&p.length>2,c=e?e.ladder.filter(a=>a.standings.length<=0?!1:h?m===u?a.gameTypeValue===null:a.gameTypeValue===m:a.gameTypeValue!==null):[],M=c.map(a=>a.standings.findIndex(t=>t.team.id===H)),y=c.length>0,F=j.competition.type===le.Domestic&&y&&((R=c==null?void 0:c[0])==null?void 0:R.generatedFrom)||void 0,U=()=>{var a,t,i,r,g,O;return((a=e==null?void 0:e.gameTypes)==null?void 0:a.length)===1?(t=e==null?void 0:e.gameTypes[0])==null?void 0:t.ladderFields:h?m===u?e==null?void 0:e.overallLadderFields:(r=(i=e==null?void 0:e.gameTypes)==null?void 0:i.find(T=>T.value===m))==null?void 0:r.ladderFields:(O=(g=e==null?void 0:e.gameTypes)==null?void 0:g.find(T=>T.value===(p==null?void 0:p[0])))==null?void 0:O.ladderFields},X=()=>{var a,t,i,r;return((a=e==null?void 0:e.gameTypes)==null?void 0:a.length)===1?(t=e==null?void 0:e.gameTypes[0])==null?void 0:t.ladderRankingFields:m===u?e==null?void 0:e.overallLadderRankingFields:(r=(i=e==null?void 0:e.gameTypes)==null?void 0:i.find(g=>g.value===m))==null?void 0:r.ladderRankingFields},w=(N=d.discoverTeam)==null?void 0:N.name,L=(S=d.discoverTeam)==null?void 0:S.organisation.name,Y=(I=(D=d.discoverTeam)==null?void 0:D.grade)==null?void 0:I.name,k=(A=d.discoverTeam)==null?void 0:A.season.name,z=((x=oe.find(({slug:a})=>a===f))==null?void 0:x.name)||f;return $(_,{children:[n(ee,{title:s("pages.teamladder.param0-param1-for-param2-param3-param4",{param0:w,param1:l.singular,param2:L,param3:Y,param4:k}),meta:[{name:"description",content:`View the complete ${l.singular.toLowerCase()} for ${w} in ${L} ${k}. Explore upcoming matches and venues, recent results and stats for ${z} competitions on PlayHQ.`}]}),(!e||!y)&&n(C,{variant:"empty",children:e?s("pages.teamladder.there-is-no-param0-available-for-this-teams-grade",{param0:l.singular.toLowerCase()}):s("pages.teamladder.there-is-no-param0-available-to-display-because-te",{param0:l.singular.toLowerCase()})}),e&&y&&$(ae,{children:[h&&n(q,{width:"60rem",marginX:"auto",marginBottom:"m",children:n(q,{position:"relative",display:"block",width:"14rem",children:n(pe,{value:m,items:W,name:s("pages.teamladder.with-params-type-filter",{ladderSingular:l.singular}),id:s("pages.teamladder.with-params-type-filter",{ladderSingular:l.singular}),"data-testid":"overall-ladder-select",placeholder:s("pages.teamladder.placeholder-please-select"),placeholderSelectable:!1,onChange:a=>P(a)})})}),n(me,{weight:"700",textTransform:"uppercase",children:s(e.name)}),n(re,{ladder:c,hasAdvancedToggle:!0,ladderTemplate:Q,title:F&&s("pages.teamladder.with-params-calculated-from-with-params",{ladderSingular:l.singular,roundName:F.name}),tenant:String(f),rowsToHighlight:M,ladderFields:U(),ladderRankingFields:X()})]})]})};export{Le as TEAM_LADDER,ke as default};
//# sourceMappingURL=TeamLadder.a1f5cf11.js.map
