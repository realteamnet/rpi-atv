import{s as t}from"./vendor.281da1c4.js";import{r as e,g as a,s as o,a as l}from"./spacing.debe5ff3.js";const i=t.div`
  ${({backgroundColor:s})=>e("background-color",a(s))};
  ${({borderRadius:s})=>e("border-radius",s)}
  ${o}
`,$=t(i).attrs(({direction:s})=>({direction:typeof s=="object"?{base:"column",...s}:s||"column"}))`
  display: flex;
  ${({gap:s})=>e("gap",l(s))};

  ${({direction:s})=>e("flex-direction",s)};
  ${({wrap:s})=>e("flex-wrap",s)};
  ${({flex:s})=>e("flex",s)};
  ${({grow:s})=>e("flex-grow",s)};
  ${({shrink:s})=>e("flex-shrink",s)};
  ${({basis:s})=>e("flex-basis",s)};

  ${({alignItems:s})=>e("align-items",s)};
  ${({alignContent:s})=>e("align-content",s)};
  ${({alignSelf:s})=>e("align-self",s)};

  ${({justifyItems:s})=>e("justify-items",s)};
  ${({justifyContent:s})=>e("justify-content",s)};
  ${({justifySelf:s})=>e("justify-self",s)};
`;export{i as B,$ as S};
//# sourceMappingURL=StackV2.1e9411b4.js.map
