import{g as s,b as a}from"./vendor.281da1c4.js";const o={};var r=(e=>(e.Afl="AFL",e.Basketball="BASKETBALL",e.Cricket="CRICKET",e.Football="FOOTBALL",e.Hockey="HOCKEY",e.Netball="NETBALL",e.Other="OTHER",e.Rugby="RUGBY",e))(r||{}),l=(e=>(e.Association="ASSOCIATION",e.Club="CLUB",e))(l||{});const i=s`
    query search($filter: SearchFilter!) {
  search(filter: $filter) {
    meta {
      page
      totalPages
      totalRecords
    }
    results {
      ... on Organisation {
        id
        routingCode
        name
        type
        logo {
          sizes {
            url
            dimensions {
              width
              height
            }
          }
        }
        tenant {
          id
          name
          logo {
            sizes {
              url
              dimensions {
                width
                height
              }
            }
          }
          slug
        }
      }
    }
  }
}
    `;function n(e){const t={...o,...e};return a(i,t)}const u=s`
    query searchSchools($filter: SearchSchoolsFilter!) {
  searchSchools(filter: $filter) {
    id
    label
    name
    suburb
    state
    postcode
  }
}
    `;export{l as O,u as S,r as a,n as u};
//# sourceMappingURL=scout.09348d87.js.map
