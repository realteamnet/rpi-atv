import{r as o,t as e}from"./index.647f9079.js";function s(r,t){o(2,arguments);var a=e(r),i=e(t);return a.getTime()>i.getTime()}export{s as i};
//# sourceMappingURL=index.ea938195.js.map
