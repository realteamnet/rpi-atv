import{s as i,j as t}from"./vendor.281da1c4.js";import{m as a}from"./index.b20384c6.js";const m=i.header.withConfig({componentId:"sc-16xl76j-0"})(["padding:2rem 1rem 1.75rem;display:flex;align-items:flex-end;color:",";",""],e=>e.theme.white400,a.tablet`
    padding-top: ${e=>e.size==="normal"?"5rem":"3.75rem"};
      padding-bottom: 2.125rem;
  `),r=i.div.withConfig({componentId:"sc-16xl76j-1"})(["display:grid;justify-items:start;width:100%;margin:0 auto;padding:0;color:",";",""],e=>e.theme.white400,a.tablet`
    max-width: 60rem;
  `),l=({size:e="normal",children:o,...d})=>t(m,{size:e,...d,children:t(r,{children:o})});export{l as P};
//# sourceMappingURL=PageHeader.215820c0.js.map
