import{ax as a,r as f,ay as m,aD as b,aC as g}from"./vendor.281da1c4.js";import{L as h}from"./List.c6284ff0.js";var s={},y=a&&a.__createBinding||(Object.create?function(e,r,t,n){n===void 0&&(n=t);var i=Object.getOwnPropertyDescriptor(r,t);(!i||("get"in i?!r.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return r[t]}}),Object.defineProperty(e,n,i)}:function(e,r,t,n){n===void 0&&(n=t),e[n]=r[t]}),_=a&&a.__setModuleDefault||(Object.create?function(e,r){Object.defineProperty(e,"default",{enumerable:!0,value:r})}:function(e,r){e.default=r}),$=a&&a.__importStar||function(e){if(e&&e.__esModule)return e;var r={};if(e!=null)for(var t in e)t!=="default"&&Object.prototype.hasOwnProperty.call(e,t)&&y(r,e,t);return _(r,e),r},d=a&&a.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(s,"__esModule",{value:!0});const o=d(f.exports),l=$(m),u=g,p=d(h),c=d(b),x=l.default.div`
  display: grid;
  grid-gap: 1rem;
`,w=(0,l.default)(p.default)`
  display: -ms-grid;
  display: grid;
  grid-gap: 0.5rem;

  ${u.media.tablet`
    grid-gap: 0;
    -ms-grid-columns: (1fr)[${e=>e.columns}];
    grid-template-columns: repeat(${e=>e.columns}, 1fr);
    min-height: 4rem;
    border: 1px solid ${e=>e.theme.grey400};
  `}

  /* IE 11 */
  ${e=>(0,l.css)`
    ${new Array(e.columns).fill(0).map((r,t)=>`
          & li:nth-child(${t+1}) {
            -ms-grid-column: ${t+1};
          }
        `).join("")}
  `}
`,v=l.default.li`
  position: relative;
  display: none;
  background-color: ${e=>e.theme.white400};
  padding: 0.5rem;
  align-items: center;

  &::before,
  &::after {
    left: 100%;
    top: 50%;
    transform: translateY(-50%) scaleX(0.75);
    transform-origin: 0;
    border: 20px solid transparent;
    height: 0;
    width: 0;
    position: absolute;
    pointer-events: none;
    z-index: 1;
    content: '';
  }

  &::before {
    border-left-color: ${e=>e.theme.grey400};
    border-width: 21px;
  }

  &::after {
    border-left-color: ${e=>e.theme.blackberry400};
    border-width: 20px;
  }

  &:first-of-type {
    margin-left: 0;
  }

  ${e=>e.current===e.index&&(0,l.css)`
      display: flex;
      background-color: ${e.theme.blackberry400};
      color: ${e.theme.white400};
      margin-right: 0.825rem;
    `}

  ${u.media.tablet`
    display: flex;
    flex-direction: column;
    text-align: center;
    justify-content: center;

    & + & {
      border-left: 1px solid ${e=>e.theme.grey400};
    }

    &::before,
    &::after {
      border: 8px solid transparent;
    }

    &::before {
      border-left-color: ${e=>e.theme.grey400};
      border-width: 9px;
    }

    &::after {
      border-left-color: ${e=>e.theme.white400};
      border-width: 8px;
    }

    &:last-of-type {
      &::before,
      &::after {
        content: none;
      }
    }

    ${e=>e.current===e.index&&(0,l.css)`
        background-color: ${e.theme.blackberry400};
        color: ${e.theme.white400};
        margin-right: 0;

        &::after {
          border-left-color: ${e.theme.blackberry400};
        }
      `}

    ${e=>e.current<e.index&&(0,l.css)`
        color: ${e.theme.black400};
      `}

      ${e=>e.current>e.index&&(0,l.css)`
          color: ${e.theme.darkGrey400};
        `}
  `}
`,j=(0,l.default)(c.default).attrs({weight:"700",color:"blackberry400"})`
  display: flex;
  align-items: center;
  border-radius: 50%;
  background-color: ${e=>e.theme.white400};
  width: 1.5rem;
  height: 1.5rem;
  justify-content: center;
  margin-right: 0.75rem;

  ${u.media.tablet`
    display: none;
  `};
`,O=({steps:e,currentStep:r=0})=>o.default.createElement(x,null,o.default.createElement(w,{columns:e.length},e.map((t,n)=>o.default.createElement(v,{key:`step-${t.title}`,index:n,current:r},o.default.createElement(j,null,n+1),o.default.createElement(c.default,{size:"14",weight:"600"},t.title),t.subtitle&&o.default.createElement(c.default,{size:"12",weight:"600"},t.subtitle)))));var M=s.default=O;export{M as _};
//# sourceMappingURL=Steps.bd35588c.js.map
