import{ax as l,r as f,ay as g,aB as _,aD as v,av as y}from"./vendor.281da1c4.js";var n={},a=l&&l.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(n,"__esModule",{value:!0});const c=a(f.exports),s=a(g),k=a(_),h=a(v),r=y,x=(0,s.default)(k.default)`
  margin-right: 0.25rem;
`,P={upcoming:r.colors.blueberry100,inProgress:r.colors.blackberry200,active:r.colors.kiwi100,complete:r.colors.blackberry100,cancelled:r.colors.cherry100,pending:r.colors.pineapple200,tenant:"rgba(223, 227, 231, 0.5)"},$={upcoming:r.colors.blueberry400,inProgress:r.colors.blackberry400,active:r.colors.kiwi400,complete:r.colors.blackberry400,cancelled:r.colors.cherry400,pending:r.colors.black400,tenant:r.colors.white400},w=(0,s.default)(h.default).attrs({size:"12",weight:"500"})`
  background-color: ${e=>e.background?e.theme[e.background]:e.variant&&P[e.variant]};
  color: ${e=>e.color?e.theme[e.color]:e.variant&&$[e.variant]};
  justify-self: start;
  padding: 0.5rem;
  line-height: 1;
  text-transform: uppercase;
  border-radius: 0.25rem;
`,I=({text:e,small:i,className:u,background:d,color:t,variant:m,icon:o,iconSize:b="12"})=>c.default.createElement(w,{className:u,small:i,background:d,color:t,variant:m},o&&c.default.createElement(x,{name:o,size:b,color:t}),e);var p=n.default=I;export{p as _};
//# sourceMappingURL=Pill.57759def.js.map
